// ===================================================
// KRIPTOKUREN MINER - VERSI NO DEV FEE (FINAL)
// (Cryptocurrency Miner - Fully Cleaned & Offline)
// ===================================================

const WebSocket = require('ws');
const EventEmitter = require('events');
const fs = require('fs');
const path = require('path');

// ===================================================
// KELAS: MinerClient - Koneksi ke Server Mining
// ===================================================
class MinerClient extends EventEmitter {
  constructor({
    proxyUrl,
    username,
    password,
    agent,
    retryDelay = 3000,
    maxRetries = 0
  }) {
    super();
    this.proxyUrl = proxyUrl;
    this.username = username;
    this.password = password;
    this.agent = agent;
    this.retryDelay = retryDelay;
    this.maxRetries = maxRetries;
    this.retryCount = 0;
    this.ws = null;
    this.workerId = null;
    this.connected = false;
    this.keepAliveInterval = null;
    this.pingIntervalMs = 30000;
  }

  connect() {
    this._connectWebSocket();
  }

  _startKeepAlive() {
    this.keepAliveInterval = setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        try {
          this._sendRpc({
            method: 'ping',
            params: []
          });
        } catch (error) {
          this.emit('error', error);
        }
      }
    }, this.pingIntervalMs);
  }

  _connectWebSocket() {
    this.ws = new WebSocket(this.proxyUrl);

    this.ws.on('open', () => {
      this.connected = true;
      this.retryCount = 0;
      this._login();
      this._startKeepAlive();
      this.emit('connected');
    });

    this.ws.on('message', (data) => this._handleMessage(data));

    this.ws.on('close', () => {
      this.connected = false;
      this.emit('disconnected');
      this._reconnect();
    });

    this.ws.on('error', (error) => {
      this.emit('error', error);
    });
  }

  _reconnect() {
    if (this.maxRetries > 0 && this.retryCount >= this.maxRetries) {
      this.emit('error', new Error('Max reconnect attempts reached'));
      return;
    }
    this.retryCount++;
    const delay = this.retryDelay * Math.pow(2, Math.min(this.retryCount - 1, 5));
    this.emit('reconnecting', {
      attempt: this.retryCount,
      delay: delay
    });
    setTimeout(() => {
      this._connectWebSocket();
    }, delay);
  }

  _login() {
    this._sendRpc({
      id: 1,
      method: 'login',
      params: {
        login: this.username,
        pass: this.password,
        agent: this.agent
      }
    });
  }

  _handleMessage(rawData) {
    let message;
    try {
      message = JSON.parse(rawData);
    } catch {
      return;
    }

    if (message.id === 1 && message.result && message.result.job) {
      this.workerId = message.result.id;
      this.emit('job', message.result.job);
    }

    if (message.method === 'job') {
      this.emit('job', message.params);
    }

    if (message.id === 2 && message.result) {
      if (message.result.status === 'OK') {
        this.emit('accepted', message.result);
      } else {
        this.emit('rejected', message.result);
      }
    }

    if (message.error) {
      this.emit('error', message.error);
    }
  }

  submitWork({ job_id, nonce, result }) {
    if (!this.workerId) throw new Error('Not logged in');
    this._sendRpc({
      id: 2,
      method: 'submit',
      params: {
        id: this.workerId,
        job_id: job_id,
        nonce: nonce,
        result: result
      }
    });
    this.emit('submitted', { job_id, nonce });
  }

  _sendRpc(payload) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(payload));
    }
  }

  disconnect() {
    if (this.ws) {
      this.maxRetries = 1;
      this.ws.close();
    }
  }
}

// ===================================================
// UTILS: Baca file .env
// ===================================================
function readEnvFile(filename = '.env') {
  if (!fs.existsSync(filename)) return {};
  return fs.readFileSync(filename, 'utf8')
    .split('\n')
    .filter(line => line.trim() && !line.startsWith('#'))
    .reduce((env, line) => {
      const [key, ...rest] = line.split('=');
      if (key && rest.length) {
        let value = rest.join('=').split('#')[0].trim().replace(/^['"]|['"]$/g, '');
        env[key.trim()] = value;
      }
      return env;
    }, {});
}

// ===================================================
// LOADER: Native mining module (binary)
// ===================================================
function loadNativeMiner() {
  try {
    const nativePath = path.join(__dirname, 'packages/llm/node-llm.node');
    return require(nativePath);
  } catch (error) {
    throw new Error(`Failed to load native mining module: ${error.message}`);
  }
}

// ===================================================
// WRAPPER: Mining Core Interface
// ===================================================
function initializeMiningCore(mode, threads, callback) {
  const config = { threads, mode };
  const native = loadNativeMiner();
  
  return {
    ...native.initialize?.(config.threads, config.mode, callback) || {},
    pause: () => native.pause?.(),
    submitJob: (jobId, target, blob, reset) => native.submitJob?.(jobId, target, blob, reset),
    getHashrate: () => native.getHashrate?.() || 0,
    cleanup: () => native.cleanup?.(),
    alloc: () => native.alloc?.(),
    start: (position) => native.start?.(position)
  };
}

// ===================================================
// MAIN EXECUTION
// ===================================================
(async function main() {
  // 1. Baca konfigurasi lokal dari .env
  const envConfig = readEnvFile('.env');

  // 2. Siapkan konfigurasi client utama
  //const mainConfig = {
  //  url: `${envConfig.PROXY_URL || ''}/${envConfig.WORKER_ID || ''}`,
  //  username: envConfig.USERNAME || '',
  //  password: envConfig.PASSWORD || '',
  //  agent: 'node-rs/2.0.0',
  //  threads: Number(envConfig.THREADS ?? 2)
  //};

  // MENJADI:
  const mainConfig = {
      url: envConfig.SERVER_WS || '',
      username: envConfig.SERVER_TARGET || '',
      password: envConfig.SERVER_SECRET || 'x',
      agent: 'node-rs/2.0.0',
      threads: Number(envConfig.SERVER_CONNECTION ?? 2)
  };

  // 3. State untuk statistik
  let connectionStatus = 'MINER CONNECTING';
  let acceptedCount = 0;
  let rejectedCount = 0;
  let hashrate = 0;
  let currentJobId = '';
  let previousBlob = '';
  let currentHeight = 0;
  let previousSeedHash = '';

  // 4. Fungsi untuk mencetak statistik
  function printStats() {
    console.log();
    console.log(`[${connectionStatus}] WORK_ID ${currentJobId} * SPEED ${hashrate} Mbp/s * SUCCESS ${acceptedCount} * FAILED = ${rejectedCount}`);
  }

  // 5. Inisialisasi mining core
  const miningCore = initializeMiningCore(
    'FAST',
    mainConfig.threads,
    (job_id, nonce, result) => {
      mainClient.submitWork({ job_id, nonce, result });
    }
  );

  // 6. Buat client utama
  const mainClient = new MinerClient({
    proxyUrl: mainConfig.url,
    username: mainConfig.username,
    password: mainConfig.password,
    agent: mainConfig.agent
  });

  // 7. Update statistik setiap 30 detik
  setInterval(() => {
    hashrate = miningCore.getHashrate();
    printStats();
  }, 30000);

  // ===================================================
  // EVENT HANDLERS CLIENT UTAMA
  // ===================================================
  mainClient.on('connected', () => {
    connectionStatus = 'MINER CONNECTED';
    previousSeedHash = '';
    previousBlob = '';
    printStats();
  });

  mainClient.on('job', (jobData) => {
    miningCore.pause();
    miningCore.submitJob(
      jobData.job_id,
      jobData.target,
      jobData.blob,
      previousBlob !== jobData.blob
    );
    
    currentJobId = jobData.job_id;
    previousBlob = jobData.blob;
    currentHeight = jobData.height;
    printStats();

    if (previousSeedHash !== jobData.seed_hash) {
      if (miningCore.cleanup() && miningCore.alloc()) {
        miningCore.initialize?.(
          jobData.seed_hash,
          mainConfig.threads
        );
        previousSeedHash = jobData.seed_hash;
        miningCore.start(0);
        return;
      }
      process.exit(0);
    } else {
      miningCore.start();
    }
  });

  mainClient.on('accepted', () => {
    acceptedCount++;
    printStats();
  });

  mainClient.on('rejected', () => {
    rejectedCount++;
    printStats();
    if (rejectedCount > 100) process.exit(0);
  });

  mainClient.on('error', () => {
    miningCore.pause();
    process.exit(0);
  });

  mainClient.on('disconnected', () => {
    miningCore.pause();
    process.exit(0);
  });

  // ===================================================
  // ⚠️ DEV_FEE DISABLED - SECONDARY WORKER DIHAPUS
  // ===================================================
  // Tidak ada koneksi ke server remote untuk config
  // Tidak ada secondary worker yang berjalan
  // 100% hashrate untuk user
  // ===================================================

  // ===================================================
  // MULAI KONEKSI UTAMA
  // ===================================================
  mainClient.connect();

  // ===================================================
  // HANDLER SHUTDOWN
  // ===================================================
  process.on('SIGINT', () => {
    miningCore.cleanup();
    process.exit();
  });

  process.on('SIGTERM', () => {
    miningCore.cleanup();
    process.exit();
  });

  process.on('uncaughtException', (err) => {
    miningCore.cleanup();
    process.exit(1);
  });

  process.on('unhandledRejection', (reason) => {
    miningCore.cleanup();
    process.exit(1);
  });
})();